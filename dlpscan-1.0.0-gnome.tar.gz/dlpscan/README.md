# dlpscan 1.0.0

Sensitive-data leak scanner. Signature matching (Aho-Corasick prefilter + `std::regex`),
checksum validators (Luhn, KZ IIN/BIN, IBAN) and Shannon-entropy analysis.
C++17, multithreaded, no runtime dependencies.

Ships as two Windows 10/11 executables:

| Binary | What it is | Subsystem |
|---|---|---|
| `dlpscan.exe` | command-line scanner | console |
| `dlpscan-gui.exe` | Dear ImGui desktop UI | windows (no console) |

Interface languages: **English, Russian, Kazakh**.

---

## 1. Prerequisites (Arch Linux)

```bash
sudo pacman -S --needed base-devel cmake git mingw-w64-gcc
# optional, to run the .exe without leaving Linux:
sudo pacman -S --needed wine
```

`mingw-w64-gcc` is the cross-compiler. Check it landed:

```bash
x86_64-w64-mingw32-g++ --version
ls /usr/x86_64-w64-mingw32/include/GL/gl.h     # must exist, note the capital GL
```

---

## 2. Build and run

### The short version

```bash
tar -xzf dlpscan-1.0.0-gnome.tar.gz && cd dlpscan

sudo pacman -S --needed base-devel cmake git mingw-w64-gcc

# give the GUI a font that has Cyrillic + Kazakh (strongly recommended)
sudo pacman -S --needed cantarell-fonts
cp /usr/share/fonts/cantarell/Cantarell-VF.otf assets/fonts/ui.ttf

./build.sh gui          # fetches Dear ImGui, builds both .exe files
```

Results:

```
build-win/dlpscan.exe        console scanner
build-win/dlpscan-gui.exe    windowed app
```

### Running the .exe

**On Windows** — copy the whole folder, keeping the layout, and double-click:

```
dlpscan-gui.exe
assets\fonts\ui.ttf
```

`assets/` must sit next to the .exe; the app resolves it from its own module
path, not the working directory. Nothing to install — no runtime, no DLLs.
The CLI needs a terminal:

```
dlpscan.exe C:\Users\you --lang kk --html report.html
```

**On Arch, without leaving Linux** — via Wine:

```bash
sudo pacman -S wine
cd build-win
cp -r ../assets .            # Wine has no Segoe UI, so the font matters here
wine ./dlpscan-gui.exe
wine ./dlpscan.exe --lang ru --selftest
```

If the GUI is blank or fails to open a window under Wine, it is OpenGL:
`WINEDEBUG=-all LIBGL_ALWAYS_SOFTWARE=1 wine ./dlpscan-gui.exe`.

### Build targets

```bash
./build.sh linux   # native Linux binary + self-test   -> build/dlpscan
./build.sh imgui   # fetch third_party/imgui           (once)
./build.sh win     # Windows CLI                       -> build-win/dlpscan.exe
./build.sh gui     # Windows CLI + GUI                 -> build-win/dlpscan-gui.exe
./build.sh test    # native build + scan_runner smoketest
./build.sh ide     # regenerate compile_commands.json for VS Code
./build.sh all     # linux + win + gui
./build.sh clean
```

`./build.sh gui` runs `imgui` for you if `third_party/imgui` is missing.
`build.sh` verifies after every Windows build that the `.exe` imports only
system DLLs - if `libstdc++-6.dll` or `libwinpthread-1.dll` shows up, it warns.

Equivalent raw CMake:

```bash
cmake -B build-win \
      -DCMAKE_TOOLCHAIN_FILE=cmake/toolchain-mingw64.cmake \
      -DCMAKE_BUILD_TYPE=Release \
      -DDLP_BUILD_GUI=ON
cmake --build build-win -j$(nproc)
```

### Dear ImGui

Not bundled. It is fetched to `third_party/imgui` (git-ignored) by
`./build.sh imgui`, or automatically by CMake when `DLP_BUILD_GUI=ON`:

```bash
git clone --depth 1 --branch v1.91.0 https://github.com/ocornut/imgui.git third_party/imgui
```

Pinned to `v1.91.0`. Override with `IMGUI_TAG=v1.92.8 ./build.sh imgui` or
`-DDLP_IMGUI_TAG=...`. Both ImGui generations are supported: `gui_main.cpp`
switches font loading on `IMGUI_VERSION_NUM >= 19200`, because 1.92 reworked
the font system and made `GetGlyphRangesCyrillic()` obsolete.

Only 6 ImGui files are compiled (core + `imgui_impl_win32` + `imgui_impl_opengl2`).
`imgui_demo.cpp` is deliberately excluded - it is the one that needs
`-Wa,-mbig-obj` under MinGW.

---

## 3. VS Code on Arch: killing the red squiggles

Two separate causes, fixed two separate ways.

**Cause 1 - a real bug.** `gui_main.cpp` had `#include <gl/gl.h>`. MinGW ships
the header as `GL/gl.h`, uppercase. Windows filesystems are case-insensitive so
it works there; Linux is case-sensitive so it fails for real, not just in the
editor. Fixed in the source.

**Cause 2 - IntelliSense configuration.** `windows.h` and `objbase.h` do exist,
at `/usr/x86_64-w64-mingw32/include/`, but VS Code was searching your Linux
system headers. Fixed by the shipped config:

```
.vscode/c_cpp_properties.json   "Windows (MinGW cross)" configuration
.vscode/settings.json           clangd args + compile_commands path
.vscode/tasks.json              build tasks (Ctrl+Shift+B)
.clangd                         clangd compilation-database config
```

To activate:

```bash
./build.sh gui     # or: ./build.sh ide
```

That generates `build-win/compile_commands.json` and symlinks it to the project
root. Then in VS Code: **Ctrl+Shift+P** -> `C/C++: Select a Configuration` ->
**Windows (MinGW cross)**, and reload the window.

If you use **clangd** instead of the Microsoft C/C++ extension, it picks up
`.clangd` + `compile_commands.json` with no further action.

Still red after that? `compile_commands.json` only lists files that are *in the
build*. `src/gui/*.cpp` only enters the build when `DLP_BUILD_GUI=ON`, so run
`./build.sh gui`, not `./build.sh win`.

---

## 4. Why text showed as `??????`, and the fix

ImGui renders any codepoint missing from its font atlas as `?`. So a screen full
of `??????` means the font had no Cyrillic glyphs — not that the translation is
broken.

The old code asked for `C:\Windows\Fonts\segoeui.ttf` and, if that failed,
silently called `AddFontDefault()`. ImGui's built-in font (ProggyClean) is
**ASCII-only**, so every Russian and Kazakh letter became `?`. Segoe UI is
Microsoft-licensed, so it does **not** exist in a Wine prefix on Arch — which is
exactly where you were most likely to see this.

What changed in `src/gui/gui_font.cpp`:

* 16 font candidates instead of 3, including `assets/fonts/` beside the .exe,
  the real Windows font directory via `GetWindowsDirectoryW`, and Wine's
  `Z:\usr\share\fonts\...` paths.
* Each candidate is **verified** to contain Ж (U+0416) and Қ (U+049A) before
  being accepted. A font that loads but lacks Cyrillic is skipped, not used.
* Fonts are read with `ReadFile` and handed to `AddFontFromMemoryTTF`, so a
  failure is detectable instead of silent.
* If every candidate fails, the window shows an orange banner telling you to
  drop a font in `assets/fonts/` — instead of rendering `?????` with no clue why.
* Glyph coverage widened from 4 ranges to 13: Latin Extended, Greek, full
  Cyrillic, punctuation, arrows (`→` was genuinely missing before), maths,
  currency and box drawing.

Guaranteed fix: `pacman -S cantarell-fonts`, then
`cp /usr/share/fonts/cantarell/Cantarell-VF.otf assets/fonts/ui.ttf`.
See `assets/fonts/README.txt`.

There was a second `?????` source on the **console**: writing UTF-8 bytes to
cmd.exe produces `?` for anything outside the active code page, even with
`SetConsoleOutputCP(CP_UTF8)`. `dlp::writeConsoleUtf8()` now converts to UTF-16
and calls `WriteConsoleW` when stdout is a real console, falling back to plain
stream output when redirected to a file or pipe.

---

## 5. Interface

GNOME/Adwaita styling, in `src/gui/gui_theme.cpp`:

* Adwaita palette, dark and light, switchable from the header bar
  (`#1e1e1e` / `#fafafa` surfaces, `#3584e4` accent, Adwaita status colours)
* Header bar with title, theme and language pickers
* Two-column layout: settings cards on the left, results on the right
* Rounded cards (12px), pill buttons (`PillButton`), suggested-action blue and
  destructive red variants
* Severity shown as a rounded badge rather than coloured text
* Stat strip (files / data / found / elapsed) above a thin progress bar
* Status bar with a coloured state dot
* Four font sizes from one family (title / bold / regular / small), and the
  whole UI scales by the monitor's DPI via `GetDeviceCaps(LOGPIXELSX)`

---

## 6. Languages

Three interface languages: `en`, `ru`, `kk`.

```bash
dlpscan --lang en /path
dlpscan --lang ru /path
dlpscan --lang kk /path
```

Without `--lang`, the language comes from the system locale
(`LC_ALL`/`LC_MESSAGES`/`LANG` on Linux, `GetUserDefaultLocaleName` on Windows),
falling back to English. In the GUI there is a **Language** dropdown at the top
of the settings panel; it switches the interface instantly.

Localized: all GUI chrome, CLI help and errors, console report, HTML report,
severity levels, rule names, and the generated finding notes.
Not localized: the stable machine-readable `ruleId` values, JSON/CSV field
names, and the individual self-test check names (developer diagnostics).

### Adding or editing translations

Everything lives in one table. `src/i18n.cpp` holds 242 entries of
`{ english, russian, kazakh }`, indexed by the `enum class S` in
`include/dlp/i18n.hpp`. A `static_assert` fails the build if the table and the
enum ever diverge.

Adding a language = add a field to `struct Entry`, a `Lang` enum value, a case
in `trIn()`, and a third string per row.

---

## 7. Usage

```bash
dlpscan                                  # scan the current directory
dlpscan C:\Users\ivanov --min-severity high
dlpscan /srv --json out.json --html out.html --lang kk
dlpscan --list-rules
dlpscan --selftest                       # 88 built-in algorithm checks
dlpscan --help
```

Exit code is 1 when findings at or above `--fail-on` exist, so it drops straight
into CI.

Secrets are masked in all output by default. `--no-redact` disables that and is
dangerous: the report then contains the live credentials.

---

## 8. Layout

```
include/dlp/      public headers (i18n.hpp, scanner.hpp, scan_runner.hpp, ...)
src/              core + CLI entry point (main.cpp)
src/i18n.cpp      242-entry translation table  (generated, edit freely)
src/i18n_help.cpp --help text, one raw string per language
src/scan_runner.* threaded scan orchestration for the GUI (cancel + live progress)
src/gui/          Windows-only GUI
  gui_main.cpp    wWinMain, window + OpenGL context, frame loop
  gui_app.cpp     the Adwaita-styled screen
  gui_theme.cpp   Adwaita palettes, pill buttons, cards, badges
  gui_font.cpp    font discovery with Cyrillic verification
  win32_util.cpp  folder picker, save dialog, UTF-8/UTF-16
assets/fonts/     drop Cantarell/Inter/Noto here (see its README.txt)
tests/            scan_runner smoke test
third_party/imgui fetched, git-ignored
```

How the two executables share code:

```
                  ┌── main.cpp ─────────────► dlpscan.exe
core sources ─────┤
                  └── scan_runner.cpp
                      + src/gui/*.cpp ──────► dlpscan-gui.exe
```

`main.cpp` and `scan_runner.cpp` are mutually exclusive; everything else is
compiled into both. `FindingSink` lives in its own `finding_sink.cpp` precisely
because both targets need it and the GUI has no `main.cpp`.

The source contains no comments - all explanation lives in this file.

---

## 9. Testing

```bash
./build.sh test
```

runs, in order:

1. `dlpscan --selftest` - 88 checks (Luhn, IIN check digit, IBAN mod-97, entropy,
   Aho-Corasick, wildcards, base64, escaping)
2. `scripts/make_samples.sh` - generates a corpus of fake secrets
   (vendor-documentation keys, official test card numbers, a valid-checksum IIN;
   nothing real)
3. `scan_runner_smoketest` on ~2000 files - verifies live progress during the
   scan, mid-scan cancellation, and destruction while a scan is still running
4. a CLI scan producing a JSON report

Check localization by eye:

```bash
for L in en ru kk; do build/dlpscan samples --lang $L --no-color | head -20; done
```
