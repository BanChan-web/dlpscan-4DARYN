#include "dlp/i18n.hpp"
#include "dlp/common.hpp"

#include <iostream>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <sstream>

#if defined(_WIN32)
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <io.h>
#  include <windows.h>
#else
#  include <unistd.h>
#endif

namespace dlp {

const char* severityName(Severity s) noexcept {
    switch (s) {
        case Severity::Critical: return "critical";
        case Severity::High:     return "high";
        case Severity::Medium:   return "medium";
        case Severity::Low:      return "low";
        case Severity::Info:     return "info";
    }
    return "info";
}

const char* severityNameLocalized(Severity s) noexcept {
    switch (s) {
        case Severity::Critical: return tr(S::SevCritical);
        case Severity::High:     return tr(S::SevHigh);
        case Severity::Medium:   return tr(S::SevMedium);
        case Severity::Low:      return tr(S::SevLow);
        case Severity::Info:     return tr(S::SevInfo);
    }
    return tr(S::SevInfo);
}

const char* severityNameLocalizedCap(Severity s) noexcept {
    switch (s) {
        case Severity::Critical: return tr(S::SevCriticalCap);
        case Severity::High:     return tr(S::SevHighCap);
        case Severity::Medium:   return tr(S::SevMediumCap);
        case Severity::Low:      return tr(S::SevLowCap);
        case Severity::Info:     return tr(S::SevInfoCap);
    }
    return tr(S::SevInfoCap);
}

bool parseSeverity(std::string_view text, Severity& out) noexcept {
    const std::string t = toLowerAscii(text);
    if (t == "critical" || t == "crit") { out = Severity::Critical; return true; }
    if (t == "high")                    { out = Severity::High;     return true; }
    if (t == "medium" || t == "med")    { out = Severity::Medium;   return true; }
    if (t == "low")                     { out = Severity::Low;      return true; }
    if (t == "info" || t == "all")      { out = Severity::Info;     return true; }
    return false;
}

std::string pathToUtf8(const fs::path& p) {
#if defined(__cpp_lib_char8_t)
    const auto s = p.u8string();
    return std::string(reinterpret_cast<const char*>(s.data()), s.size());
#else
    return p.u8string();
#endif
}

fs::path utf8ToPath(std::string_view s) {
#if defined(__cpp_lib_char8_t)
    return fs::path(std::u8string(reinterpret_cast<const char8_t*>(s.data()), s.size()));
#else
    return fs::u8path(std::string(s));
#endif
}

std::string normalizeSeparators(std::string_view p) {
    std::string out(p);
    std::replace(out.begin(), out.end(), '\\', '/');
    return out;
}

std::string toLowerAscii(std::string_view s) {
    std::string out(s);
    for (char& c : out) {
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
    }
    return out;
}

static inline char lowerc(char c) noexcept {
    return (c >= 'A' && c <= 'Z') ? static_cast<char>(c - 'A' + 'a') : c;
}

bool iequalsAscii(std::string_view a, std::string_view b) noexcept {
    if (a.size() != b.size()) return false;
    for (std::size_t i = 0; i < a.size(); ++i) {
        if (lowerc(a[i]) != lowerc(b[i])) return false;
    }
    return true;
}

bool endsWithIAscii(std::string_view s, std::string_view suffix) noexcept {
    if (suffix.size() > s.size()) return false;
    return iequalsAscii(s.substr(s.size() - suffix.size()), suffix);
}

bool startsWithIAscii(std::string_view s, std::string_view prefix) noexcept {
    if (prefix.size() > s.size()) return false;
    return iequalsAscii(s.substr(0, prefix.size()), prefix);
}

bool wildcardMatch(std::string_view pat, std::string_view text,
                   bool caseInsensitive) noexcept {
    std::size_t p = 0, t = 0;
    std::size_t starP = std::string_view::npos, starT = 0;
    while (t < text.size()) {
        const bool have = p < pat.size();
        char pc = have ? pat[p] : '\0';
        char tc = text[t];
        if (caseInsensitive) { pc = lowerc(pc); tc = lowerc(tc); }

        if (have && (pc == '?' || pc == tc)) {
            ++p; ++t;
        } else if (have && pc == '*') {
            starP = p++;
            starT = t;
        } else if (starP != std::string_view::npos) {
            p = starP + 1;
            t = ++starT;
        } else {
            return false;
        }
    }
    while (p < pat.size() && pat[p] == '*') ++p;
    return p == pat.size();
}

std::string trim(std::string_view s) {
    std::size_t b = 0, e = s.size();
    auto isws = [](char c) {
        return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f' || c == '\v';
    };
    while (b < e && isws(s[b])) ++b;
    while (e > b && isws(s[e - 1])) --e;
    return std::string(s.substr(b, e - b));
}

std::vector<std::string> splitAndTrim(std::string_view s, char sep) {
    std::vector<std::string> out;
    std::size_t start = 0;
    while (start <= s.size()) {
        const std::size_t pos = s.find(sep, start);
        const std::size_t end = (pos == std::string_view::npos) ? s.size() : pos;
        std::string piece = trim(s.substr(start, end - start));
        if (!piece.empty()) out.push_back(std::move(piece));
        if (pos == std::string_view::npos) break;
        start = pos + 1;
    }
    return out;
}

std::string humanBytes(u64 bytes) {
    static const char* kUnits[] = {"B", "KiB", "MiB", "GiB", "TiB", "PiB"};
    double v = static_cast<double>(bytes);
    int u = 0;
    while (v >= 1024.0 && u < 5) { v /= 1024.0; ++u; }
    char buf[64];
    if (u == 0) std::snprintf(buf, sizeof(buf), "%llu B", static_cast<unsigned long long>(bytes));
    else        std::snprintf(buf, sizeof(buf), "%.2f %s", v, kUnits[u]);
    return buf;
}

std::string humanDuration(double seconds) {
    char buf[64];
    if (seconds < 1.0)  { std::snprintf(buf, sizeof(buf), tr(S::UnitMs), seconds * 1000.0); return buf; }
    if (seconds < 60.0) { std::snprintf(buf, sizeof(buf), tr(S::UnitSec), seconds);           return buf; }
    const int m = static_cast<int>(seconds) / 60;
    const double s = seconds - m * 60;
    std::snprintf(buf, sizeof(buf), tr(S::UnitMinSec), m, s);
    return buf;
}

bool parseSize(std::string_view text, u64& out) noexcept {
    if (text.empty()) return false;
    u64 value = 0;
    std::size_t i = 0;
    bool anyDigit = false;
    for (; i < text.size() && text[i] >= '0' && text[i] <= '9'; ++i) {
        const u64 d = static_cast<u64>(text[i] - '0');
        if (value > (~0ull - d) / 10) return false;
        value = value * 10 + d;
        anyDigit = true;
    }
    if (!anyDigit) return false;

    u64 mult = 1;
    std::string suffix = toLowerAscii(text.substr(i));
    if (!suffix.empty() && suffix.back() == 'b') suffix.pop_back();
    if      (suffix.empty()) mult = 1;
    else if (suffix == "k")  mult = 1024ull;
    else if (suffix == "m")  mult = 1024ull * 1024;
    else if (suffix == "g")  mult = 1024ull * 1024 * 1024;
    else if (suffix == "t")  mult = 1024ull * 1024 * 1024 * 1024;
    else return false;

    if (value > ~0ull / mult) return false;
    out = value * mult;
    return true;
}

u64 fnv1a64(const void* data, std::size_t len) noexcept {
    const u8* p = static_cast<const u8*>(data);
    u64 h = 1469598103934665603ull;
    for (std::size_t i = 0; i < len; ++i) {
        h ^= p[i];
        h *= 1099511628211ull;
    }
    return h;
}

std::string toHex64(u64 v) {
    static const char* kHex = "0123456789abcdef";
    std::string out(16, '0');
    for (int i = 15; i >= 0; --i) {
        out[static_cast<std::size_t>(i)] = kHex[v & 0xF];
        v >>= 4;
    }
    return out;
}

std::string nowIso8601Utc() {
    const std::time_t t = std::time(nullptr);
    std::tm tmv{};
#if defined(_WIN32)
    gmtime_s(&tmv, &t);
#else
    gmtime_r(&t, &tmv);
#endif
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tmv);
    return buf;
}

bool stdoutIsTty() noexcept {
#if defined(_WIN32)
    return _isatty(_fileno(stdout)) != 0;
#else
    return isatty(fileno(stdout)) != 0;
#endif
}

void enableConsoleUtf8AndAnsi() noexcept {
#if defined(_WIN32)

    ::SetConsoleOutputCP(CP_UTF8);
    ::SetConsoleCP(CP_UTF8);
    HANDLE h = ::GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode = 0;
    if (h != INVALID_HANDLE_VALUE && ::GetConsoleMode(h, &mode)) {
        ::SetConsoleMode(h, mode | 0x0004  );
    }
#endif
}

#if defined(_WIN32)
namespace {

HANDLE consoleHandleFor(std::ostream& os) noexcept {
    DWORD which = STD_OUTPUT_HANDLE;
    if (&os == &std::cerr || &os == &std::clog) which = STD_ERROR_HANDLE;
    HANDLE h = ::GetStdHandle(which);
    if (h == nullptr || h == INVALID_HANDLE_VALUE) return nullptr;
    DWORD mode = 0;
    if (!::GetConsoleMode(h, &mode)) return nullptr;
    return h;
}

}
#endif

void writeConsoleUtf8(std::ostream& os, const std::string& text) {
    if (text.empty()) return;
#if defined(_WIN32)
    HANDLE h = consoleHandleFor(os);
    if (h != nullptr) {
        os.flush();
        const int need = ::MultiByteToWideChar(CP_UTF8, 0, text.data(),
                                               static_cast<int>(text.size()), nullptr, 0);
        if (need > 0) {
            std::wstring w(static_cast<std::size_t>(need), L'\0');
            ::MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()),
                                  w.data(), need);
            DWORD written = 0;
            ::WriteConsoleW(h, w.data(), static_cast<DWORD>(w.size()), &written, nullptr);
            return;
        }
    }
#endif
    os << text;
}

void flushConsole(std::ostream& os) { os.flush(); }

}
