#include "dlp/thread_pool.hpp"

namespace dlp {

unsigned defaultThreadCount() noexcept {
    unsigned n = std::thread::hardware_concurrency();
    if (n == 0) n = 4;

    return n;
}

}
