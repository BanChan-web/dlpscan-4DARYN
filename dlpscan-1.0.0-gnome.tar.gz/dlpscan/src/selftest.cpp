#include "dlp/i18n.hpp"
#include "dlp/selftest.hpp"

#include "dlp/detectors.hpp"
#include "dlp/entropy.hpp"
#include "dlp/prefilter.hpp"
#include "dlp/redact.hpp"
#include "dlp/report.hpp"
#include "dlp/rules.hpp"
#include "dlp/validators.hpp"

#include <cmath>
#include <cstring>
#include <iostream>
#include <string>

namespace dlp {

namespace {

int g_failed = 0;
int g_total  = 0;

void check(bool cond, const std::string& what, std::ostream& os) {
    ++g_total;
    if (!cond) {
        ++g_failed;
        os << "  [ПРОВАЛ] " << what << '\n';
    }
}

void checkNear(double got, double want, double eps, const std::string& what,
               std::ostream& os) {
    ++g_total;
    if (std::fabs(got - want) > eps) {
        ++g_failed;
        os << "  [ПРОВАЛ] " << what << ": получено " << got << ", ожидалось " << want << '\n';
    }
}

const u8* bytes(const char* s) { return reinterpret_cast<const u8*>(s); }

void testLuhn(std::ostream& os) {
    check(luhnValid("4111111111111111"),  "Луна: валидный Visa", os);
    check(luhnValid("5555555555554444"),  "Луна: валидный Mastercard", os);
    check(luhnValid("378282246310005"),   "Луна: валидный Amex", os);
    check(!luhnValid("4111111111111112"), "Луна: испорченная контрольная цифра", os);
    check(!luhnValid("1234567890123456"), "Луна: произвольные цифры", os);
    check(!luhnValid("411111111111"),     "Луна: слишком короткий", os);
    check(!luhnValid("41111111111111111111"), "Луна: слишком длинный", os);
    check(!luhnValid("4111a11111111111"), "Луна: нецифровой символ", os);

    check(detectCardBrand("4111111111111111") == CardBrand::Visa,       "БИН: Visa", os);
    check(detectCardBrand("5555555555554444") == CardBrand::Mastercard, "БИН: Mastercard", os);
    check(detectCardBrand("378282246310005")  == CardBrand::Amex,       "БИН: Amex", os);
    check(isKnownTestCard("4242424242424242"), "тестовый номер распознан", os);
}

void testIin(std::ostream& os) {

    check(kzIinValid("950101300125"), "ИИН: валидный номер", os);
    check(!kzIinValid("950101300124"), "ИИН: неверная контрольная цифра", os);
    check(!kzIinValid("951301300125"), "ИИН: месяц 13", os);
    check(!kzIinValid("950132300125"), "ИИН: день 32", os);
    check(!kzIinValid("95010130012"),  "ИИН: 11 цифр", os);
    check(!kzIinValid("9501013001250"),"ИИН: 13 цифр", os);
    check(!kzIinValid("95010190012x"), "ИИН: буква внутри", os);

    IinInfo info;
    if (kzIinValid("950101300125", &info)) {
        check(info.year == 1995 && info.month == 1 && info.day == 1,
              "ИИН: разбор даты рождения", os);
        check(!info.female, "ИИН: признак пола (7-я цифра 3 → мужской)", os);
    } else {
        check(false, "ИИН: разбор эталонного номера", os);
    }

    int accepted = 0;
    u64 seed = 123456789;
    for (int i = 0; i < 1000; ++i) {
        seed = seed * 6364136223846793005ull + 1442695040888963407ull;
        char buf[13];
        u64 x = seed >> 11;
        for (int k = 0; k < 12; ++k) { buf[k] = static_cast<char>('0' + x % 10); x /= 10; }
        buf[12] = '\0';
        if (kzIinValid(std::string(buf, 12))) ++accepted;
    }
    check(accepted < 60, "ИИН: доля ложных срабатываний на случайных числах < 6%", os);
}

void testEntropy(std::ostream& os) {

    std::string zeros(4096, '\0');
    checkNear(shannonEntropy(bytes(zeros.data()), zeros.size()), 0.0, 1e-9,
              "энтропия константного буфера", os);

    std::vector<u8> uniform(256 * 16);
    for (std::size_t i = 0; i < uniform.size(); ++i) uniform[i] = static_cast<u8>(i % 256);
    checkNear(shannonEntropy(uniform.data(), uniform.size()), 8.0, 1e-6,
              "энтропия равномерного буфера", os);

    std::vector<u8> binary(1000);
    for (std::size_t i = 0; i < binary.size(); ++i) binary[i] = (i % 2) ? 'a' : 'b';
    checkNear(shannonEntropy(binary.data(), binary.size()), 1.0, 1e-9,
              "энтропия двух равновероятных символов", os);

    EntropyCounter ec;
    const char* text = "The quick brown fox jumps over the lazy dog 1234567890";
    ec.addRange(bytes(text), std::strlen(text));
    checkNear(ec.entropy(), shannonEntropy(bytes(text), std::strlen(text)), 1e-9,
              "инкрементальный счётчик == прямой подсчёт", os);

    const double before = ec.entropy();
    ec.add('Z');
    ec.remove('Z');
    checkNear(ec.entropy(), before, 1e-9, "add/remove обратимы", os);

    std::vector<u8> mixed;
    for (int i = 0; i < 4096; ++i) mixed.push_back(static_cast<u8>('a' + (i % 5)));
    u64 s = 99991;
    for (int i = 0; i < 4096; ++i) {
        s = s * 6364136223846793005ull + 1442695040888963407ull;
        mixed.push_back(static_cast<u8>(s >> 33));
    }
    EntropyProfiler prof(1024, 512, 7.0);
    prof.feed(mixed.data(), mixed.size(), 0);
    const EntropyProfile p = prof.finish();
    check(p.maxWindowEntropy > 7.0, "скользящее окно находит случайный блок", os);
    check(p.maxWindowOffset >= 3000, "смещение окна указывает во вторую половину", os);
    check(p.fileEntropy < p.maxWindowEntropy, "средняя энтропия ниже локального максимума", os);
}

void testPrefilter(std::ostream& os) {
    AhoCorasick ac(true);
    ac.add("akia", 1);
    ac.add("password", 2);
    ac.add("-----begin", 3);
    ac.add("sword", 4);
    ac.build();

    const char* text = "x AKIAxxxx ... My PassWord is ... -----BEGIN RSA";
    std::vector<int> ids;
    ac.scan(bytes(text), std::strlen(text), [&](int id, std::size_t) { ids.push_back(id); });

    auto has = [&](int id) {
        return std::find(ids.begin(), ids.end(), id) != ids.end();
    };
    check(has(1), "Ахо—Корасик: регистронезависимый поиск AKIA", os);
    check(has(2), "Ахо—Корасик: PassWord найден", os);
    check(has(3), "Ахо—Корасик: -----BEGIN найден", os);
    check(has(4), "Ахо—Корасик: вложенный суффикс 'sword' найден", os);

    AhoCorasick empty(true);
    empty.build();
    std::size_t count = 0;
    empty.scan(bytes(text), std::strlen(text), [&](int, std::size_t) { ++count; });
    check(count == 0, "Ахо—Корасик: пустой автомат безопасен", os);
}

void testNumericScanner(std::ostream& os) {
    const char* text = "Карта: 4111 1111 1111 1111, ИИН 950101300125, код 12345, "
                       "id=987654321098765432109876";
    std::vector<NumericHit> hits;
    NumericOptions opt;
    scanNumericRuns(bytes(text), std::strlen(text), opt, hits);

    bool card = false, iin = false, overlong = false;
    for (const NumericHit& h : hits) {
        if (h.digits == "4111111111111111") card = true;
        if (h.digits == "950101300125")     iin  = true;
        if (h.digits.size() > 24)           overlong = true;
    }
    check(card, "числовой автомат: карта с пробелами собрана", os);
    check(iin,  "числовой автомат: 12-значный ИИН выделен", os);
    check(!overlong, "числовой автомат: сверхдлинные последовательности отброшены", os);

    std::vector<NumericHit> h2;
    const char* inWord = "abc4111111111111111def";
    scanNumericRuns(bytes(inWord), std::strlen(inWord), opt, h2);
    check(h2.empty(), "числовой автомат: границы слова соблюдены", os);
}

void testTokenScanner(std::ostream& os) {
    std::vector<TokenHit> hits;
    TokenOptions opt;
    const char* text = "api_key = 7Fq2LmZx9TbVnR4pKdW8sYcE3hJu6Ago and a normal "
                       "sentence with ordinary words only";
    scanEntropicTokens(bytes(text), std::strlen(text), opt, hits);
    check(!hits.empty(), "токен-детектор: ключ рядом с api_key найден", os);

    std::vector<TokenHit> h2;
    const char* plain = "this is a perfectly ordinary sentence without any secrets 123";
    scanEntropicTokens(bytes(plain), std::strlen(plain), opt, h2);
    check(h2.empty(), "токен-детектор: обычный текст не даёт срабатываний", os);

    std::vector<TokenHit> h3;
    const char* uuid = "request_id 550e8400-e29b-41d4-a716-446655440000 done";
    scanEntropicTokens(bytes(uuid), std::strlen(uuid), opt, h3);
    check(h3.empty(), "токен-детектор: UUID не считается секретом", os);
}

void testValidators(std::ostream& os) {
    check(jwtStructureValid(
              "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
              "eyJzdWIiOiIxMjM0NTY3ODkwIn0.dBjftJeZ4CVPmB92K27uhbUJU1p1r_wW1gFWFOEjXk"),
          "JWT: корректная структура", os);
    check(!jwtStructureValid("eyJhbGciOiJIUzI1NiJ9.notbase64!!.sig"), "JWT: битая полезная нагрузка", os);
    check(!jwtStructureValid("aaa.bbb.ccc"), "JWT: заголовок не JSON", os);

    check(ibanValid("GB82 WEST 1234 5698 7654 32"), "IBAN: эталонный британский", os);
    check(!ibanValid("GB82WEST12345698765433"),     "IBAN: испорченная контрольная сумма", os);

    check(looksLikePlaceholder("your_api_key_here"), "заглушка: your_api_key_here", os);
    check(looksLikePlaceholder("${DB_PASSWORD}"),    "заглушка: переменная окружения", os);
    check(looksLikePlaceholder("xxxxxxxxxxxx"),      "заглушка: повтор символов", os);
    check(!looksLikePlaceholder("7Fq2LmZx9TbVnR4p"), "заглушка: реальный ключ не отброшен", os);

    check(isUuid("550e8400-e29b-41d4-a716-446655440000"), "UUID распознан", os);
    check(isHexString("deadbeef1234"), "hex-строка распознана", os);
    check(isBase64OfText("VGhpcyBpcyBwbGFpbiB0ZXh0IGRhdGEh"), "base64 от текста распознан", os);
}

void testRedaction(std::ostream& os) {
    const std::string red = redactSecret("AKIAIOSFODNN7EXAMPLE");
    check(red.find("IOSFODNN7") == std::string::npos, "маскирование: середина скрыта", os);
    check(red.rfind("AKIA", 0) == 0, "маскирование: начало сохранено", os);

    const std::string pan = redactPan("4111111111111111");
    check(pan == "411111******1111", "маскирование PAN по правилам PCI DSS", os);
    check(redactIin("950101300125") == "950101******", "маскирование ИИН", os);

    const char* line = "password=SuperSecret123 # comment";
    const std::string prev = buildPreview(bytes(line), std::strlen(line), 9, 15, "****");
    check(prev.find("SuperSecret123") == std::string::npos,
          "предпросмотр не содержит исходный секрет", os);
    check(prev.find("password=") != std::string::npos,
          "предпросмотр сохраняет контекст", os);
}

void testRules(std::ostream& os) {
    RuleSet rs;
    rs.loadDefaults();
    std::string err;
    check(rs.compile(err), "все встроенные правила компилируются: " + err, os);
    check(rs.enabledCount() > 20, "загружено достаточное число правил", os);
    check(!rs.prefilter().empty(), "предфильтр построен", os);

    struct Case { const char* id; const char* text; };
    const Case cases[] = {
        {"aws_access_key",       "key = AKIAIOSFODNN7EXAMPLE"},
        {"github_token",         "ghp_1234567890abcdefghijklmnopqrstuvwxyz"},
        {"private_key_pem",      "-----BEGIN RSA PRIVATE KEY-----"},
        {"db_connection_string", "postgres://admin:Str0ngPass@db.local:5432/app"},
        {"gcp_api_key",          "AIzaSyD-1234567890abcdefghijklmnopqrstu"},
        {"slack_token",          "xoxb-12345678901-abcdefghijklmnop"},
    };
    for (const Case& c : cases) {
        bool matched = false;
        for (const Rule& r : rs.rules()) {
            if (r.id != c.id || !r.compiled) continue;
            matched = std::regex_search(c.text, r.re);
            break;
        }
        check(matched, std::string("правило ") + c.id + " срабатывает на эталоне", os);
    }

    const char* benign = "Обычный текст без секретов. Версия 1.2.3, дата 2026-01-15.";
    int falsePositives = 0;
    for (const Rule& r : rs.rules()) {
        if (!r.compiled || r.id == "email_address") continue;
        if (std::regex_search(benign, r.re)) ++falsePositives;
    }
    check(falsePositives == 0, "на нейтральном тексте нет срабатываний", os);
}

void testUtils(std::ostream& os) {
    check(wildcardMatch("*/node_modules/*", "/home/u/p/node_modules/x.js", true),
          "маска: */node_modules/*", os);
    check(wildcardMatch("*.log", "app.LOG", true), "маска: регистронезависимость", os);
    check(!wildcardMatch("*.log", "app.txt", true), "маска: несовпадение", os);
    check(wildcardMatch("a?c", "abc", true), "маска: символ '?'", os);
    check(wildcardMatch("*", "что угодно", true), "маска: одиночная звёздочка", os);

    u64 sz = 0;
    check(parseSize("200M", sz) && sz == 200ull * 1024 * 1024, "разбор размера 200M", os);
    check(parseSize("1G", sz) && sz == 1024ull * 1024 * 1024, "разбор размера 1G", os);
    check(parseSize("4096", sz) && sz == 4096, "разбор размера без суффикса", os);
    check(!parseSize("abc", sz), "разбор размера: мусор отклонён", os);

    check(jsonEscape("a\"b\\c\nd") == "a\\\"b\\\\c\\nd", "экранирование JSON", os);
    check(htmlEscape("<a href='x'>&</a>").find('<') == std::string::npos,
          "экранирование HTML", os);
    check(csvEscape("a,b") == "\"a,b\"", "экранирование CSV", os);

    Severity s;
    check(parseSeverity("HIGH", s) && s == Severity::High, "разбор уровня критичности", os);
}

void testSniffer(std::ostream& os) {
    const u8 zip[] = {'P', 'K', 0x03, 0x04, 0, 0};
    check(sniffContentType(zip, sizeof(zip)).type != nullptr, "сигнатура ZIP распознана", os);

    const u8 ossl[] = {'S','a','l','t','e','d','_','_', 1,2,3,4};
    const SniffResult r = sniffContentType(ossl, sizeof(ossl));
    check(r.encrypted, "сигнатура OpenSSL enc помечена как шифрованная", os);

    const char* plain = "just a normal text file";
    check(sniffContentType(bytes(plain), std::strlen(plain)).type == nullptr,
          "текст не имеет двоичной сигнатуры", os);
    check(looksLikeText(bytes(plain), std::strlen(plain)), "эвристика текста", os);

    const u8 bin[] = {0x00, 0x01, 0x02, 0x00, 0xFF};
    check(!looksLikeText(bin, sizeof(bin)), "эвристика двоичных данных", os);
}

}

int runSelfTests(std::ostream& os) {
    g_failed = 0;
    g_total  = 0;

    os << tr(S::SelfTitle) << '\n'
       << "─────────────────────────────────────────────\n";

    testUtils(os);
    testLuhn(os);
    testIin(os);
    testEntropy(os);
    testPrefilter(os);
    testNumericScanner(os);
    testTokenScanner(os);
    testValidators(os);
    testRedaction(os);
    testRules(os);
    testSniffer(os);

    os << "─────────────────────────────────────────────\n";
    if (g_failed == 0) {
        os << trf(S::SelfPassed, g_total, g_total) << '\n';
    } else {
        os << trf(S::SelfFailed, g_total - g_failed, g_total, g_failed) << '\n';
    }
    return g_failed;
}

}
