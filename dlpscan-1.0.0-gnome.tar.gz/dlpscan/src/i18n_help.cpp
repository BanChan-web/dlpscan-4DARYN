#include "dlp/i18n.hpp"

namespace dlp {

namespace {

const char* const kHelpEn = R"DLPHELP(
USAGE
  dlpscan [PATH...] [OPTIONS]

  With no options the current directory is scanned. Several paths are allowed.

SCAN SCOPE
  -p, --path PATH         add a directory or file
  -e, --exclude MASK      exclude paths by mask (*, ?); repeatable
      --ext LIST          only these extensions (".log,.txt,.conf")
      --exclude-ext LIST  exclude extensions
      --max-size SIZE     skip files larger than this (default 256M)
      --min-size SIZE     skip files smaller than this
      --max-depth N       limit recursion depth
      --follow-symlinks   follow symbolic links
      --no-skip-noise     do not skip .git, node_modules, WinSxS and media files

DETECTION METHODS
      --no-signatures     disable regular-expression search
      --no-numeric        disable card (Luhn) and IIN checks
      --no-entropy        disable file entropy analysis
      --no-tokens         disable high-entropy string search
      --no-binary         do not apply signatures to binary files
      --entropy-threshold X  "encryption" threshold, bits/byte (default 7.2)
      --entropy-window N  sliding window size in bytes (8192)
      --token-entropy X   token entropy threshold (4.2)
      --token-min-len N   minimum token length (24)
      --iin-context       report IIN only next to an explanatory word
      --report-test-cards include known test card numbers

RULES
      --rules FILE        load custom rules (ini format)
      --only ID           use only rules with this id (masks, repeatable)
      --disable ID        disable a rule (masks, repeatable)
      --list-rules        show active rules and exit

PERFORMANCE
  -j, --threads N         thread count (default: number of cores)
      --map-limit SIZE    map files whole up to this size (512M)
      --chunk SIZE        block size for streaming reads (8M)

OUTPUT
      --json FILE         save a JSON report
      --csv FILE          save a CSV report (Excel compatible)
      --html FILE         save an interactive HTML report
      --min-severity LVL  output threshold: info|low|medium|high|critical
      --fail-on LVL       exit code 1 if findings of this level exist
      --show-all          do not collapse long console lists
      --no-redact         show secrets in full (DANGEROUS)
      --no-color          disable colour output
      --no-progress       do not show the progress indicator
  -q, --quiet             summary only
  -v, --verbose           verbose output

LANGUAGE
      --lang CODE         interface language: en | ru | kk
                          (default: taken from the system locale)

OTHER
      --selftest          run the built-in algorithm tests
  -h, --help              this help
      --version           version
)DLPHELP";

const char* const kHelpRu = R"DLPHELP(
ИСПОЛЬЗОВАНИЕ
  dlpscan [ПУТЬ...] [ПАРАМЕТРЫ]

  Без параметров сканируется текущий каталог. Путей можно указать несколько.

ОБЛАСТЬ СКАНИРОВАНИЯ
  -p, --path ПУТЬ         добавить каталог или файл
  -e, --exclude МАСКА     исключить пути по маске (*, ?); можно повторять
      --ext СПИСОК        только эти расширения (".log,.txt,.conf")
      --exclude-ext СПИСОК исключить расширения
      --max-size РАЗМЕР   пропускать файлы крупнее (по умолчанию 256M)
      --min-size РАЗМЕР   пропускать файлы мельче
      --max-depth N       ограничить глубину рекурсии
      --follow-symlinks   переходить по символическим ссылкам
      --no-skip-noise     не пропускать .git, node_modules, WinSxS и медиафайлы

МЕТОДЫ ОБНАРУЖЕНИЯ
      --no-signatures     отключить поиск по регулярным выражениям
      --no-numeric        отключить проверку карт (Луна) и ИИН
      --no-entropy        отключить энтропийный анализ файлов
      --no-tokens         отключить поиск высокоэнтропийных строк
      --no-binary         не применять сигнатуры к двоичным файлам
      --entropy-threshold X  порог «шифрования», бит/байт (по умолчанию 7.2)
      --entropy-window N  размер скользящего окна в байтах (8192)
      --token-entropy X   порог энтропии токена (4.2)
      --token-min-len N   минимальная длина токена (24)
      --iin-context       сообщать об ИИН только рядом с поясняющим словом
      --report-test-cards включать заведомо тестовые номера карт

ПРАВИЛА
      --rules ФАЙЛ        подключить пользовательские правила (ini-формат)
      --only ID           использовать только правила с этим id (маски, повторяемо)
      --disable ID        отключить правило (маски, повторяемо)
      --list-rules        показать активные правила и выйти

ПРОИЗВОДИТЕЛЬНОСТЬ
  -j, --threads N         число потоков (по умолчанию — по числу ядер)
      --map-limit РАЗМЕР  до какого размера отображать файл целиком (512M)
      --chunk РАЗМЕР      размер блока при потоковом чтении (8M)

ВЫВОД
      --json ФАЙЛ         сохранить отчёт в JSON
      --csv ФАЙЛ          сохранить отчёт в CSV (совместим с Excel)
      --html ФАЙЛ         сохранить интерактивный HTML-отчёт
      --min-severity УР.  порог вывода: info|low|medium|high|critical
      --fail-on УР.       код возврата 1, если есть находки этого уровня
      --show-all          не сворачивать длинный список в консоли
      --no-redact         показывать секреты целиком (ОПАСНО)
      --no-color          отключить цветовое оформление
      --no-progress       не показывать индикатор выполнения
  -q, --quiet             только итоговая сводка
  -v, --verbose           подробный вывод

ЯЗЫК
      --lang КОД          язык интерфейса: en | ru | kk
                          (по умолчанию — из системной локали)

ПРОЧЕЕ
      --selftest          прогнать встроенные тесты алгоритмов
  -h, --help              эта справка
      --version           версия

КОДЫ ВОЗВРАТА
  0 — находок выше порога --fail-on нет
  1 — найдены чувствительные данные
  2 — ошибка параметров или доступа
  3 — самотестирование не пройдено

ПРИМЕРЫ
  dlpscan C:\Users\Public --html report.html
  dlpscan D:\ --ext .log,.txt,.csv --min-severity high -j 16
  dlpscan . --disable email_address --disable kz_phone --json out.json
  dlpscan \\server\share --max-size 50M --exclude "*\backup\*" --quiet
)DLPHELP";

const char* const kHelpKk = R"DLPHELP(
ҚОЛДАНЫЛУЫ
  dlpscan [ЖОЛ...] [ПАРАМЕТРЛЕР]

  Параметрсіз ағымдағы каталог сканерленеді. Бірнеше жол көрсетуге болады.

СКАНЕРЛЕУ АУҚЫМЫ
  -p, --path ЖОЛ          каталог немесе файл қосу
  -e, --exclude МАСКА     жолдарды маска бойынша алып тастау (*, ?); қайталанады
      --ext ТІЗІМ         тек осы кеңейтімдер (".log,.txt,.conf")
      --exclude-ext ТІЗІМ кеңейтімдерді алып тастау
      --max-size ӨЛШЕМ    үлкенірек файлдарды өткізу (әдепкі 256M)
      --min-size ӨЛШЕМ    кішірек файлдарды өткізу
      --max-depth N       рекурсия тереңдігін шектеу
      --follow-symlinks   символдық сілтемелермен жүру
      --no-skip-noise     .git, node_modules, WinSxS және медиа файлдарды өткізбеу

АНЫҚТАУ ӘДІСТЕРІ
      --no-signatures     тұрақты өрнектермен іздеуді өшіру
      --no-numeric        карта (Луна) және ЖСН тексеруін өшіру
      --no-entropy        файл энтропиясын талдауды өшіру
      --no-tokens         жоғары энтропиялы жолдарды іздеуді өшіру
      --no-binary         екілік файлдарға сигнатураларды қолданбау
      --entropy-threshold X  "шифрлау" шегі, бит/байт (әдепкі 7.2)
      --entropy-window N  жылжымалы терезе өлшемі, байт (8192)
      --token-entropy X   токен энтропиясының шегі (4.2)
      --token-min-len N   токеннің ең аз ұзындығы (24)
      --iin-context       ЖСН туралы тек түсіндірме сөз жанында хабарлау
      --report-test-cards белгілі сынақ карта нөмірлерін қосу

ЕРЕЖЕЛЕР
      --rules ФАЙЛ        пайдаланушы ережелерін қосу (ini пішімі)
      --only ID           тек осы id бар ережелерді қолдану (маскалар, қайталанады)
      --disable ID        ережені өшіру (маскалар, қайталанады)
      --list-rules        белсенді ережелерді көрсетіп шығу

ӨНІМДІЛІК
  -j, --threads N         ағындар саны (әдепкі: ядролар саны бойынша)
      --map-limit ӨЛШЕМ   қай өлшемге дейін файлды толық бейнелеу (512M)
      --chunk ӨЛШЕМ       ағынды оқу кезіндегі блок өлшемі (8M)

ШЫҒАРУ
      --json ФАЙЛ         есепті JSON пішімінде сақтау
      --csv ФАЙЛ          есепті CSV пішімінде сақтау (Excel үйлесімді)
      --html ФАЙЛ         интерактивті HTML есебін сақтау
      --min-severity ДЕҢ. шығару шегі: info|low|medium|high|critical
      --fail-on ДЕҢ.      осы деңгейдегі деректер болса, қайтару коды 1
      --show-all          консольдегі ұзын тізімді жинамау
      --no-redact         құпияларды толық көрсету (ҚАУІПТІ)
      --no-color          түстік безендіруді өшіру
      --no-progress       орындалу индикаторын көрсетпеу
  -q, --quiet             тек қорытынды
  -v, --verbose           толық шығару

ТІЛ
      --lang КОД          интерфейс тілі: en | ru | kk
                          (әдепкі: жүйелік локальдан алынады)

БАСҚА
      --selftest          кірістірілген алгоритм сынақтарын орындау
  -h, --help              осы анықтама
      --version           нұсқа
)DLPHELP";

}

const char* helpText() noexcept {
    switch (language()) {
        case Lang::Ru: return kHelpRu;
        case Lang::Kk: return kHelpKk;
        case Lang::En: break;
    }
    return kHelpEn;
}

}
