#include "dlp/i18n.hpp"
#include "dlp/cli.hpp"

#include "dlp/thread_pool.hpp"

#include <cstdlib>
#include <cstring>
#include <ostream>

namespace dlp {

void printVersion(std::ostream& os) {
    os << "dlpscan " << kVersion << tr(S::CliSubtitle) << '\n'
       << tr(S::CliTagline) << '\n';
}

void printHelp(std::ostream& os) {
    printVersion(os);
    os << helpText();
}

namespace {

bool needValue(const char* opt, int& i, int argc, char** argv, std::string& out,
               std::string& error) {
    if (i + 1 >= argc) {
        error = std::string("параметр ") + opt + " требует значение";
        return false;
    }
    out = argv[++i];
    return true;
}

std::vector<std::string> normalizeExtList(const std::string& raw) {
    std::vector<std::string> out;
    for (std::string e : splitAndTrim(raw, ',')) {
        if (!e.empty() && e[0] != '.') e.insert(e.begin(), '.');
        out.push_back(toLowerAscii(e));
    }
    return out;
}

}

CliResult parseCommandLine(int argc, char** argv) {
    CliResult r;
    ScanConfig& c = r.config;
    c.color    = stdoutIsTty();
    c.progress = stdoutIsTty();

    std::string v;

    for (int i = 1; i < argc; ++i) {
        const std::string a = argv[i];
        auto fail = [&](const std::string& msg) {
            r.action = CliAction::Error;
            r.error = msg;
        };

        if (a == "-h" || a == "--help")     { r.action = CliAction::Help; return r; }
        if (a == "--version")               { r.action = CliAction::Version; return r; }
        if (a == "--selftest")              { r.action = CliAction::SelfTest; return r; }
        if (a == "--list-rules")            { r.action = CliAction::ListRules; continue; }

        if (a == "-p" || a == "--path") {
            if (!needValue("--path", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.roots.push_back(utf8ToPath(v));
        } else if (a == "-e" || a == "--exclude") {
            if (!needValue("--exclude", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.excludeGlobs.push_back(v);
        } else if (a == "--ext") {
            if (!needValue("--ext", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            for (auto& e : normalizeExtList(v)) c.includeExts.push_back(e);
        } else if (a == "--exclude-ext") {
            if (!needValue("--exclude-ext", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            for (auto& e : normalizeExtList(v)) c.excludeExts.push_back(e);
        } else if (a == "--max-size") {
            if (!needValue("--max-size", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            if (!parseSize(v, c.maxFileSize)) { fail(trf(S::CliBadSize, v.c_str())); return r; }
        } else if (a == "--min-size") {
            if (!needValue("--min-size", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            if (!parseSize(v, c.minFileSize)) { fail(trf(S::CliBadSize, v.c_str())); return r; }
        } else if (a == "--max-depth") {
            if (!needValue("--max-depth", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.maxDepth = std::atoi(v.c_str());
        } else if (a == "--follow-symlinks") {
            c.followSymlinks = true;
        } else if (a == "--no-skip-noise") {
            c.skipDefaultNoise = false;
        } else if (a == "--no-signatures") {
            c.useSignatures = false;
        } else if (a == "--no-numeric") {
            c.useNumeric = false;
        } else if (a == "--no-entropy") {
            c.useEntropy = false;
        } else if (a == "--no-tokens") {
            c.useEntropyTokens = false;
        } else if (a == "--no-binary") {
            c.scanBinary = false;
        } else if (a == "--entropy-threshold") {
            if (!needValue("--entropy-threshold", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.entropyThreshold = std::atof(v.c_str());
            if (c.entropyThreshold <= 0.0 || c.entropyThreshold > 8.0) {
                fail(tr(S::CliBadEntropy)); return r;
            }
        } else if (a == "--entropy-window") {
            if (!needValue("--entropy-window", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            u64 w = 0;
            if (!parseSize(v, w) || w < 256) { fail(tr(S::CliBadWindow)); return r; }
            c.entropyWindow = static_cast<std::size_t>(w);
            c.entropyStep   = c.entropyWindow / 2;
        } else if (a == "--token-entropy") {
            if (!needValue("--token-entropy", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.tokenEntropyMin = std::atof(v.c_str());
        } else if (a == "--token-min-len") {
            if (!needValue("--token-min-len", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.tokenMinLen = static_cast<std::size_t>(std::atoi(v.c_str()));
            if (c.tokenMinLen < 8) { fail(tr(S::CliBadTokenLen)); return r; }
        } else if (a == "--iin-context") {
            c.iinRequireContext = true;
        } else if (a == "--report-test-cards") {
            c.reportTestCards = true;
        } else if (a == "--rules") {
            if (!needValue("--rules", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.rulesFile = v;
        } else if (a == "--only") {
            if (!needValue("--only", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            for (auto& id : splitAndTrim(v, ',')) c.onlyRules.push_back(id);
        } else if (a == "--disable") {
            if (!needValue("--disable", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            for (auto& id : splitAndTrim(v, ',')) c.disabledRules.push_back(id);
        } else if (a == "-j" || a == "--threads") {
            if (!needValue("--threads", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            const int n = std::atoi(v.c_str());
            if (n < 1 || n > 1024) { fail(tr(S::CliBadThreads)); return r; }
            c.threads = static_cast<unsigned>(n);
        } else if (a == "--map-limit") {
            if (!needValue("--map-limit", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            if (!parseSize(v, c.mapLimit)) { fail(trf(S::CliBadSize, v.c_str())); return r; }
        } else if (a == "--chunk") {
            if (!needValue("--chunk", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            u64 ch = 0;
            if (!parseSize(v, ch) || ch < 64 * 1024) { fail(tr(S::CliBadChunk)); return r; }
            c.chunkSize = static_cast<std::size_t>(ch);
        } else if (a == "--json") {
            if (!needValue("--json", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.jsonOut = v;
        } else if (a == "--csv") {
            if (!needValue("--csv", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.csvOut = v;
        } else if (a == "--html") {
            if (!needValue("--html", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            c.htmlOut = v;
        } else if (a == "--min-severity") {
            if (!needValue("--min-severity", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            if (!parseSeverity(v, c.minSeverity)) { fail(trf(S::CliBadSeverity, v.c_str())); return r; }
        } else if (a == "--fail-on") {
            if (!needValue("--fail-on", i, argc, argv, v, r.error)) { r.action = CliAction::Error; return r; }
            if (!parseSeverity(v, c.failOn)) { fail(trf(S::CliBadSeverity, v.c_str())); return r; }
        } else if (a == "--show-all") {
            c.showAllFindings = true;
        } else if (a == "--no-redact") {
            c.redact = false;
        } else if (a == "--no-color") {
            c.color = false;
        } else if (a == "--no-progress") {
            c.progress = false;
        } else if (a == "-q" || a == "--quiet") {
            c.quiet = true;
            c.progress = false;
        } else if (a == "-v" || a == "--verbose") {
            c.verbose = true;
        } else if (!a.empty() && a[0] == '-' && a != "-") {
            Lang lang;
            if (a == "--lang") {
                if (!needValue("--lang", i, argc, argv, v, r.error)) {
                    r.action = CliAction::Error;
                    return r;
                }
                if (!parseLang(v, lang)) { fail(trf(S::CliBadLang, v.c_str())); return r; }
                setLanguage(lang);
                c.lang = v;
                continue;
            }
            fail(trf(S::CliUnknownOption, a.c_str()));
            return r;
        } else {
            c.roots.push_back(utf8ToPath(a));
        }
    }

    if (c.roots.empty()) c.roots.push_back(fs::current_path());
    if (c.threads == 0)  c.threads = defaultThreadCount();
    return r;
}

}
