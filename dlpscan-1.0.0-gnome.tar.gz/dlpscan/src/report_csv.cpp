#include "dlp/i18n.hpp"
#include "dlp/report.hpp"

#include <fstream>
#include <iomanip>

namespace dlp {

std::string csvEscape(std::string_view s) {
    const bool needQuotes = s.find_first_of(",\";\n\r") != std::string_view::npos;
    if (!needQuotes) return std::string(s);
    std::string out;
    out.reserve(s.size() + 8);
    out += '"';
    for (char c : s) {
        if (c == '"') out += "\"\"";
        else if (c == '\n' || c == '\r') out += ' ';
        else out += c;
    }
    out += '"';
    return out;
}

bool writeCsvReport(const ScanSummary& s, const fs::path& path, std::string& error) {
    std::ofstream out(path, std::ios::binary);
    if (!out) {
        error = trf(S::ErrCannotCreate, pathToUtf8(path).c_str());
        return false;
    }

    out << "\xEF\xBB\xBF";
    out << "severity,rule_id,rule_name,method,file,line,column,offset,entropy,"
           "fingerprint,note,preview\r\n";

    out << std::fixed << std::setprecision(3);
    for (const Finding& f : s.findings) {
        out << severityName(f.severity) << ','
            << csvEscape(f.ruleId)      << ','
            << csvEscape(f.ruleName)    << ','
            << methodName(f.method)     << ','
            << csvEscape(f.file)        << ','
            << f.line                   << ','
            << f.column                 << ','
            << f.offset                 << ','
            << f.entropy                << ','
            << f.fingerprint            << ','
            << csvEscape(f.note)        << ','
            << csvEscape(f.preview)     << "\r\n";
    }

    if (!out) { error = trf(S::ErrWriteFailed, pathToUtf8(path).c_str()); return false; }
    return true;
}

}
