#include "dlp/i18n.hpp"
#include "dlp/scan_runner.hpp"

#include "dlp/cli.hpp"
#include "dlp/file_walker.hpp"
#include "dlp/rules.hpp"
#include "dlp/scanner.hpp"
#include "dlp/thread_pool.hpp"

#include <algorithm>
#include <vector>

namespace dlp {

const char* runStateName(RunState s) noexcept {
    switch (s) {
        case RunState::Idle:      return "idle";
        case RunState::Running:   return "running";
        case RunState::Done:      return "done";
        case RunState::Cancelled: return "cancelled";
        case RunState::Failed:    return "failed";
    }
    return "idle";
}

ScanRunner::ScanRunner() : stats_(std::make_unique<ScanStats>()) {}

ScanRunner::~ScanRunner() {

    cancel();
    if (worker_.joinable()) worker_.join();
}

void ScanRunner::start(ScanConfig cfg) {
    if (worker_.joinable()) worker_.join();

    stats_ = std::make_unique<ScanStats>();
    sink_  = std::make_unique<FindingSink>(cfg.maxFindings ? cfg.maxFindings : 200000);
    {
        std::lock_guard<std::mutex> lk(summaryMtx_);
        summary_.reset();
    }
    {
        std::lock_guard<std::mutex> lk(errorMtx_);
        error_.clear();
    }
    cancelRequested_.store(false);
    elapsedAtEnd_.store(0.0);
    startTime_    = std::chrono::steady_clock::now();
    startedAtIso_ = nowIso8601Utc();
    state_.store(RunState::Running);

    worker_ = std::thread(&ScanRunner::runBody, this, std::move(cfg));
}

void ScanRunner::cancel() noexcept {
    cancelRequested_.store(true);
}

std::vector<Finding> ScanRunner::liveFindings() const {
    return sink_ ? sink_->snapshot() : std::vector<Finding>{};
}

std::shared_ptr<const ScanSummary> ScanRunner::summary() const {
    std::lock_guard<std::mutex> lk(summaryMtx_);
    return summary_;
}

double ScanRunner::elapsedSeconds() const {
    if (state_.load() == RunState::Running) {
        return std::chrono::duration<double>(
            std::chrono::steady_clock::now() - startTime_).count();
    }
    return elapsedAtEnd_.load();
}

std::string ScanRunner::errorMessage() const {
    std::lock_guard<std::mutex> lk(errorMtx_);
    return error_;
}

void ScanRunner::runBody(ScanConfig cfg) {
    RuleSet rules;
    rules.loadDefaults();

    if (!cfg.rulesFile.empty()) {
        std::string err;
        if (!rules.loadFromFile(utf8ToPath(cfg.rulesFile), err)) {
            std::lock_guard<std::mutex> lk(errorMtx_);
            error_ = trf(S::ErrCustomRules, err.c_str());
            state_.store(RunState::Failed);
            return;
        }
    }
    rules.applyFilters(cfg.onlyRules, cfg.disabledRules);

    {
        std::string err;
        if (!rules.compile(err)) {
            std::lock_guard<std::mutex> lk(errorMtx_);
            error_ = trf(S::ErrRuleCompile, err.c_str());
            state_.store(RunState::Failed);
            return;
        }
    }

    const unsigned threads = cfg.threads ? cfg.threads : defaultThreadCount();

    Scanner scanner(rules, cfg, *stats_);
    BoundedQueue<FileTask> queue(cfg.queueCapacity ? cfg.queueCapacity : 4096);

    std::mutex errMtx;
    std::vector<std::string> ioErrors;

    auto workerFn = [&]() {
        ScanContext ctx;
        FileTask task;
        while (queue.pop(task)) {
            if (cancelRequested_.load()) break;
            ctx.out.clear();
            std::string e;
            if (!scanner.scanFile(task.path, ctx, e)) {
                stats_->filesUnreadable.fetch_add(1, std::memory_order_relaxed);
                std::lock_guard<std::mutex> lk(errMtx);
                if (ioErrors.size() < 200) {
                    ioErrors.push_back(pathToUtf8(task.path) + ": " + e);
                }
                continue;
            }
            sink_->addBatch(ctx.out);
        }
    };

    std::vector<std::thread> pool;
    pool.reserve(threads);
    for (unsigned i = 0; i < threads; ++i) pool.emplace_back(workerFn);

    FileWalker walker(cfg, *stats_, cancelRequested_);
    std::thread producer([&]() {
        walker.run(queue);
        queue.close();
    });

    producer.join();
    for (std::thread& t : pool) if (t.joinable()) t.join();

    const double seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - startTime_).count();
    elapsedAtEnd_.store(seconds);

    auto sum = std::make_shared<ScanSummary>();
    sum->findings        = sink_->take();
    sum->config           = cfg;
    sum->seconds          = seconds;
    sum->filesScanned     = stats_->filesScanned.load();
    sum->filesSkipped     = stats_->filesSkipped.load();
    sum->filesUnreadable  = stats_->filesUnreadable.load();
    sum->bytesScanned     = stats_->bytesScanned.load();
    sum->regexRuns        = stats_->regexRuns.load();
    sum->prefilterHits    = stats_->prefilterHits.load();
    sum->threads          = threads;
    sum->ruleCount        = rules.enabledCount();
    sum->truncated        = sink_->truncated();
    sum->startedAt        = startedAtIso_;
    sum->version          = kVersion;

    sum->errors = walker.errors();
    {
        std::lock_guard<std::mutex> lk(errMtx);
        for (const std::string& e : ioErrors) sum->errors.push_back(e);
    }

    std::sort(sum->findings.begin(), sum->findings.end());

    {
        std::lock_guard<std::mutex> lk(summaryMtx_);
        summary_ = sum;
    }

    state_.store(cancelRequested_.load() ? RunState::Cancelled : RunState::Done);
}

}
