#include "dlp/i18n.hpp"
#include "dlp/report.hpp"

#include <cstdio>
#include <fstream>
#include <iomanip>
#include <sstream>

namespace dlp {

std::string jsonEscape(std::string_view s) {
    std::string out;
    out.reserve(s.size() + 16);
    for (const char rawChar : s) {
        const unsigned char c = static_cast<unsigned char>(rawChar);
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            case '\b': out += "\\b";  break;
            case '\f': out += "\\f";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

bool writeJsonReport(const ScanSummary& s, const fs::path& path, std::string& error) {
    std::ofstream out(path, std::ios::binary);
    if (!out) {
        error = trf(S::ErrCannotCreate, pathToUtf8(path).c_str());
        return false;
    }

    const auto hist = severityHistogram(s.findings);
    out << std::fixed << std::setprecision(3);

    out << "{\n";
    out << "  \"tool\": \"dlpscan\",\n";
    out << "  \"version\": \"" << jsonEscape(s.version) << "\",\n";
    out << "  \"started_at\": \"" << jsonEscape(s.startedAt) << "\",\n";
    out << "  \"duration_seconds\": " << s.seconds << ",\n";

    out << "  \"scope\": {\n";
    out << "    \"roots\": [";
    for (std::size_t i = 0; i < s.config.roots.size(); ++i) {
        out << (i ? ", " : "") << '"' << jsonEscape(pathToUtf8(s.config.roots[i])) << '"';
    }
    out << "],\n";
    out << "    \"rules_enabled\": " << s.ruleCount << ",\n";
    out << "    \"threads\": " << s.threads << ",\n";
    out << "    \"entropy_threshold\": " << s.config.entropyThreshold << "\n";
    out << "  },\n";

    out << "  \"stats\": {\n";
    out << "    \"files_scanned\": " << s.filesScanned << ",\n";
    out << "    \"files_skipped\": " << s.filesSkipped << ",\n";
    out << "    \"files_unreadable\": " << s.filesUnreadable << ",\n";
    out << "    \"bytes_scanned\": " << s.bytesScanned << ",\n";
    out << "    \"prefilter_hits\": " << s.prefilterHits << ",\n";
    out << "    \"regex_runs\": " << s.regexRuns << ",\n";
    out << "    \"truncated\": " << (s.truncated ? "true" : "false") << "\n";
    out << "  },\n";

    out << "  \"summary\": {\n";
    out << "    \"critical\": " << hist[4] << ",\n";
    out << "    \"high\": "     << hist[3] << ",\n";
    out << "    \"medium\": "   << hist[2] << ",\n";
    out << "    \"low\": "      << hist[1] << ",\n";
    out << "    \"info\": "     << hist[0] << ",\n";
    out << "    \"total\": "    << s.findings.size() << "\n";
    out << "  },\n";

    out << "  \"findings\": [\n";
    for (std::size_t i = 0; i < s.findings.size(); ++i) {
        const Finding& f = s.findings[i];
        out << "    {"
            << "\"file\": \""        << jsonEscape(f.file) << "\", "
            << "\"rule_id\": \""     << jsonEscape(f.ruleId) << "\", "
            << "\"rule_name\": \""   << jsonEscape(f.ruleName) << "\", "
            << "\"severity\": \""    << severityName(f.severity) << "\", "
            << "\"method\": \""      << methodName(f.method) << "\", "
            << "\"line\": "          << f.line << ", "
            << "\"column\": "        << f.column << ", "
            << "\"offset\": "        << f.offset << ", "
            << "\"length\": "        << f.length << ", "
            << "\"entropy\": "       << f.entropy << ", "
            << "\"fingerprint\": \"" << jsonEscape(f.fingerprint) << "\", "
            << "\"note\": \""        << jsonEscape(f.note) << "\", "
            << "\"preview\": \""     << jsonEscape(f.preview) << "\"}"
            << (i + 1 < s.findings.size() ? ",\n" : "\n");
    }
    out << "  ],\n";

    out << "  \"errors\": [";
    for (std::size_t i = 0; i < s.errors.size(); ++i) {
        out << (i ? ", " : "") << '"' << jsonEscape(s.errors[i]) << '"';
    }
    out << "]\n";
    out << "}\n";

    if (!out) { error = trf(S::ErrWriteFailed, pathToUtf8(path).c_str()); return false; }
    return true;
}

}
