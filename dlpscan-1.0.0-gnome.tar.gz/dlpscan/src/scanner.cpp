#include "dlp/i18n.hpp"
#include "dlp/scanner.hpp"

#include "dlp/entropy.hpp"
#include "dlp/file_source.hpp"
#include "dlp/redact.hpp"
#include "dlp/validators.hpp"

#include <algorithm>
#include <cstring>

namespace dlp {

namespace {

inline u64 dedupKey(std::string_view ruleId, u64 offset) noexcept {
    const u64 a = fnv1a64(ruleId.data(), ruleId.size());
    return a ^ (offset * 1099511628211ull);
}

const char* kTextExts[] = {
    ".txt", ".log", ".csv", ".tsv", ".json", ".xml", ".yml", ".yaml", ".ini",
    ".conf", ".cfg", ".md", ".rst", ".html", ".htm", ".sql", ".env", ".sh",
    ".bat", ".ps1", ".py", ".js", ".ts", ".java", ".cs", ".php", ".rb", ".go",
    ".c", ".h", ".cpp", ".hpp", ".properties", ".list", ".srt", ".sub", ".po",
};

struct ExtType { const char* ext; const char* type; };
const ExtType kExtTypes[] = {
    {".zip", "ZIP/OOXML"}, {".docx", "ZIP/OOXML"}, {".xlsx", "ZIP/OOXML"},
    {".pptx", "ZIP/OOXML"}, {".jar", "ZIP/OOXML"}, {".apk", "ZIP/OOXML"},
    {".odt", "ZIP/OOXML"}, {".epub", "ZIP/OOXML"},
    {".gz", "GZIP"}, {".tgz", "GZIP"}, {".xz", "XZ"}, {".bz2", "BZIP2"},
    {".zst", "Zstandard"}, {".7z", "7-Zip"}, {".rar", "RAR"},
    {".pdf", "PDF"}, {".png", "PNG"}, {".jpg", "JPEG"}, {".jpeg", "JPEG"},
    {".gif", "GIF"}, {".exe", "PE/EXE"}, {".dll", "PE/EXE"}, {".sys", "PE/EXE"},
    {".doc", "MS Office (OLE2)"}, {".xls", "MS Office (OLE2)"},
    {".ppt", "MS Office (OLE2)"}, {".db", "SQLite DB"}, {".sqlite", "SQLite DB"},
    {".ttf", "TrueType font"}, {".otf", "TrueType font"},
};

bool isMarkerRule(std::string_view id) noexcept {
    return id == "private_key_pem" || id == "putty_private_key" ||
           id == "pgp_block" || id == "gcp_service_account";
}

}

const char* methodName(Method m) noexcept {
    switch (m) {
        case Method::Signature: return "signature";
        case Method::Checksum:  return "checksum";
        case Method::Entropy:   return "entropy";
    }
    return "signature";
}

bool isTextExtension(std::string_view ext) noexcept {
    for (const char* e : kTextExts) if (iequalsAscii(ext, e)) return true;
    return false;
}

const char* expectedTypeForExtension(std::string_view ext) noexcept {
    for (const ExtType& t : kExtTypes) if (iequalsAscii(ext, t.ext)) return t.type;
    return nullptr;
}

bool Scanner::emit(Finding&& f, ScanContext& ctx, FileState& st) {
    if (static_cast<int>(f.severity) < static_cast<int>(cfg_.minSeverity)) return false;
    if (st.perFile >= cfg_.maxFindingsPerFile) return false;

    const u64 key = dedupKey(f.ruleId, f.offset);
    if (!ctx.seen.insert(key).second) return false;

    f.file = st.utf8Path;
    f.fingerprint = toHex64(fnv1a64(f.preview.data(), f.preview.size()) ^
                            fnv1a64(f.ruleId.data(), f.ruleId.size()) ^
                            fnv1a64(st.utf8Path.data(), st.utf8Path.size()));
    ctx.out.push_back(std::move(f));
    ++st.perFile;
    stats_.findings.fetch_add(1, std::memory_order_relaxed);
    return true;
}

void Scanner::assignLines(const u8* data, std::size_t n, u64 base, ScanContext& ctx,
                          FileState& st, std::size_t firstIdx) {
    if (firstIdx >= ctx.out.size()) return;

    std::sort(ctx.out.begin() + static_cast<std::ptrdiff_t>(firstIdx), ctx.out.end(),
              [](const Finding& a, const Finding& b) { return a.offset < b.offset; });

    u64 pos = std::max<u64>(st.lineCountedUpTo, base);
    if (pos < base || pos > base + n) pos = base;

    for (std::size_t i = firstIdx; i < ctx.out.size(); ++i) {
        Finding& f = ctx.out[i];
        if (f.offset < pos) {
            f.line = st.lineBase;
            f.column = 1;
            continue;
        }
        const std::size_t from = static_cast<std::size_t>(pos - base);
        const std::size_t to   = static_cast<std::size_t>(
            std::min<u64>(f.offset, base + n) - base);
        for (std::size_t k = from; k < to; ++k) {
            if (data[k] == '\n') {
                ++st.lineBase;
                st.lastLineStart = base + k + 1;
            }
        }
        pos = f.offset;
        f.line = st.lineBase;
        f.column = f.offset >= st.lastLineStart ? (f.offset - st.lastLineStart + 1) : 1;
    }
    st.lineCountedUpTo = pos;
}

void Scanner::runSignatures(const u8* data, std::size_t n, u64 base,
                            ScanContext& ctx, FileState& st) {
    const std::vector<Rule>& rules = rules_.rules();
    ctx.hits.clear();
    ctx.ruleNextAllowed.assign(rules.size(), 0);

    rules_.prefilter().scan(data, n, [&](int ruleIdx, std::size_t endPos) {
        ctx.hits.emplace_back(ruleIdx, endPos);
    });
    if (!ctx.hits.empty()) {
        stats_.prefilterHits.fetch_add(ctx.hits.size(), std::memory_order_relaxed);
    }

    const char* cdata = reinterpret_cast<const char*>(data);

    ctx.candidates.clear();

    auto tryRule = [&](const Rule& r, int ruleIdx, std::size_t wStart, std::size_t wEnd) {
        stats_.regexRuns.fetch_add(1, std::memory_order_relaxed);
        const char* b = cdata + wStart;
        const char* e = cdata + wEnd;

        auto it  = std::cregex_iterator(b, e, r.re);
        const auto end = std::cregex_iterator();
        for (; it != end; ++it) {
            const std::cmatch& m = *it;
            const std::size_t gi =
                (r.captureGroup > 0 && static_cast<std::size_t>(r.captureGroup) < m.size())
                    ? static_cast<std::size_t>(r.captureGroup)
                    : std::size_t{0};
            if (!m[gi].matched) continue;

            const std::string secret = m[gi].str();
            const std::string whole  = m[0].str();
            if (secret.empty()) continue;

            double ent = tokenEntropy(secret);
            switch (r.validator) {
                case Validator::Jwt:
                    if (!jwtStructureValid(whole)) continue;
                    break;
                case Validator::Iban:
                    if (!ibanValid(whole)) continue;
                    break;
                case Validator::Entropy:
                    if (ent < r.entropyMin) continue;
                    if (looksLikePlaceholder(secret)) continue;
                    break;
                case Validator::NotPlaceholder:
                    if (looksLikePlaceholder(secret)) continue;
                    break;
                case Validator::None:
                    break;
            }

            const std::size_t mStart = wStart + static_cast<std::size_t>(m.position(0));
            const std::size_t mLen   = static_cast<std::size_t>(m.length(0));
            const std::size_t sStart = wStart + static_cast<std::size_t>(m.position(gi));
            const std::size_t sLen   = static_cast<std::size_t>(m.length(gi));

            Finding f;
            f.ruleId   = r.id;
            f.ruleName = r.name;
            f.severity = r.severity;
            f.method   = Method::Signature;

            f.offset   = base + sStart;
            f.length   = sLen;
            f.entropy  = ent;
            f.preview  = buildPreview(data, n, sStart, sLen,
                                      (cfg_.redact && !isMarkerRule(r.id))
                                          ? redactSecret(secret) : secret);
            if (r.entropyMin > 0.0) {
                char buf[64];
                std::snprintf(buf, sizeof(buf), tr(S::NoteEntropyBits), ent);
                f.note = buf;
            }
            ctx.candidates.emplace_back(ruleIdx, std::move(f));
            ctx.covered.emplace_back(mStart, mStart + mLen);
            if (ctx.candidates.size() >= cfg_.maxFindingsPerFile * 4) return;
        }
    };

    for (const auto& [ruleIdx, endPos] : ctx.hits) {
        const Rule& r = rules[static_cast<std::size_t>(ruleIdx)];
        if (!r.enabled || !r.compiled) continue;

        const std::size_t wStart = (endPos > r.windowBefore) ? endPos - r.windowBefore : 0;
        const std::size_t wEnd   = std::min(n, endPos + r.windowAfter);
        if (wEnd <= ctx.ruleNextAllowed[static_cast<std::size_t>(ruleIdx)]) continue;

        const std::size_t effStart =
            std::max(wStart, ctx.ruleNextAllowed[static_cast<std::size_t>(ruleIdx)] > r.windowBefore
                                 ? ctx.ruleNextAllowed[static_cast<std::size_t>(ruleIdx)] - r.windowBefore
                                 : 0);
        tryRule(r, ruleIdx, std::min(effStart, wStart), wEnd);
        ctx.ruleNextAllowed[static_cast<std::size_t>(ruleIdx)] = wEnd;
        if (ctx.candidates.size() >= cfg_.maxFindingsPerFile * 4) break;
    }

    if (!rules_.heavyRules().empty() && n <= (1u << 20)) {
        for (int idx : rules_.heavyRules()) {
            const Rule& r = rules[static_cast<std::size_t>(idx)];
            if (!r.enabled || !r.compiled) continue;
            tryRule(r, idx, 0, n);
            if (ctx.candidates.size() >= cfg_.maxFindingsPerFile * 4) break;
        }
    }

    std::sort(ctx.candidates.begin(), ctx.candidates.end(),
              [](const std::pair<int, Finding>& a, const std::pair<int, Finding>& b) {
                  if (a.second.offset != b.second.offset) return a.second.offset < b.second.offset;
                  if (a.second.severity != b.second.severity) {
                      return static_cast<int>(a.second.severity) > static_cast<int>(b.second.severity);
                  }
                  return a.first < b.first;
              });

    u64 lastOffset = ~0ull;
    for (auto& [ruleIdx, f] : ctx.candidates) {
        (void)ruleIdx;
        if (f.offset == lastOffset) continue;
        lastOffset = f.offset;
        emit(std::move(f), ctx, st);
        if (st.perFile >= cfg_.maxFindingsPerFile) return;
    }
}

void Scanner::runNumeric(const u8* data, std::size_t n, u64 base,
                         ScanContext& ctx, FileState& st) {
    NumericOptions opt;
    ctx.numeric.clear();
    scanNumericRuns(data, n, opt, ctx.numeric);

    for (const NumericHit& h : ctx.numeric) {
        const std::string& d = h.digits;

        if (d.size() == 12) {
            IinInfo info;
            const bool iin = kzIinValid(d, &info);
            const bool bin = !iin && kzBinValid(d);
            if (!iin && !bin) continue;

            const bool ctxOk = hasIinContext(data, n, h.start);
            if (cfg_.iinRequireContext && !ctxOk) continue;

            Finding f;
            f.ruleId   = bin ? "kz_bin" : "kz_iin";
            f.ruleName = bin ? tr(S::RuleBin) : tr(S::RuleIin);
            f.severity = ctxOk ? Severity::High : Severity::Medium;
            f.method   = Method::Checksum;
            f.offset   = base + h.start;
            f.length   = h.length;
            f.preview  = buildPreview(data, n, h.start, h.length,
                                      cfg_.redact ? redactIin(d) : d);
            if (iin) {
                char buf[128];
                std::snprintf(buf, sizeof(buf),
                              tr(S::NoteIinOk),
                              info.day, info.month, info.year,
                              info.female ? tr(S::NoteSexFemale) : tr(S::NoteSexMale));
                f.note = buf;
            } else {
                f.note = tr(S::NoteBinOk);
            }
            if (!ctxOk) f.note += tr(S::NoteNoContextWord);
            emit(std::move(f), ctx, st);
            continue;
        }

        if (d.size() >= 13 && d.size() <= 19) {
            if (!luhnValid(d)) continue;
            const bool test = isKnownTestCard(d);
            if (test && !cfg_.reportTestCards) continue;

            const CardBrand brand = detectCardBrand(d);
            if (brand == CardBrand::Unknown && !hasSecretContext(data, n, h.start, 64)) {

                continue;
            }

            Finding f;
            f.ruleId   = "payment_card";
            f.ruleName = tr(S::RulePan);
            f.severity = test ? Severity::Info : Severity::Critical;
            f.method   = Method::Checksum;
            f.offset   = base + h.start;
            f.length   = h.length;
            f.preview  = buildPreview(data, n, h.start, h.length,
                                      cfg_.redact ? redactPan(d) : d);
            f.note = trf(S::NoteLuhnPassed, cardBrandName(brand));
            if (test) f.note += tr(S::NoteKnownTestCard);
            emit(std::move(f), ctx, st);
        }
        if (st.perFile >= cfg_.maxFindingsPerFile) return;
    }
}

void Scanner::runTokens(const u8* data, std::size_t n, u64 base,
                        ScanContext& ctx, FileState& st) {
    TokenOptions opt;
    opt.minLen     = cfg_.tokenMinLen;
    opt.minEntropy = cfg_.tokenEntropyMin;
    ctx.tokens.clear();
    scanEntropicTokens(data, n, opt, ctx.tokens);
    if (ctx.tokens.empty()) return;

    std::sort(ctx.covered.begin(), ctx.covered.end());

    for (const TokenHit& t : ctx.tokens) {

        bool inside = false;
        auto it = std::upper_bound(ctx.covered.begin(), ctx.covered.end(),
                                   std::make_pair(t.start, std::numeric_limits<std::size_t>::max()));
        if (it != ctx.covered.begin()) {
            --it;
            if (it->second > t.start) inside = true;
        }
        if (inside) continue;

        const std::string_view tok(reinterpret_cast<const char*>(data + t.start), t.length);
        if (looksLikePlaceholder(tok)) continue;

        const bool ctxOk = hasSecretContext(data, n, t.start);
        Finding f;
        f.ruleId   = "high_entropy_token";
        f.ruleName = tr(S::RuleHighEntropyToken);
        f.severity = ctxOk ? Severity::High : Severity::Medium;
        f.method   = Method::Entropy;
        f.offset   = base + t.start;

        const std::size_t shownLen = std::min(t.fullLength, n - t.start);
        f.length   = t.fullLength;
        f.entropy  = t.entropy;
        f.preview  = buildPreview(data, n, t.start, shownLen,
                                  cfg_.redact ? redactSecret(tok) : std::string(tok));

        char buf[160];
        if (t.fullLength > t.length) {
            std::snprintf(buf, sizeof(buf),
                          tr(S::NoteEntropyRun),
                          t.entropy, static_cast<unsigned long long>(t.fullLength));
        } else {
            std::snprintf(buf, sizeof(buf), tr(S::NoteEntropyLen),
                          t.entropy, static_cast<unsigned long long>(t.length));
        }
        f.note = buf;
        if (isBase64OfText(tok)) f.note += tr(S::NoteBase64Text);
        else if (isHexString(tok)) f.note += tr(S::NoteHexString);
        if (ctxOk) f.note += tr(S::NoteKeywordNearby);

        emit(std::move(f), ctx, st);
        if (st.perFile >= cfg_.maxFindingsPerFile) return;
    }
}

void Scanner::finalizeEntropy(const EntropyProfile& p, ScanContext& ctx, FileState& st) {
    const char* expected = expectedTypeForExtension(st.ext);
    const bool textExt   = isTextExtension(st.ext);
    const char* actual   = st.sniff.type;

    if (actual) {
        const bool mismatch =
            (expected && std::strcmp(expected, actual) != 0) || (textExt && !st.sniff.encrypted);
        if (mismatch) {
            Finding f;
            f.ruleId   = "type_mismatch";
            f.ruleName = tr(S::RuleTypeMismatch);
            f.severity = Severity::High;
            f.method   = Method::Entropy;
            f.offset   = 0;
            f.line = 1; f.column = 1;
            f.entropy  = p.fileEntropy;
            f.note = trf(S::NoteExtMismatch,
                         st.ext.empty() ? tr(S::NoteExtNone) : st.ext.c_str(),
                         std::string(actual).c_str());
            f.preview = trf(S::PreviewContentSig, std::string(actual).c_str());
            emit(std::move(f), ctx, st);
        }
        if (st.sniff.encrypted) {
            Finding f;
            f.ruleId   = "encrypted_container";
            f.ruleName = tr(S::RuleEncryptedContainer);
            f.severity = Severity::High;
            f.method   = Method::Entropy;
            f.offset   = 0;
            f.line = 1; f.column = 1;
            f.entropy  = p.fileEntropy;
            f.note     = trf(S::NoteFormat, std::string(actual).c_str());
            f.preview  = trf(S::PreviewEncrypted, std::string(actual).c_str());
            emit(std::move(f), ctx, st);
        }
        return;
    }

    if (p.fileEntropy >= cfg_.entropyThreshold) {
        Finding f;
        f.ruleId   = "encrypted_or_packed";
        f.ruleName = textExt ? tr(S::RuleEncryptedAsText) : tr(S::RuleNearMaxEntropy);
        f.severity = textExt ? Severity::High : Severity::Medium;
        f.method   = Method::Entropy;
        f.offset   = 0;
        f.line = 1; f.column = 1;
        f.entropy  = p.fileEntropy;

        char buf[192];
        std::snprintf(buf, sizeof(buf),
                      tr(S::NoteFileEntropy),
                      p.fileEntropy, cfg_.entropyThreshold, p.printableRatio * 100.0);
        f.note = buf;
        f.preview = tr(S::PreviewBinaryNoSig);
        emit(std::move(f), ctx, st);
        return;
    }

    if (p.maxWindowEntropy >= cfg_.entropyThreshold && p.windowsTotal > 1 && !st.binary) {
        Finding f;
        f.ruleId   = "high_entropy_region";
        f.ruleName = tr(S::RuleHighEntropyRegion);
        f.severity = Severity::Medium;
        f.method   = Method::Entropy;
        f.offset   = p.maxWindowOffset;
        f.entropy  = p.maxWindowEntropy;

        char buf[192];
        std::snprintf(buf, sizeof(buf),
                      tr(S::NoteEntropyWindow),
                      static_cast<unsigned long long>(cfg_.entropyWindow),
                      static_cast<unsigned long long>(p.maxWindowOffset),
                      p.maxWindowEntropy, p.fileEntropy);
        f.note = buf;
        f.preview = tr(S::PreviewRandomBytes);
        f.line = 0; f.column = 1;
        emit(std::move(f), ctx, st);
    }
}

void Scanner::scanChunk(const u8* data, std::size_t n, u64 base,
                        ScanContext& ctx, FileState& st) {
    const std::size_t firstIdx = ctx.out.size();
    ctx.covered.clear();

    if (!st.sniffed) {
        st.sniff   = sniffContentType(data, n);
        st.binary  = !looksLikeText(data, n);
        st.sniffed = true;
    }

    if (cfg_.useSignatures && (!st.binary || cfg_.scanBinary)) {
        runSignatures(data, n, base, ctx, st);
    }
    if (cfg_.useNumeric && (!st.binary || cfg_.scanBinary)) {
        runNumeric(data, n, base, ctx, st);
    }
    if (cfg_.useEntropyTokens && !st.binary) {
        runTokens(data, n, base, ctx, st);
    }

    assignLines(data, n, base, ctx, st, firstIdx);
}

bool Scanner::scanFile(const fs::path& path, ScanContext& ctx, std::string& error) {
    FileSource src;
    if (!src.open(path, cfg_.mapLimit, error)) return false;

    FileState st;
    st.utf8Path = pathToUtf8(path);
    st.ext      = toLowerAscii(pathToUtf8(path.extension()));

    ctx.seen.clear();

    EntropyProfiler prof(cfg_.entropyWindow, cfg_.entropyStep, cfg_.entropyThreshold);
    const bool wantEntropy = cfg_.useEntropy;

    FileSource::Chunk chunk;
    u64 consumed = 0;
    u64 totalBytes = 0;

    while (src.next(cfg_.chunkSize, cfg_.chunkOverlap, chunk, error)) {
        scanChunk(chunk.data, chunk.size, chunk.offset, ctx, st);

        if (wantEntropy) {
            const u64 newFrom = std::max(consumed, chunk.offset);
            if (newFrom < chunk.offset + chunk.size) {
                const std::size_t skip = static_cast<std::size_t>(newFrom - chunk.offset);
                prof.feed(chunk.data + skip, chunk.size - skip, newFrom);
            }
        }
        consumed = std::max(consumed, chunk.offset + chunk.size);
        totalBytes = consumed;

        if (st.perFile >= cfg_.maxFindingsPerFile) break;
    }
    if (!error.empty()) return false;

    if (wantEntropy && totalBytes > 0) {
        const EntropyProfile p = prof.finish();
        finalizeEntropy(p, ctx, st);
    }

    stats_.bytesScanned.fetch_add(totalBytes, std::memory_order_relaxed);
    stats_.filesScanned.fetch_add(1, std::memory_order_relaxed);
    return true;
}

}
