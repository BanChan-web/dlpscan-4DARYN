#include "dlp/i18n.hpp"
#include "dlp/rules.hpp"

#include <algorithm>
#include <fstream>
#include <sstream>

namespace dlp {

namespace {

struct RuleSpec {
    const char* id;
    const char* name;
    Severity    sev;
    const char* pattern;
    bool        icase;
    const char* keywords;
    Validator   validator;
    double      entropyMin;
    int         group;
    S           descId;
};

const RuleSpec kDefaultRules[] = {

{"aws_access_key", "AWS Access Key ID", Severity::Critical,
 R"((?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ABIA|ACCA)[0-9A-Z]{16})", false,
 "AKIA,ASIA,AGPA,AIDA,AROA,AIPA,ANPA,ANVA,ABIA,ACCA", Validator::None, 0.0, 0,
 S::RuleAwsAccessKeyId},

{"aws_secret_key", "AWS Secret Access Key", Severity::Critical,
 R"(aws[a-z_ .\-]{0,20}(?:secret|private)[a-z_ .\-]{0,20}['\"= :]{1,5}([A-Za-z0-9/+=]{40}))", true,
 "aws_secret,aws secret,awssecret,aws_private,secret_access_key", Validator::Entropy, 4.0, 1,
 S::RuleAwsSecretKey},

{"gcp_api_key", "Google API Key", Severity::High,
 R"(AIza[0-9A-Za-z_\-]{35})", false, "AIza", Validator::None, 0.0, 0,
 S::RuleGoogleApiKey},

{"gcp_service_account", "GCP Service Account Key", Severity::Critical,
 R"("type"\s*:\s*"service_account")", false, "service_account", Validator::None, 0.0, 0,
 S::RuleGcpServiceAccount},

{"azure_storage_key", "Azure Storage Account Key", Severity::Critical,
 R"(AccountKey\s*=\s*([A-Za-z0-9+/=]{64,100}))", true, "accountkey", Validator::Entropy, 4.5, 1,
 S::RuleAzureStorageKey},

{"github_token", "GitHub Token", Severity::Critical,
 R"(gh[pousr]_[A-Za-z0-9]{36,255})", false, "ghp_,gho_,ghu_,ghs_,ghr_", Validator::None, 0.0, 0,
 S::RuleGithubToken},

{"gitlab_pat", "GitLab Personal Access Token", Severity::Critical,
 R"(glpat-[A-Za-z0-9_\-]{20,})", false, "glpat-", Validator::None, 0.0, 0,
 S::RuleGitlabToken},

{"slack_token", "Slack Token", Severity::High,
 R"(xox[baprs]-[0-9A-Za-z\-]{10,72})", false, "xoxb-,xoxa-,xoxp-,xoxr-,xoxs-", Validator::None, 0.0, 0,
 S::RuleSlackToken},

{"slack_webhook", "Slack Webhook URL", Severity::Medium,
 R"(https://hooks\.slack\.com/services/T[0-9A-Za-z_\-]{6,}/B[0-9A-Za-z_\-]{6,}/[0-9A-Za-z_\-]{16,})", false,
 "hooks.slack.com", Validator::None, 0.0, 0, S::RuleSlackWebhook},

{"stripe_key", "Stripe Secret Key", Severity::Critical,
 R"((?:sk|rk)_(?:live|test)_[0-9A-Za-z]{16,99})", false, "sk_live_,sk_test_,rk_live_,rk_test_",
 Validator::None, 0.0, 0, S::RuleStripeKey},

{"openai_key", "OpenAI API Key", Severity::Critical,
 R"(sk-(?:proj-|svcacct-)?[A-Za-z0-9_\-]{20,})", false, "sk-", Validator::Entropy, 3.5, 0,
 S::RuleOpenaiKey},

{"anthropic_key", "Anthropic API Key", Severity::Critical,
 R"(sk-ant-[A-Za-z0-9_\-]{24,})", false, "sk-ant-", Validator::None, 0.0, 0,
 S::RuleAnthropicKey},

{"telegram_bot_token", "Telegram Bot Token", Severity::High,
 R"([0-9]{8,10}:AA[A-Za-z0-9_\-]{33})", false, ":aa", Validator::None, 0.0, 0,
 S::RuleTelegramToken},

{"sendgrid_key", "SendGrid API Key", Severity::High,
 R"(SG\.[A-Za-z0-9_\-]{20,24}\.[A-Za-z0-9_\-]{39,45})", false, "sg.", Validator::None, 0.0, 0,
 S::RuleSendgridKey},

{"twilio_key", "Twilio Account SID/Key", Severity::High,
 R"((?:AC|SK)[0-9a-fA-F]{32})", false, "ac,sk", Validator::None, 0.0, 0,
 S::RuleTwilioKey},

{"npm_token", "npm Access Token", Severity::High,
 R"(npm_[A-Za-z0-9]{36})", false, "npm_", Validator::None, 0.0, 0, S::RuleNpmToken},

{"docker_auth", "Docker Registry Auth", Severity::High,
 R"("auth"\s*:\s*"([A-Za-z0-9+/=]{20,}))", false, "\"auth\"", Validator::Entropy, 3.5, 1,
 S::RuleDockerAuth},

{"private_key_pem", "Private key (PEM)", Severity::Critical,
 R"(-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----)", false,
 "-----begin", Validator::None, 0.0, 0,
 S::RulePrivateKeyHeader},

{"putty_private_key", "PuTTY Private Key", Severity::Critical,
 R"(PuTTY-User-Key-File-[0-9])", false, "putty-user-key-file", Validator::None, 0.0, 0,
 S::RulePuttyKey},

{"jwt_token", "JSON Web Token", Severity::High,
 R"(eyJ[A-Za-z0-9_\-]{8,}\.eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,})", false, "eyj",
 Validator::Jwt, 0.0, 0, S::RuleJwt},

{"db_connection_string", "Password in a connection string", Severity::Critical,
 R"((?:postgres|postgresql|mysql|mariadb|mongodb\+srv|mongodb|redis|rediss|amqp|amqps|mssql|clickhouse|ftp|sftp)://[^:@\s/]{1,64}:([^@\s/]{3,128})@)", true,
 "postgres://,postgresql://,mysql://,mariadb://,mongodb://,mongodb+srv://,redis://,rediss://,amqp://,amqps://,mssql://,clickhouse://,ftp://,sftp://",
 Validator::NotPlaceholder, 0.0, 1, S::RuleDbUriPassword},

{"basic_auth_url", "Basic auth in URL", Severity::High,
 R"(https?://[^:@\s/]{1,64}:([^@\s/]{3,128})@)", true, "http://,https://",
 Validator::NotPlaceholder, 0.0, 1, S::RuleHttpUserPass},

{"password_assignment", "Plaintext password", Severity::High,
 R"((?:password|passwd|pwd|pass_word|db_pass|user_pass)["']?\s*[:=>]{1,2}\s*["']?([^"'\s,;)}\]<>]{6,72}))", true,
 "password,passwd,pwd,pass_word,db_pass,user_pass", Validator::NotPlaceholder, 0.0, 1,
 S::RulePasswordAssign},

{"password_assignment_ru", "Password (Cyrillic)", Severity::High,
 R"((?:пароль|Пароль|ПАРОЛЬ|парол)\s*[:=\-]{1,2}\s*["']?([^"'\s,;]{4,72}))", false,
 "пароль,Пароль,ПАРОЛЬ", Validator::NotPlaceholder, 0.0, 1,
 S::RulePasswordRuNote},

{"generic_api_key", "Generic secret (api_key / token)", Severity::High,
 R"((?:api[_\-]?key|apikey|api[_\-]?secret|secret[_\-]?key|access[_\-]?token|auth[_\-]?token|client[_\-]?secret|private[_\-]?token|bearer)["']?\s*[:=]{1,2}\s*["']?([A-Za-z0-9_\-+/=.]{16,128}))", true,
 "api_key,apikey,api-key,api_secret,secret_key,secretkey,access_token,accesstoken,auth_token,authtoken,client_secret,clientsecret,private_token,bearer",
 Validator::Entropy, 3.0, 1, S::RuleNamedSecretVar},

{"authorization_header", "Authorization header", Severity::High,
 R"([Aa]uthorization\s*:\s*(?:Bearer|Basic|Token)\s+([A-Za-z0-9_\-+/=.]{16,}))", false,
 "authorization", Validator::Entropy, 3.0, 1, S::RuleHttpAuthToken},

{"env_secret_line", "Secret in .env", Severity::High,
 R"((?:^|\n)[A-Z0-9_]{0,32}(?:SECRET|TOKEN|PASSWORD|APIKEY|API_KEY|PRIVATE_KEY)[A-Z0-9_]{0,16}\s*=\s*["']?([^"'\n\r]{8,128}))", false,
 "SECRET=,TOKEN=,PASSWORD=,APIKEY=,API_KEY=,PRIVATE_KEY=,SECRET_,TOKEN_,_SECRET,_TOKEN,_PASSWORD",
 Validator::NotPlaceholder, 0.0, 1, S::RuleEnvVarSecret},

{"credential_dump_line", "login:password dump line", Severity::Critical,
 R"([A-Za-z0-9._%+\-]{3,64}@[A-Za-z0-9.\-]{2,63}\.[A-Za-z]{2,10}[:;|](?=[^\s:;|/]{0,63}[^0-9\s:;|/])([^\s:;|/]{4,64}))", false,
 "@", Validator::NotPlaceholder, 0.0, 1,
 S::RuleEmailPassword},

{"kz_iban", "IBAN (Kazakhstan)", Severity::Medium,
 R"(KZ[0-9]{2}[0-9A-Z]{16})", false, "KZ", Validator::Iban, 0.0, 0,
 S::RuleIban},

{"kz_phone", "Phone number (+7)", Severity::Low,
 R"(\+7[ \-]?\(?7[0-9]{2}\)?[ \-]?[0-9]{3}[ \-]?[0-9]{2}[ \-]?[0-9]{2})", false, "+7",
 Validator::None, 0.0, 0, S::RulePiiMobile},

{"email_address", "Email address", Severity::Info,
 R"([A-Za-z0-9._%+\-]{2,64}@[A-Za-z0-9.\-]{2,63}\.[A-Za-z]{2,10})", false, "@",
 Validator::None, 0.0, 0, S::RulePiiEmail},

{"ssh_known_hosts_key", "Private SSH key in config", Severity::High,
 R"(IdentityFile\s+([^\s#]{3,256}))", false, "identityfile", Validator::None, 0.0, 1,
 S::RuleSshKeyPath},

{"windows_cred", "Windows credentials", Severity::High,
 R"(net use\s+[A-Za-z:\\\\$. ]{1,64}\s+/user:\s*([^\s]{2,64})\s+([^\s]{3,64}))", true, "net use",
 Validator::NotPlaceholder, 0.0, 2, S::RuleNetUsePassword},

{"pgp_block", "PGP block", Severity::Medium,
 R"(-----BEGIN PGP (?:PUBLIC|PRIVATE) KEY BLOCK-----)", false, "-----begin pgp",
 Validator::None, 0.0, 0, S::RulePgpExported},
};

Severity parseSevOr(const std::string& s, Severity def) {
    Severity out = def;
    return parseSeverity(s, out) ? out : def;
}

}

void RuleSet::loadDefaults() {
    for (const RuleSpec& s : kDefaultRules) {
        Rule r;
        r.id          = s.id;
        r.description = tr(s.descId);
        r.name        = r.description.empty() ? std::string(s.name) : r.description;
        r.severity    = s.sev;
        r.pattern     = s.pattern;
        r.icase       = s.icase;
        r.validator   = s.validator;
        r.entropyMin  = s.entropyMin;
        r.captureGroup = s.group;
        if (s.keywords && *s.keywords) r.keywords = splitAndTrim(s.keywords, ',');
        rules_.push_back(std::move(r));
    }
}

bool RuleSet::loadFromFile(const fs::path& path, std::string& error) {
    std::ifstream in(path);
    if (!in) {
        error = tr(S::ErrRulesOpen) + pathToUtf8(path);
        return false;
    }

    Rule cur;
    bool inRule = false;
    std::string line;
    int lineNo = 0;

    auto flush = [&]() -> bool {
        if (!inRule) return true;
        if (cur.id.empty() || cur.pattern.empty()) {
            error = tr(S::ErrRuleNoId) + std::to_string(lineNo) + ")";
            return false;
        }
        auto it = std::find_if(rules_.begin(), rules_.end(),
                               [&](const Rule& r) { return r.id == cur.id; });
        if (it != rules_.end()) *it = cur;
        else rules_.push_back(cur);
        cur = Rule{};
        inRule = false;
        return true;
    };

    while (std::getline(in, line)) {
        ++lineNo;
        const std::string t = trim(line);
        if (t.empty() || t[0] == '#' || t[0] == ';') continue;

        if (t.front() == '[' && t.back() == ']') {
            if (!flush()) return false;
            inRule = true;
            continue;
        }
        const std::size_t eq = t.find('=');
        if (eq == std::string::npos) continue;
        const std::string key = toLowerAscii(trim(t.substr(0, eq)));
        std::string val = trim(t.substr(eq + 1));
        if (val.size() >= 2 && ((val.front() == '"' && val.back() == '"') ||
                                (val.front() == '\'' && val.back() == '\''))) {
            val = val.substr(1, val.size() - 2);
        }

        if      (key == "id")          cur.id = val;
        else if (key == "name")        cur.name = val;
        else if (key == "description") cur.description = val;
        else if (key == "severity")    cur.severity = parseSevOr(val, Severity::Medium);
        else if (key == "pattern")     cur.pattern = val;
        else if (key == "icase")       cur.icase = (val == "1" || iequalsAscii(val, "true") || iequalsAscii(val, "yes"));
        else if (key == "keywords")    cur.keywords = splitAndTrim(val, ',');
        else if (key == "entropy_min") cur.entropyMin = std::atof(val.c_str());
        else if (key == "group")       cur.captureGroup = std::atoi(val.c_str());
        else if (key == "validator") {
            const std::string v = toLowerAscii(val);
            if      (v == "jwt")             cur.validator = Validator::Jwt;
            else if (v == "entropy")         cur.validator = Validator::Entropy;
            else if (v == "not_placeholder") cur.validator = Validator::NotPlaceholder;
            else if (v == "iban")            cur.validator = Validator::Iban;
            else                             cur.validator = Validator::None;
        }
    }
    if (cur.name.empty()) cur.name = cur.id;
    return flush();
}

void RuleSet::applyFilters(const std::vector<std::string>& onlyIds,
                           const std::vector<std::string>& disabledIds) {
    for (Rule& r : rules_) {
        if (!onlyIds.empty()) {
            const bool keep = std::any_of(onlyIds.begin(), onlyIds.end(),
                [&](const std::string& id) { return wildcardMatch(id, r.id, true); });
            if (!keep) { r.enabled = false; continue; }
        }
        const bool off = std::any_of(disabledIds.begin(), disabledIds.end(),
            [&](const std::string& id) { return wildcardMatch(id, r.id, true); });
        if (off) r.enabled = false;
    }
}

bool RuleSet::compile(std::string& error) {
    heavy_.clear();
    for (std::size_t i = 0; i < rules_.size(); ++i) {
        Rule& r = rules_[i];
        if (!r.enabled) continue;
        auto flags = std::regex::ECMAScript | std::regex::optimize;
        if (r.icase) flags |= std::regex::icase;
        try {
            r.re = std::regex(r.pattern, flags);
            r.compiled = true;
        } catch (const std::regex_error& e) {
            error = tr(S::ErrRuleRegex) + r.id + "': " + e.what();
            return false;
        }
        if (r.keywords.empty()) {
            heavy_.push_back(static_cast<int>(i));
        } else {
            for (const std::string& kw : r.keywords) {
                prefilter_.add(kw, static_cast<int>(i));
            }
        }
    }
    prefilter_.build();
    return true;
}

std::size_t RuleSet::enabledCount() const noexcept {
    return static_cast<std::size_t>(
        std::count_if(rules_.begin(), rules_.end(), [](const Rule& r) { return r.enabled; }));
}

}
