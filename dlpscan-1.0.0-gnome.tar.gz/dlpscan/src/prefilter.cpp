#include "dlp/prefilter.hpp"

#include <algorithm>
#include <queue>

namespace dlp {

AhoCorasick::AhoCorasick(bool caseInsensitive) {
    for (int i = 0; i < 256; ++i) {
        u8 c = static_cast<u8>(i);
        if (caseInsensitive && c >= 'A' && c <= 'Z') c = static_cast<u8>(c - 'A' + 'a');
        lower_[static_cast<std::size_t>(i)] = c;
    }
    newNode();
}

std::int32_t AhoCorasick::newNode() {
    next_.resize(next_.size() + 256, -1);
    fail_.push_back(0);
    tmpOut_.emplace_back();
    return nodes_++;
}

void AhoCorasick::add(std::string_view pattern, int id) {
    if (pattern.empty() || built_) return;
    std::int32_t cur = 0;
    for (char ch : pattern) {
        const u8 c = lower_[static_cast<u8>(ch)];
        std::int32_t& slot = next_[static_cast<std::size_t>(cur) * 256 + c];
        if (slot < 0) {
            const std::int32_t created = newNode();

            next_[static_cast<std::size_t>(cur) * 256 + c] = created;
            cur = created;
        } else {
            cur = slot;
        }
    }
    tmpOut_[static_cast<std::size_t>(cur)].push_back(id);
    ++patterns_;
    maxLen_ = std::max(maxLen_, pattern.size());
}

void AhoCorasick::build() {
    if (built_) return;
    built_ = true;

    std::queue<std::int32_t> q;
    for (int c = 0; c < 256; ++c) {
        std::int32_t& v = next_[static_cast<std::size_t>(c)];
        if (v < 0) {
            v = 0;
        } else {
            fail_[static_cast<std::size_t>(v)] = 0;
            q.push(v);
        }
    }

    while (!q.empty()) {
        const std::int32_t u = q.front();
        q.pop();

        const std::int32_t f = fail_[static_cast<std::size_t>(u)];
        if (!tmpOut_[static_cast<std::size_t>(f)].empty()) {
            auto& dst = tmpOut_[static_cast<std::size_t>(u)];
            const auto& src = tmpOut_[static_cast<std::size_t>(f)];
            dst.insert(dst.end(), src.begin(), src.end());
        }

        for (int c = 0; c < 256; ++c) {
            const std::size_t idx = static_cast<std::size_t>(u) * 256 + static_cast<std::size_t>(c);
            const std::int32_t v = next_[idx];
            if (v < 0) {
                next_[idx] = next_[static_cast<std::size_t>(fail_[static_cast<std::size_t>(u)]) * 256
                                   + static_cast<std::size_t>(c)];
            } else {
                fail_[static_cast<std::size_t>(v)] =
                    next_[static_cast<std::size_t>(fail_[static_cast<std::size_t>(u)]) * 256
                          + static_cast<std::size_t>(c)];
                q.push(v);
            }
        }
    }

    outStart_.resize(static_cast<std::size_t>(nodes_) + 1, 0);
    std::size_t total = 0;
    for (std::int32_t i = 0; i < nodes_; ++i) {
        outStart_[static_cast<std::size_t>(i)] = static_cast<std::int32_t>(total);
        total += tmpOut_[static_cast<std::size_t>(i)].size();
    }
    outStart_[static_cast<std::size_t>(nodes_)] = static_cast<std::int32_t>(total);

    outIds_.resize(total);
    std::size_t pos = 0;
    for (std::int32_t i = 0; i < nodes_; ++i) {
        for (std::int32_t id : tmpOut_[static_cast<std::size_t>(i)]) outIds_[pos++] = id;
    }
    std::vector<std::vector<std::int32_t>>().swap(tmpOut_);
    std::vector<std::int32_t>().swap(fail_);
}

}
