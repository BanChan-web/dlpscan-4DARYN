#include "gui_theme.hpp"

namespace dlpgui {

namespace {

Theme  g_theme = Theme::Dark;
Palette g_pal;

ImVec4 rgb(int r, int g, int b, float a = 1.0f) {
    return ImVec4(static_cast<float>(r) / 255.0f,
                  static_cast<float>(g) / 255.0f,
                  static_cast<float>(b) / 255.0f, a);
}

void buildDark(Palette& p) {
    p.windowBg     = rgb(0x1e, 0x1e, 0x1e);
    p.headerBg     = rgb(0x2d, 0x2d, 0x2d);
    p.cardBg       = rgb(0x30, 0x30, 0x30);
    p.viewBg       = rgb(0x26, 0x26, 0x26);
    p.border       = rgb(0x48, 0x48, 0x48);
    p.text         = rgb(0xff, 0xff, 0xff, 0.92f);
    p.textDim      = rgb(0xff, 0xff, 0xff, 0.55f);
    p.accent       = rgb(0x35, 0x84, 0xe4);
    p.accentHover  = rgb(0x4a, 0x90, 0xe8);
    p.accentActive = rgb(0x1c, 0x71, 0xd8);
    p.onAccent     = rgb(0xff, 0xff, 0xff);
    p.success      = rgb(0x2e, 0xc2, 0x7e);
    p.warning      = rgb(0xf5, 0xc2, 0x11);
    p.error        = rgb(0xff, 0x7b, 0x63);
    p.destructive  = rgb(0xc0, 0x1c, 0x28);

    p.sev[0] = rgb(0x9a, 0x9a, 0x9a);
    p.sev[1] = rgb(0x78, 0xae, 0xed);
    p.sev[2] = rgb(0xf5, 0xc2, 0x11);
    p.sev[3] = rgb(0xff, 0xa3, 0x48);
    p.sev[4] = rgb(0xff, 0x7b, 0x63);
    for (int i = 0; i < 5; ++i) {
        p.sevBg[i] = ImVec4(p.sev[i].x, p.sev[i].y, p.sev[i].z, 0.16f);
    }
}

void buildLight(Palette& p) {
    p.windowBg     = rgb(0xfa, 0xfa, 0xfa);
    p.headerBg     = rgb(0xeb, 0xeb, 0xeb);
    p.cardBg       = rgb(0xff, 0xff, 0xff);
    p.viewBg       = rgb(0xff, 0xff, 0xff);
    p.border       = rgb(0xd4, 0xd4, 0xd4);
    p.text         = rgb(0x00, 0x00, 0x00, 0.88f);
    p.textDim      = rgb(0x00, 0x00, 0x00, 0.52f);
    p.accent       = rgb(0x35, 0x84, 0xe4);
    p.accentHover  = rgb(0x1c, 0x71, 0xd8);
    p.accentActive = rgb(0x1a, 0x5f, 0xb4);
    p.onAccent     = rgb(0xff, 0xff, 0xff);
    p.success      = rgb(0x26, 0xa2, 0x69);
    p.warning      = rgb(0xe5, 0xa5, 0x0a);
    p.error        = rgb(0xe0, 0x1b, 0x24);
    p.destructive  = rgb(0xc0, 0x1c, 0x28);

    p.sev[0] = rgb(0x77, 0x76, 0x7b);
    p.sev[1] = rgb(0x1c, 0x71, 0xd8);
    p.sev[2] = rgb(0xc6, 0x86, 0x00);
    p.sev[3] = rgb(0xe6, 0x61, 0x00);
    p.sev[4] = rgb(0xc0, 0x1c, 0x28);
    for (int i = 0; i < 5; ++i) {
        p.sevBg[i] = ImVec4(p.sev[i].x, p.sev[i].y, p.sev[i].z, 0.13f);
    }
}

ImVec4 mix(const ImVec4& a, const ImVec4& b, float t) {
    return ImVec4(a.x + (b.x - a.x) * t,
                  a.y + (b.y - a.y) * t,
                  a.z + (b.z - a.z) * t,
                  a.w + (b.w - a.w) * t);
}

}

Theme currentTheme() { return g_theme; }
const Palette& palette() { return g_pal; }

void ApplyTheme(Theme t) {
    g_theme = t;
    if (t == Theme::Dark) buildDark(g_pal); else buildLight(g_pal);

    const Palette& p = g_pal;
    ImGuiStyle& s = ImGui::GetStyle();

    s.WindowRounding    = 0.0f;
    s.ChildRounding     = 12.0f;
    s.FrameRounding     = 8.0f;
    s.PopupRounding     = 10.0f;
    s.ScrollbarRounding = 10.0f;
    s.GrabRounding      = 10.0f;
    s.TabRounding       = 8.0f;

    s.WindowPadding     = ImVec2(18.0f, 16.0f);
    s.FramePadding      = ImVec2(12.0f, 8.0f);
    s.ItemSpacing       = ImVec2(10.0f, 10.0f);
    s.ItemInnerSpacing  = ImVec2(8.0f, 6.0f);
    s.CellPadding       = ImVec2(12.0f, 9.0f);
    s.IndentSpacing     = 18.0f;
    s.ScrollbarSize     = 12.0f;
    s.GrabMinSize       = 14.0f;

    s.WindowBorderSize  = 0.0f;
    s.ChildBorderSize   = 1.0f;
    s.FrameBorderSize   = 0.0f;
    s.PopupBorderSize   = 1.0f;

    s.WindowTitleAlign  = ImVec2(0.0f, 0.5f);
    s.ButtonTextAlign   = ImVec2(0.5f, 0.5f);
    s.SelectableTextAlign = ImVec2(0.0f, 0.5f);

    ImVec4* c = s.Colors;
    c[ImGuiCol_Text]                  = p.text;
    c[ImGuiCol_TextDisabled]          = p.textDim;
    c[ImGuiCol_WindowBg]              = p.windowBg;
    c[ImGuiCol_ChildBg]               = p.cardBg;
    c[ImGuiCol_PopupBg]               = p.cardBg;
    c[ImGuiCol_Border]                = p.border;
    c[ImGuiCol_BorderShadow]          = ImVec4(0, 0, 0, 0);

    c[ImGuiCol_FrameBg]               = mix(p.cardBg, p.text, 0.07f);
    c[ImGuiCol_FrameBgHovered]        = mix(p.cardBg, p.text, 0.12f);
    c[ImGuiCol_FrameBgActive]         = mix(p.cardBg, p.text, 0.16f);

    c[ImGuiCol_TitleBg]               = p.headerBg;
    c[ImGuiCol_TitleBgActive]         = p.headerBg;
    c[ImGuiCol_TitleBgCollapsed]      = p.headerBg;
    c[ImGuiCol_MenuBarBg]             = p.headerBg;

    c[ImGuiCol_ScrollbarBg]           = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_ScrollbarGrab]         = mix(p.cardBg, p.text, 0.20f);
    c[ImGuiCol_ScrollbarGrabHovered]  = mix(p.cardBg, p.text, 0.30f);
    c[ImGuiCol_ScrollbarGrabActive]   = mix(p.cardBg, p.text, 0.40f);

    c[ImGuiCol_CheckMark]             = p.onAccent;
    c[ImGuiCol_SliderGrab]            = p.accent;
    c[ImGuiCol_SliderGrabActive]      = p.accentActive;

    c[ImGuiCol_Button]                = mix(p.cardBg, p.text, 0.10f);
    c[ImGuiCol_ButtonHovered]         = mix(p.cardBg, p.text, 0.16f);
    c[ImGuiCol_ButtonActive]          = mix(p.cardBg, p.text, 0.22f);

    c[ImGuiCol_Header]                = mix(p.cardBg, p.accent, 0.25f);
    c[ImGuiCol_HeaderHovered]         = mix(p.cardBg, p.accent, 0.35f);
    c[ImGuiCol_HeaderActive]          = mix(p.cardBg, p.accent, 0.45f);

    c[ImGuiCol_Separator]             = p.border;
    c[ImGuiCol_SeparatorHovered]      = p.accent;
    c[ImGuiCol_SeparatorActive]       = p.accent;

    c[ImGuiCol_ResizeGrip]            = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_ResizeGripHovered]     = p.accent;
    c[ImGuiCol_ResizeGripActive]      = p.accentActive;

    c[ImGuiCol_Tab]                   = p.headerBg;
    c[ImGuiCol_TabHovered]            = mix(p.headerBg, p.accent, 0.35f);

    c[ImGuiCol_PlotLines]             = p.accent;
    c[ImGuiCol_PlotHistogram]         = p.accent;

    c[ImGuiCol_TableHeaderBg]         = p.headerBg;
    c[ImGuiCol_TableBorderStrong]     = p.border;
    c[ImGuiCol_TableBorderLight]      = mix(p.cardBg, p.border, 0.55f);
    c[ImGuiCol_TableRowBg]            = ImVec4(0, 0, 0, 0);
    c[ImGuiCol_TableRowBgAlt]         = mix(p.cardBg, p.text, 0.035f);

    c[ImGuiCol_TextSelectedBg]        = ImVec4(p.accent.x, p.accent.y, p.accent.z, 0.35f);
    c[ImGuiCol_NavHighlight]          = p.accent;
    c[ImGuiCol_ModalWindowDimBg]      = ImVec4(0, 0, 0, 0.45f);
}

bool PillButton(const char* label, const ImVec2& size, bool suggested) {
    const Palette& p = palette();
    if (suggested) {
        ImGui::PushStyleColor(ImGuiCol_Button, p.accent);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, p.accentHover);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, p.accentActive);
        ImGui::PushStyleColor(ImGuiCol_Text, p.onAccent);
    }
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 999.0f);
    const bool clicked = ImGui::Button(label, size);
    ImGui::PopStyleVar();
    if (suggested) ImGui::PopStyleColor(4);
    return clicked;
}

bool DestructivePillButton(const char* label, const ImVec2& size) {
    const Palette& p = palette();
    ImGui::PushStyleColor(ImGuiCol_Button, p.destructive);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
                          ImVec4(p.destructive.x * 1.15f, p.destructive.y * 1.15f,
                                 p.destructive.z * 1.15f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,
                          ImVec4(p.destructive.x * 0.85f, p.destructive.y * 0.85f,
                                 p.destructive.z * 0.85f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 999.0f);
    const bool clicked = ImGui::Button(label, size);
    ImGui::PopStyleVar();
    ImGui::PopStyleColor(4);
    return clicked;
}

void SectionHeader(const char* label) {
    ImGui::Dummy(ImVec2(0.0f, 2.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, palette().textDim);
    ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();
    ImGui::Dummy(ImVec2(0.0f, 1.0f));
}

void Badge(const char* text, const ImVec4& fg, const ImVec4& bg) {
    const ImVec2 pad(9.0f, 3.0f);
    const ImVec2 ts = ImGui::CalcTextSize(text);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const ImVec2 sz(ts.x + pad.x * 2.0f, ts.y + pad.y * 2.0f);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, ImVec2(pos.x + sz.x, pos.y + sz.y),
                      ImGui::GetColorU32(bg), sz.y * 0.5f);
    dl->AddText(ImVec2(pos.x + pad.x, pos.y + pad.y), ImGui::GetColorU32(fg), text);
    ImGui::Dummy(sz);
}

void BeginCard(const char* id, const ImVec2& size) {
    ImGui::PushStyleColor(ImGuiCol_ChildBg, palette().cardBg);
    ImGui::PushStyleColor(ImGuiCol_Border, palette().border);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 12.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16.0f, 14.0f));
    ImGui::BeginChild(id, size, true);
}

void EndCard() {
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
}

}
