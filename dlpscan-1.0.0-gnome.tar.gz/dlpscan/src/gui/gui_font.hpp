#pragma once

#include "imgui.h"

namespace dlpgui {

struct UiFonts {
    ImFont* regular = nullptr;
    ImFont* medium  = nullptr;
    ImFont* small   = nullptr;
    ImFont* title   = nullptr;
    bool    cyrillicOk = false;
};

UiFonts LoadUiFonts(ImGuiIO& io, float uiScale);
const UiFonts& fonts();

}
