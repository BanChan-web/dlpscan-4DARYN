#pragma once

#include <windows.h>
#include <string>

namespace dlpgui {

std::wstring Utf8ToWide(const std::string& s);
std::string  WideToUtf8(const std::wstring& s);

bool BrowseForFolder(HWND owner, const wchar_t* title, std::wstring& outPath);

bool SaveFileDialog(HWND owner, const wchar_t* filter, const wchar_t* defExt,
                    std::wstring& outPath);

}
