#include "gui_app.hpp"
#include "gui_font.hpp"
#include "win32_util.hpp"

#include "dlp/common.hpp"
#include "dlp/report.hpp"

#include "imgui.h"

#include <algorithm>
#include <cstdio>
#include <iterator>

namespace dlpgui {

using dlp::S;
using dlp::tr;
using dlp::trf;

namespace {

const char* severityLabel(int i) {
    static const S kIds[5] = {S::SevInfoCap, S::SevLowCap, S::SevMediumCap,
                              S::SevHighCap, S::SevCriticalCap};
    return tr(kIds[(i < 0 || i > 4) ? 0 : i]);
}

void PushTitleFont() { if (fonts().title)  ImGui::PushFont(fonts().title); }
void PushBoldFont()  { if (fonts().medium) ImGui::PushFont(fonts().medium); }
void PushSmallFont() { if (fonts().small)  ImGui::PushFont(fonts().small); }
void PopUiFont(ImFont* f) { if (f) ImGui::PopFont(); }

void DimText(const char* s) {
    ImGui::PushStyleColor(ImGuiCol_Text, palette().textDim);
    ImGui::TextUnformatted(s);
    ImGui::PopStyleColor();
}

}

void GuiApp::DrawUI() {
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const float headerH = 56.0f;
    const float statusH = 34.0f;

    ImGui::SetNextWindowPos(vp->Pos);
    ImGui::SetNextWindowSize(vp->Size);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);

    const ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBringToFrontOnFocus;

    ImGui::Begin("##root", nullptr, flags);
    ImGui::PopStyleVar(2);

    DrawHeaderBar(headerH);

    const float bodyH = vp->Size.y - headerH - statusH;
    const float pad   = 14.0f;
    const float leftW = 380.0f;

    ImGui::SetCursorPos(ImVec2(pad, headerH + pad));
    ImGui::BeginChild("##body", ImVec2(vp->Size.x - pad * 2.0f, bodyH - pad * 2.0f),
                      false, ImGuiWindowFlags_NoScrollbar);

    const ImVec2 avail = ImGui::GetContentRegionAvail();
    DrawSettingsColumn(ImVec2(leftW, avail.y));
    ImGui::SameLine(0.0f, pad);
    DrawResultsColumn(ImVec2(avail.x - leftW - pad, avail.y));

    ImGui::EndChild();

    DrawStatusBar(statusH);
    ImGui::End();

    RefreshLiveFindings();
}

void GuiApp::DrawHeaderBar(float height) {
    const Palette& p = palette();
    const ImGuiViewport* vp = ImGui::GetMainViewport();

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 a = vp->Pos;
    const ImVec2 b = ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + height);
    dl->AddRectFilled(a, b, ImGui::GetColorU32(p.headerBg));
    dl->AddLine(ImVec2(a.x, b.y - 1.0f), ImVec2(b.x, b.y - 1.0f),
                ImGui::GetColorU32(p.border), 1.0f);

    ImGui::SetCursorPos(ImVec2(20.0f, 14.0f));
    ImFont* tf = fonts().title;
    PushTitleFont();
    ImGui::TextUnformatted(tr(S::GuiAppTitle));
    PopUiFont(tf);

    ImGui::SetCursorPos(ImVec2(20.0f + ImGui::CalcTextSize(tr(S::GuiAppTitle)).x + 14.0f, 19.0f));
    PushSmallFont();
    DimText("dlpscan 1.0.0");
    PopUiFont(fonts().small);

    const float ctrlW = 150.0f;
    const float themeW = 130.0f;

    ImGui::SetCursorPos(ImVec2(vp->Size.x - ctrlW - themeW - 30.0f, 11.0f));
    ImGui::SetNextItemWidth(themeW);
    const char* themes[2] = {tr(S::GuiThemeDark), tr(S::GuiThemeLight)};
    if (ImGui::Combo("##theme", &themeIdx_, themes, 2)) {
        ApplyTheme(themeIdx_ == 0 ? Theme::Dark : Theme::Light);
    }

    ImGui::SetCursorPos(ImVec2(vp->Size.x - ctrlW - 16.0f, 11.0f));
    ImGui::SetNextItemWidth(ctrlW);
    const char* langs[3] = {
        dlp::langNativeName(dlp::Lang::En),
        dlp::langNativeName(dlp::Lang::Ru),
        dlp::langNativeName(dlp::Lang::Kk),
    };
    if (ImGui::Combo("##lang", &langIdx_, langs, 3)) {
        dlp::setLanguage(static_cast<dlp::Lang>(langIdx_));
    }
}

void GuiApp::DrawSettingsColumn(const ImVec2& size) {
    ImGui::BeginChild("##settings", size, false);
    DrawFontWarning();
    DrawTargetsCard();
    DrawMethodsCard();
    DrawTuningCard();
    ImGui::EndChild();
}

void GuiApp::DrawFontWarning() {
    if (fonts().cyrillicOk) return;
    const Palette& p = palette();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, p.sevBg[3]);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 10.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12.0f, 10.0f));
    ImGui::BeginChild("##fontwarn", ImVec2(0.0f, 86.0f), true);
    ImGui::PushStyleColor(ImGuiCol_Text, p.sev[3]);
    ImGui::TextWrapped("%s", tr(S::GuiFontWarning));
    ImGui::PopStyleColor();
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
    ImGui::Dummy(ImVec2(0.0f, 6.0f));
}

void GuiApp::DrawTargetsCard() {
    const bool busy = runner_.isActive();
    BeginCard("##targets", ImVec2(0.0f, 212.0f));

    ImFont* bf = fonts().medium;
    PushBoldFont();
    ImGui::TextUnformatted(tr(S::GuiSecScope));
    PopUiFont(bf);
    ImGui::Dummy(ImVec2(0.0f, 2.0f));

    ImGui::BeginDisabled(busy);

    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputTextWithHint("##pathinput", tr(S::GuiPathHint), pathInput_, sizeof(pathInput_));

    const float halfW = (ImGui::GetContentRegionAvail().x - 8.0f) * 0.5f;
    if (PillButton(tr(S::GuiBrowse), ImVec2(halfW, 0.0f), false)) {
        std::wstring picked;
        if (BrowseForFolder(hwnd_, Utf8ToWide(tr(S::GuiBrowseTitle)).c_str(), picked)) {
            const std::string u8 = WideToUtf8(picked);
            std::snprintf(pathInput_, sizeof(pathInput_), "%s", u8.c_str());
        }
    }
    ImGui::SameLine(0.0f, 8.0f);
    if (PillButton(tr(S::GuiAdd), ImVec2(halfW, 0.0f), true) && pathInput_[0] != '\0') {
        roots_.emplace_back(pathInput_);
        pathInput_[0] = '\0';
    }

    ImGui::PushStyleColor(ImGuiCol_ChildBg, palette().viewBg);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 8.0f);
    ImGui::BeginChild("##rootslist", ImVec2(0.0f, 78.0f), true);
    if (roots_.empty()) {
        PushSmallFont();
        DimText(tr(S::GuiNoTargets));
        PopUiFont(fonts().small);
    }
    int removeIdx = -1;
    for (std::size_t i = 0; i < roots_.size(); ++i) {
        ImGui::PushID(static_cast<int>(i));
        ImGui::PushStyleColor(ImGuiCol_Text, palette().error);
        if (ImGui::SmallButton("x")) removeIdx = static_cast<int>(i);
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::TextUnformatted(roots_[i].c_str());
        ImGui::PopID();
    }
    ImGui::EndChild();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();
    if (removeIdx >= 0) {
        roots_.erase(roots_.begin() + static_cast<std::ptrdiff_t>(removeIdx));
    }

    ImGui::EndDisabled();
    EndCard();
    ImGui::Dummy(ImVec2(0.0f, 10.0f));
}

void GuiApp::DrawMethodsCard() {
    const bool busy = runner_.isActive();
    BeginCard("##methods", ImVec2(0.0f, 210.0f));

    ImFont* bf = fonts().medium;
    PushBoldFont();
    ImGui::TextUnformatted(tr(S::GuiSecMethods));
    PopUiFont(bf);
    ImGui::Dummy(ImVec2(0.0f, 2.0f));

    ImGui::BeginDisabled(busy);
    ImGui::Checkbox(tr(S::GuiOptSignatures), &useSignatures_);
    ImGui::Checkbox(tr(S::GuiOptNumeric), &useNumeric_);
    ImGui::Checkbox(tr(S::GuiOptEntropy), &useEntropy_);
    ImGui::Checkbox(tr(S::GuiOptTokens), &useEntropyTokens_);
    ImGui::Checkbox(tr(S::GuiOptBinary), &scanBinary_);
    ImGui::Checkbox(tr(S::GuiOptRedact), &redact_);
    if (!redact_) {
        ImGui::PushStyleColor(ImGuiCol_Text, palette().error);
        PushSmallFont();
        ImGui::TextWrapped("%s", tr(S::GuiRedactWarning));
        PopUiFont(fonts().small);
        ImGui::PopStyleColor();
    }
    ImGui::EndDisabled();

    EndCard();
    ImGui::Dummy(ImVec2(0.0f, 10.0f));
}

void GuiApp::DrawTuningCard() {
    const bool busy = runner_.isActive();
    BeginCard("##tuning", ImVec2(0.0f, 0.0f));

    ImFont* bf = fonts().medium;
    PushBoldFont();
    ImGui::TextUnformatted(tr(S::GuiSecTuning));
    PopUiFont(bf);
    ImGui::Dummy(ImVec2(0.0f, 2.0f));

    ImGui::BeginDisabled(busy);

    PushSmallFont();
    DimText(tr(S::GuiEntropyThreshold));
    PopUiFont(fonts().small);
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::SliderFloat("##entropy", &entropyThreshold_, 4.0f, 8.0f, "%.2f");

    PushSmallFont();
    DimText(tr(S::GuiThreads));
    PopUiFont(fonts().small);
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::SliderInt("##threads", &threads_, 0, 64);

    PushSmallFont();
    DimText(tr(S::GuiMinSeverity));
    PopUiFont(fonts().small);
    const char* sevItems[5] = {severityLabel(0), severityLabel(1), severityLabel(2),
                               severityLabel(3), severityLabel(4)};
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::Combo("##minsev", &minSeverityIdx_, sevItems, 5);

    ImGui::Dummy(ImVec2(0.0f, 4.0f));
    SectionHeader(tr(S::GuiSecFilters));
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputTextWithHint("##exclude", tr(S::GuiExcludeHint),
                             excludeGlobsBuf_, sizeof(excludeGlobsBuf_));
    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputTextWithHint("##rulesfile", tr(S::GuiRulesFileHint),
                             rulesFileBuf_, sizeof(rulesFileBuf_));

    ImGui::EndDisabled();
    EndCard();
}

void GuiApp::DrawResultsColumn(const ImVec2& size) {
    ImGui::BeginChild("##results", size, false, ImGuiWindowFlags_NoScrollbar);

    BeginCard("##toolbar", ImVec2(0.0f, 150.0f));
    DrawToolbar();
    ImGui::Dummy(ImVec2(0.0f, 6.0f));
    DrawStatStrip();
    EndCard();

    ImGui::Dummy(ImVec2(0.0f, 10.0f));
    DrawFindingsTable(ImVec2(0.0f, ImGui::GetContentRegionAvail().y));

    ImGui::EndChild();
}

void GuiApp::DrawToolbar() {
    dlp::RunState st = runner_.state();
    bool busy = (st == dlp::RunState::Running);

    ImGui::BeginDisabled(busy || roots_.empty());
    if (PillButton(tr(S::GuiStartScan), ImVec2(190.0f, 36.0f), true)) {
        StartScan();
        st   = runner_.state();
        busy = (st == dlp::RunState::Running);
    }
    ImGui::EndDisabled();

    ImGui::SameLine(0.0f, 8.0f);
    ImGui::BeginDisabled(!busy || runner_.isCancelRequested());
    if (DestructivePillButton(tr(S::GuiCancel), ImVec2(110.0f, 36.0f))) runner_.cancel();
    ImGui::EndDisabled();

    ImGui::SameLine(0.0f, 20.0f);
    ImGui::BeginDisabled(busy || st == dlp::RunState::Idle);
    if (PillButton(tr(S::GuiExportHtml), ImVec2(0.0f, 36.0f), false)) ExportReport(0);
    ImGui::SameLine(0.0f, 8.0f);
    if (PillButton(tr(S::GuiExportJson), ImVec2(0.0f, 36.0f), false)) ExportReport(1);
    ImGui::SameLine(0.0f, 8.0f);
    if (PillButton(tr(S::GuiExportCsv), ImVec2(0.0f, 36.0f), false)) ExportReport(2);
    ImGui::EndDisabled();
}

void GuiApp::DrawStatStrip() {
    const Palette& p = palette();
    const dlp::ScanStats& stats = runner_.stats();
    const dlp::RunState st = runner_.state();
    const bool busy = (st == dlp::RunState::Running);

    char files[48], data[48], found[48], took[48];
    std::snprintf(files, sizeof(files), "%llu",
                  static_cast<unsigned long long>(stats.filesScanned.load()));
    std::snprintf(data, sizeof(data), "%s",
                  dlp::humanBytes(stats.bytesScanned.load()).c_str());
    std::snprintf(found, sizeof(found), "%llu",
                  static_cast<unsigned long long>(stats.findings.load()));
    std::snprintf(took, sizeof(took), "%s",
                  dlp::humanDuration(runner_.elapsedSeconds()).c_str());

    struct Cell { const char* label; const char* value; };
    const Cell cells[4] = {
        {tr(S::GuiFilesLabel), files},
        {tr(S::GuiDataLabel),  data},
        {tr(S::GuiFoundLabel), found},
        {tr(S::GuiElapsed),    took},
    };

    const float w = ImGui::GetContentRegionAvail().x / 4.0f;
    for (int i = 0; i < 4; ++i) {
        ImGui::BeginGroup();
        PushSmallFont();
        DimText(cells[i].label);
        PopUiFont(fonts().small);
        ImFont* bf = fonts().medium;
        PushBoldFont();
        ImGui::TextUnformatted(cells[i].value);
        PopUiFont(bf);
        ImGui::EndGroup();
        if (i < 3) ImGui::SameLine(0.0f, w - ImGui::GetItemRectSize().x);
    }

    ImGui::Dummy(ImVec2(0.0f, 4.0f));

    ImGui::PushStyleColor(ImGuiCol_PlotHistogram, busy ? p.accent : p.success);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 999.0f);
    if (busy) {
        ImGui::ProgressBar(-1.0f * static_cast<float>(ImGui::GetTime()),
                           ImVec2(-1.0f, 6.0f), "");
    } else {
        ImGui::ProgressBar(st == dlp::RunState::Idle ? 0.0f : 1.0f,
                           ImVec2(-1.0f, 6.0f), "");
    }
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();
}

void GuiApp::DrawFindingsTable(const ImVec2& size) {
    const Palette& p = palette();
    BeginCard("##findings", size);

    ImFont* bf = fonts().medium;
    PushBoldFont();
    ImGui::TextUnformatted(tr(S::GuiResults));
    PopUiFont(bf);
    ImGui::SameLine();
    PushSmallFont();
    ImGui::PushStyleColor(ImGuiCol_Text, palette().textDim);
    ImGui::Text(tr(S::GuiFindingsCount),
                static_cast<unsigned long long>(displayFindings_.size()));
    ImGui::PopStyleColor();
    PopUiFont(fonts().small);
    ImGui::Dummy(ImVec2(0.0f, 4.0f));

    if (displayFindings_.empty() && runner_.state() == dlp::RunState::Idle) {
        PushSmallFont();
        DimText(tr(S::GuiNoResults));
        PopUiFont(fonts().small);
        EndCard();
        return;
    }

    const ImGuiTableFlags tflags =
        ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY |
        ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV;

    ImGui::PushStyleColor(ImGuiCol_ChildBg, p.viewBg);
    if (ImGui::BeginTable("findings_table", 6, tflags,
                          ImVec2(0.0f, ImGui::GetContentRegionAvail().y))) {
        ImGui::TableSetupColumn(tr(S::GuiColLevel), ImGuiTableColumnFlags_WidthFixed, 104.0f);
        ImGui::TableSetupColumn(tr(S::GuiColFile), ImGuiTableColumnFlags_WidthStretch, 1.4f);
        ImGui::TableSetupColumn(tr(S::GuiColLine), ImGuiTableColumnFlags_WidthFixed, 60.0f);
        ImGui::TableSetupColumn(tr(S::GuiColRule), ImGuiTableColumnFlags_WidthStretch, 1.2f);
        ImGui::TableSetupColumn(tr(S::GuiColContext), ImGuiTableColumnFlags_WidthStretch, 1.6f);
        ImGui::TableSetupColumn(tr(S::GuiColNote), ImGuiTableColumnFlags_WidthStretch, 1.3f);
        ImGui::TableSetupScrollFreeze(0, 1);
        ImGui::TableHeadersRow();

        ImGuiListClipper clipper;
        clipper.Begin(static_cast<int>(displayFindings_.size()));
        while (clipper.Step()) {
            for (int row = clipper.DisplayStart; row < clipper.DisplayEnd; ++row) {
                const dlp::Finding& f = displayFindings_[static_cast<std::size_t>(row)];
                int sevIdx = static_cast<int>(f.severity);
                if (sevIdx < 0 || sevIdx > 4) sevIdx = 0;

                ImGui::TableNextRow();

                ImGui::TableNextColumn();
                Badge(dlp::severityNameLocalized(f.severity), p.sev[sevIdx], p.sevBg[sevIdx]);

                ImGui::TableNextColumn();
                ImGui::TextUnformatted(f.file.c_str());
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", f.file.c_str());

                ImGui::TableNextColumn();
                ImGui::Text("%llu", static_cast<unsigned long long>(f.line));

                ImGui::TableNextColumn();
                ImGui::TextUnformatted(f.ruleName.c_str());

                ImGui::TableNextColumn();
                ImGui::TextUnformatted(f.preview.c_str());
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", f.preview.c_str());

                ImGui::TableNextColumn();
                PushSmallFont();
                DimText(f.note.c_str());
                PopUiFont(fonts().small);
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", f.note.c_str());
            }
        }
        ImGui::EndTable();
    }
    ImGui::PopStyleColor();
    EndCard();
}

void GuiApp::DrawStatusBar(float height) {
    const Palette& p = palette();
    const ImGuiViewport* vp = ImGui::GetMainViewport();

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 a(vp->Pos.x, vp->Pos.y + vp->Size.y - height);
    const ImVec2 b(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y);
    dl->AddRectFilled(a, b, ImGui::GetColorU32(p.headerBg));
    dl->AddLine(a, ImVec2(b.x, a.y), ImGui::GetColorU32(p.border), 1.0f);

    const dlp::RunState st = runner_.state();
    ImVec4 dot = p.textDim;
    const char* msg = tr(S::GuiReady);
    if (st == dlp::RunState::Running)        { dot = p.accent;  msg = runner_.isCancelRequested() ? tr(S::GuiStopping) : tr(S::GuiScanning); }
    else if (st == dlp::RunState::Done)      { dot = p.success; msg = tr(S::GuiDone); }
    else if (st == dlp::RunState::Cancelled) { dot = p.warning; msg = tr(S::GuiCancelledByUser); }
    else if (st == dlp::RunState::Failed)    { dot = p.error;   msg = tr(S::GuiDone); }

    const float cy = vp->Size.y - height + height * 0.5f;
    dl->AddCircleFilled(ImVec2(vp->Pos.x + 24.0f, vp->Pos.y + cy), 4.0f,
                        ImGui::GetColorU32(dot));

    ImGui::SetCursorPos(ImVec2(38.0f, vp->Size.y - height + 8.0f));
    PushSmallFont();
    if (st == dlp::RunState::Failed) {
        ImGui::PushStyleColor(ImGuiCol_Text, p.error);
        ImGui::Text(tr(S::GuiErrorPrefix), runner_.errorMessage().c_str());
        ImGui::PopStyleColor();
    } else {
        ImGui::TextUnformatted(msg);
    }
    if (!statusMessage_.empty()) {
        ImGui::SameLine(0.0f, 16.0f);
        ImGui::PushStyleColor(ImGuiCol_Text, statusIsError_ ? p.error : p.textDim);
        ImGui::TextUnformatted(statusMessage_.c_str());
        ImGui::PopStyleColor();
    }
    PopUiFont(fonts().small);
}

dlp::ScanConfig GuiApp::BuildConfig() const {
    dlp::ScanConfig cfg;
    cfg.roots.reserve(roots_.size());
    for (const auto& r : roots_) cfg.roots.push_back(dlp::utf8ToPath(r));

    cfg.useSignatures    = useSignatures_;
    cfg.useNumeric       = useNumeric_;
    cfg.useEntropy       = useEntropy_;
    cfg.useEntropyTokens = useEntropyTokens_;
    cfg.scanBinary       = scanBinary_;
    cfg.redact           = redact_;
    cfg.entropyThreshold = static_cast<double>(entropyThreshold_);
    cfg.threads          = threads_ > 0 ? static_cast<unsigned>(threads_) : 0u;
    cfg.minSeverity      = static_cast<dlp::Severity>(minSeverityIdx_);

    cfg.progress = false;
    cfg.quiet    = true;
    cfg.color    = false;

    if (excludeGlobsBuf_[0] != '\0') cfg.excludeGlobs = dlp::splitAndTrim(excludeGlobsBuf_, ',');
    if (rulesFileBuf_[0]    != '\0') cfg.rulesFile    = rulesFileBuf_;

    return cfg;
}

void GuiApp::StartScan() {
    displayFindings_.clear();
    lastFindingsPollTime_ = -1.0;
    lastSummarySeen_.reset();
    statusMessage_.clear();
    statusIsError_ = false;
    runner_.start(BuildConfig());
}

void GuiApp::RefreshLiveFindings() {
    const dlp::RunState st = runner_.state();
    const double now = ImGui::GetTime();

    if (st == dlp::RunState::Running) {
        if (lastFindingsPollTime_ < 0.0 || now - lastFindingsPollTime_ >= 0.2) {
            displayFindings_ = runner_.liveFindings();
            std::sort(displayFindings_.begin(), displayFindings_.end());
            lastFindingsPollTime_ = now;
        }
    } else if (st == dlp::RunState::Done || st == dlp::RunState::Cancelled) {
        auto sum = runner_.summary();
        if (sum && sum != lastSummarySeen_) {
            displayFindings_ = sum->findings;
            lastSummarySeen_ = sum;
        }
    }
}

void GuiApp::ExportReport(int kind) {
    auto sum = runner_.summary();
    if (!sum) {
        statusMessage_ = tr(S::GuiFinishFirst);
        statusIsError_ = true;
        return;
    }

    const wchar_t* filter = L"";
    const wchar_t* defExt = L"";
    switch (kind) {
        case 0: filter = L"HTML\0*.html\0\0"; defExt = L"html"; break;
        case 1: filter = L"JSON\0*.json\0\0"; defExt = L"json"; break;
        case 2: filter = L"CSV\0*.csv\0\0";   defExt = L"csv";  break;
        default: return;
    }

    std::wstring picked;
    if (!SaveFileDialog(hwnd_, filter, defExt, picked)) return;

    const std::string pathUtf8 = WideToUtf8(picked);
    std::string err;
    bool ok = false;
    switch (kind) {
        case 0: ok = dlp::writeHtmlReport(*sum, dlp::utf8ToPath(pathUtf8), err); break;
        case 1: ok = dlp::writeJsonReport(*sum, dlp::utf8ToPath(pathUtf8), err); break;
        case 2: ok = dlp::writeCsvReport(*sum, dlp::utf8ToPath(pathUtf8), err); break;
    }
    statusIsError_ = !ok;
    statusMessage_ = ok ? trf(S::GuiSaved, pathUtf8.c_str())
                        : trf(S::GuiSaveError, err.c_str());
}

}
