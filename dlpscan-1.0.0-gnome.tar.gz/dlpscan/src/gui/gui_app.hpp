#pragma once

#include "dlp/scan_runner.hpp"
#include "dlp/i18n.hpp"

#include "gui_theme.hpp"

#include <windows.h>
#include <memory>
#include <string>
#include <vector>

namespace dlpgui {

class GuiApp {
public:
    explicit GuiApp(HWND hwnd) : hwnd_(hwnd) {}

    void DrawUI();

private:
    void DrawHeaderBar(float height);
    void DrawSettingsColumn(const ImVec2& size);
    void DrawResultsColumn(const ImVec2& size);
    void DrawTargetsCard();
    void DrawMethodsCard();
    void DrawTuningCard();
    void DrawToolbar();
    void DrawStatStrip();
    void DrawFindingsTable(const ImVec2& size);
    void DrawStatusBar(float height);
    void DrawFontWarning();

    dlp::ScanConfig BuildConfig() const;
    void StartScan();
    void RefreshLiveFindings();
    void ExportReport(int kind);

    HWND hwnd_;
    dlp::ScanRunner runner_;

    std::vector<std::string> roots_;
    char pathInput_[1024]      = "";
    char excludeGlobsBuf_[512] = "";
    char rulesFileBuf_[512]    = "";

    bool  useSignatures_    = true;
    bool  useNumeric_       = true;
    bool  useEntropy_       = true;
    bool  useEntropyTokens_ = true;
    bool  scanBinary_       = true;
    bool  redact_           = true;
    float entropyThreshold_ = 7.2f;
    int   threads_          = 0;
    int   minSeverityIdx_   = 0;
    int   langIdx_          = 0;
    int   themeIdx_         = 0;

    std::vector<dlp::Finding> displayFindings_;
    double lastFindingsPollTime_ = -1.0;
    std::shared_ptr<const dlp::ScanSummary> lastSummarySeen_;

    std::string statusMessage_;
    bool        statusIsError_ = false;
};

}
