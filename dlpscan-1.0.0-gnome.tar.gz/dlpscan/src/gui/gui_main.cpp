#include "gui_app.hpp"
#include "gui_font.hpp"
#include "gui_theme.hpp"
#include "win32_util.hpp"

#include "dlp/i18n.hpp"

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_opengl2.h"

#include <windows.h>
#include <objbase.h>
#include <GL/gl.h>

#include <memory>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hwnd, UINT msg,
                                                             WPARAM wParam, LPARAM lParam);

namespace {

HGLRC       g_glContext = nullptr;
HDC         g_hdc       = nullptr;
WNDCLASSEXW g_wc{};

bool CreateDeviceGL(HWND hwnd) {
    g_hdc = GetDC(hwnd);
    if (!g_hdc) return false;

    PIXELFORMATDESCRIPTOR pfd{};
    pfd.nSize      = sizeof(pfd);
    pfd.nVersion   = 1;
    pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 24;

    const int pf = ChoosePixelFormat(g_hdc, &pfd);
    if (pf == 0 || !SetPixelFormat(g_hdc, pf, &pfd)) {
        ReleaseDC(hwnd, g_hdc);
        g_hdc = nullptr;
        return false;
    }

    g_glContext = wglCreateContext(g_hdc);
    if (!g_glContext) {
        ReleaseDC(hwnd, g_hdc);
        g_hdc = nullptr;
        return false;
    }
    if (!wglMakeCurrent(g_hdc, g_glContext)) {
        wglDeleteContext(g_glContext);
        g_glContext = nullptr;
        ReleaseDC(hwnd, g_hdc);
        g_hdc = nullptr;
        return false;
    }
    return true;
}

void DestroyDeviceGL(HWND hwnd) {
    wglMakeCurrent(nullptr, nullptr);
    if (g_glContext) { wglDeleteContext(g_glContext); g_glContext = nullptr; }
    if (g_hdc)       { ReleaseDC(hwnd, g_hdc);        g_hdc = nullptr; }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam)) return 1;

    switch (msg) {
        case WM_SIZE:
            if (wParam != SIZE_MINIMIZED && g_glContext != nullptr) {
                glViewport(0, 0,
                           static_cast<GLsizei>(LOWORD(lParam)),
                           static_cast<GLsizei>(HIWORD(lParam)));
            }
            return 0;
        case WM_SYSCOMMAND:
            if ((wParam & 0xFFF0) == SC_KEYMENU) return 0;
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int) {
    dlp::setLanguage(dlp::detectSystemLanguage());

    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    ImGui_ImplWin32_EnableDpiAwareness();

    g_wc.cbSize        = sizeof(g_wc);
    g_wc.style         = CS_HREDRAW | CS_VREDRAW;
    g_wc.lpfnWndProc   = WndProc;
    g_wc.hInstance     = hInstance;
    g_wc.hCursor       = LoadCursorW(nullptr, IDC_ARROW);
    g_wc.lpszClassName = L"DlpscanGuiWindow";

    if (RegisterClassExW(&g_wc) == 0) {
        MessageBoxW(nullptr,
                    dlpgui::Utf8ToWide(dlp::tr(dlp::S::GuiClassErrorTitle)).c_str(),
                    L"dlpscan", MB_ICONERROR);
        CoUninitialize();
        return 1;
    }

    HWND hwnd = CreateWindowExW(
        0, g_wc.lpszClassName,
        dlpgui::Utf8ToWide(dlp::tr(dlp::S::GuiWindowTitle)).c_str(),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1280, 800,
        nullptr, nullptr, hInstance, nullptr);

    if (!hwnd || !CreateDeviceGL(hwnd)) {
        MessageBoxW(nullptr,
                    dlpgui::Utf8ToWide(dlp::tr(dlp::S::GuiGlErrorTitle)).c_str(),
                    L"dlpscan", MB_ICONERROR);
        if (hwnd) DestroyWindow(hwnd);
        UnregisterClassW(g_wc.lpszClassName, hInstance);
        CoUninitialize();
        return 1;
    }

    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;

    float dpi = 1.0f;
    {
        const HDC screen = GetDC(nullptr);
        if (screen) {
            const int px = GetDeviceCaps(screen, LOGPIXELSX);
            if (px > 0) dpi = static_cast<float>(px) / 96.0f;
            ReleaseDC(nullptr, screen);
        }
    }
    if (dpi < 1.0f) dpi = 1.0f;
    if (dpi > 3.0f) dpi = 3.0f;

    dlpgui::LoadUiFonts(io, dpi);
    dlpgui::ApplyTheme(dlpgui::Theme::Dark);
    ImGui::GetStyle().ScaleAllSizes(dpi);

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplOpenGL2_Init();

    auto app = std::make_unique<dlpgui::GuiApp>(hwnd);

    bool running = true;
    while (running) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) running = false;
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        if (!running) break;

        ImGui_ImplOpenGL2_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        app->DrawUI();

        ImGui::Render();

        RECT rc{};
        GetClientRect(hwnd, &rc);
        glViewport(0, 0,
                   static_cast<GLsizei>(rc.right - rc.left),
                   static_cast<GLsizei>(rc.bottom - rc.top));
        glClearColor(0.10f, 0.10f, 0.11f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL2_RenderDrawData(ImGui::GetDrawData());
        SwapBuffers(g_hdc);
    }

    app.reset();

    ImGui_ImplOpenGL2_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    DestroyDeviceGL(hwnd);
    DestroyWindow(hwnd);
    UnregisterClassW(g_wc.lpszClassName, hInstance);
    CoUninitialize();
    return 0;
}
