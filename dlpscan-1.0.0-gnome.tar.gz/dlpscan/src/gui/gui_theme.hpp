#pragma once

#include "imgui.h"

namespace dlpgui {

enum class Theme { Dark, Light };

struct Palette {
    ImVec4 windowBg;
    ImVec4 headerBg;
    ImVec4 cardBg;
    ImVec4 viewBg;
    ImVec4 border;
    ImVec4 text;
    ImVec4 textDim;
    ImVec4 accent;
    ImVec4 accentHover;
    ImVec4 accentActive;
    ImVec4 onAccent;
    ImVec4 success;
    ImVec4 warning;
    ImVec4 error;
    ImVec4 destructive;
    ImVec4 sev[5];
    ImVec4 sevBg[5];
};

void ApplyTheme(Theme t);
Theme currentTheme();
const Palette& palette();

bool PillButton(const char* label, const ImVec2& size, bool suggested);
bool DestructivePillButton(const char* label, const ImVec2& size);
void SectionHeader(const char* label);
void Badge(const char* text, const ImVec4& fg, const ImVec4& bg);
void BeginCard(const char* id, const ImVec2& size);
void EndCard();

}
