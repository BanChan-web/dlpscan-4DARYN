#include "gui_font.hpp"

#include <windows.h>
#include <shlwapi.h>

#include <string>
#include <vector>

namespace dlpgui {

namespace {

UiFonts g_fonts;

const ImWchar* UiGlyphRanges() {
    static const ImWchar kRanges[] = {
        0x0020, 0x00FF,
        0x0100, 0x017F,
        0x0180, 0x024F,
        0x0370, 0x03FF,
        0x0400, 0x052F,
        0x2010, 0x205E,
        0x2070, 0x209F,
        0x20A0, 0x20BF,
        0x2190, 0x21FF,
        0x2200, 0x22FF,
        0x2500, 0x257F,
        0x25A0, 0x25FF,
        0x2600, 0x26FF,
        0,
    };
    return kRanges;
}

bool readFile(const std::wstring& path, std::vector<unsigned char>& out) {
    HANDLE h = ::CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                             OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;

    LARGE_INTEGER li{};
    if (!::GetFileSizeEx(h, &li) || li.QuadPart <= 0 || li.QuadPart > (64 << 20)) {
        ::CloseHandle(h);
        return false;
    }

    out.resize(static_cast<std::size_t>(li.QuadPart));
    DWORD got = 0;
    const BOOL ok = ::ReadFile(h, out.data(), static_cast<DWORD>(out.size()), &got, nullptr);
    ::CloseHandle(h);

    if (!ok || got != out.size()) { out.clear(); return false; }
    return true;
}

std::wstring exeDir() {
    wchar_t buf[MAX_PATH] = {};
    const DWORD n = ::GetModuleFileNameW(nullptr, buf, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return std::wstring();
    std::wstring p(buf, n);
    const std::size_t slash = p.find_last_of(L"\\/");
    return slash == std::wstring::npos ? std::wstring() : p.substr(0, slash + 1);
}

std::wstring winFontsDir() {
    wchar_t buf[MAX_PATH] = {};
    const UINT n = ::GetWindowsDirectoryW(buf, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return L"C:\\Windows\\Fonts\\";
    std::wstring p(buf, n);
    if (!p.empty() && p.back() != L'\\') p += L'\\';
    return p + L"Fonts\\";
}

struct Candidate {
    std::wstring regular;
    std::wstring bold;
};

std::vector<Candidate> candidates() {
    const std::wstring app = exeDir();
    const std::wstring win = winFontsDir();
    std::vector<Candidate> v;

    if (!app.empty()) {
        v.push_back({app + L"assets\\fonts\\Cantarell-Regular.ttf",
                     app + L"assets\\fonts\\Cantarell-Bold.ttf"});
        v.push_back({app + L"assets\\fonts\\Inter-Regular.ttf",
                     app + L"assets\\fonts\\Inter-SemiBold.ttf"});
        v.push_back({app + L"assets\\fonts\\NotoSans-Regular.ttf",
                     app + L"assets\\fonts\\NotoSans-Bold.ttf"});
        v.push_back({app + L"assets\\fonts\\DejaVuSans.ttf",
                     app + L"assets\\fonts\\DejaVuSans-Bold.ttf"});
        v.push_back({app + L"assets\\fonts\\ui.ttf", app + L"assets\\fonts\\ui-bold.ttf"});
    }

    v.push_back({win + L"segoeui.ttf",  win + L"segoeuib.ttf"});
    v.push_back({win + L"SegUIVar.ttf", win + L"SegUIVar.ttf"});
    v.push_back({win + L"tahoma.ttf",   win + L"tahomabd.ttf"});
    v.push_back({win + L"arial.ttf",    win + L"arialbd.ttf"});
    v.push_back({win + L"verdana.ttf",  win + L"verdanab.ttf"});
    v.push_back({win + L"calibri.ttf",  win + L"calibrib.ttf"});

    const wchar_t* const kWine[] = {
        L"Z:\\usr\\share\\fonts\\TTF\\DejaVuSans.ttf",
        L"Z:\\usr\\share\\fonts\\dejavu\\DejaVuSans.ttf",
        L"Z:\\usr\\share\\fonts\\truetype\\dejavu\\DejaVuSans.ttf",
        L"Z:\\usr\\share\\fonts\\noto\\NotoSans-Regular.ttf",
        L"Z:\\usr\\share\\fonts\\TTF\\LiberationSans-Regular.ttf",
        L"Z:\\usr\\share\\fonts\\liberation\\LiberationSans-Regular.ttf",
        L"Z:\\usr\\share\\fonts\\cantarell\\Cantarell-VF.otf",
    };
    for (const wchar_t* w : kWine) v.push_back({w, w});

    return v;
}

bool fontHasCyrillic(const std::vector<unsigned char>& data) {
    if (data.size() < 12) return false;
    ImFontAtlas probe;
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;
    ImFont* f = probe.AddFontFromMemoryTTF(
        const_cast<unsigned char*>(data.data()), static_cast<int>(data.size()),
        16.0f, &cfg, UiGlyphRanges());
    if (!f) return false;
    unsigned char* pixels = nullptr;
    int w = 0, h = 0;
    probe.GetTexDataAsAlpha8(&pixels, &w, &h);
    const bool ok = f->FindGlyphNoFallback(static_cast<ImWchar>(0x0416)) != nullptr &&
                    f->FindGlyphNoFallback(static_cast<ImWchar>(0x049A)) != nullptr;
    probe.Clear();
    return ok;
}

ImFont* addFromBytes(ImGuiIO& io, const std::vector<unsigned char>& data, float px) {
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;
    cfg.OversampleH = 2;
    cfg.OversampleV = 1;
    cfg.PixelSnapH  = false;
    return io.Fonts->AddFontFromMemoryTTF(
        const_cast<unsigned char*>(data.data()), static_cast<int>(data.size()),
        px, &cfg, UiGlyphRanges());
}

std::vector<unsigned char> g_regularBytes;
std::vector<unsigned char> g_boldBytes;

}

const UiFonts& fonts() { return g_fonts; }

UiFonts LoadUiFonts(ImGuiIO& io, float uiScale) {
    g_fonts = UiFonts();

    const float base  = 16.0f * uiScale;
    const float small = 13.0f * uiScale;
    const float title = 19.0f * uiScale;

    for (const Candidate& c : candidates()) {
        std::vector<unsigned char> reg;
        if (!readFile(c.regular, reg)) continue;
        if (!fontHasCyrillic(reg)) continue;

        g_regularBytes.swap(reg);
        if (!readFile(c.bold, g_boldBytes) || !fontHasCyrillic(g_boldBytes)) {
            g_boldBytes = g_regularBytes;
        }

        g_fonts.regular = addFromBytes(io, g_regularBytes, base);
        g_fonts.small   = addFromBytes(io, g_regularBytes, small);
        g_fonts.medium  = addFromBytes(io, g_boldBytes,    base);
        g_fonts.title   = addFromBytes(io, g_boldBytes,    title);
        g_fonts.cyrillicOk = (g_fonts.regular != nullptr);
        if (g_fonts.cyrillicOk) {
            io.FontDefault = g_fonts.regular;
            return g_fonts;
        }
    }

    ImFont* fallback = io.Fonts->AddFontDefault();
    g_fonts.regular = fallback;
    g_fonts.medium  = fallback;
    g_fonts.small   = fallback;
    g_fonts.title   = fallback;
    g_fonts.cyrillicOk = false;
    return g_fonts;
}

}
