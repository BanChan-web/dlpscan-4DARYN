#include "win32_util.hpp"

#include <objbase.h>
#include <shlobj.h>
#include <commdlg.h>

#include <iterator>
#include <vector>

namespace dlpgui {

std::wstring Utf8ToWide(const std::string& s) {
    if (s.empty()) return std::wstring();
    const int len = static_cast<int>(s.size());
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), len, nullptr, 0);
    if (n <= 0) return std::wstring();
    std::wstring w(static_cast<std::size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), len, w.data(), n);
    return w;
}

std::string WideToUtf8(const std::wstring& s) {
    if (s.empty()) return std::string();
    const int len = static_cast<int>(s.size());
    const int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), len,
                                      nullptr, 0, nullptr, nullptr);
    if (n <= 0) return std::string();
    std::string u(static_cast<std::size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), len, u.data(), n, nullptr, nullptr);
    return u;
}

bool BrowseForFolder(HWND owner, const wchar_t* title, std::wstring& outPath) {
    wchar_t displayName[MAX_PATH] = {};

    BROWSEINFOW bi{};
    bi.hwndOwner      = owner;
    bi.pszDisplayName = displayName;
    bi.lpszTitle      = title;
    bi.ulFlags        = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_EDITBOX;

    LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return false;

    wchar_t pathBuf[MAX_PATH] = {};
    const BOOL ok = SHGetPathFromIDListW(pidl, pathBuf);
    CoTaskMemFree(pidl);

    if (!ok) return false;
    outPath = pathBuf;
    return true;
}

bool SaveFileDialog(HWND owner, const wchar_t* filter, const wchar_t* defExt,
                    std::wstring& outPath) {
    wchar_t fileBuf[MAX_PATH] = {};

    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = owner;
    ofn.lpstrFilter = filter;
    ofn.lpstrFile   = fileBuf;
    ofn.nMaxFile    = static_cast<DWORD>(std::size(fileBuf));
    ofn.lpstrDefExt = defExt;
    ofn.Flags       = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

    if (!GetSaveFileNameW(&ofn)) return false;
    outPath = fileBuf;
    return true;
}

}
