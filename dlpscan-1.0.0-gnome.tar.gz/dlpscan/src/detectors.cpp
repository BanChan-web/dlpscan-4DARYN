#include "dlp/detectors.hpp"

#include "dlp/entropy.hpp"
#include "dlp/validators.hpp"

#include <algorithm>
#include <cstring>

namespace dlp {

namespace {

inline bool isDigitB(u8 c) noexcept { return c >= '0' && c <= '9'; }
inline bool isAlnumB(u8 c) noexcept {
    return isDigitB(c) || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}
inline bool isSepB(u8 c) noexcept { return c == ' ' || c == '-'; }

inline bool isTokenChar(u8 c) noexcept {
    return isAlnumB(c) || c == '+' || c == '/' || c == '=' || c == '_' || c == '-' || c == '.';
}

bool containsI(const u8* data, std::size_t n, const char* needle) noexcept {
    const std::size_t m = std::strlen(needle);
    if (m == 0 || n < m) return false;
    for (std::size_t i = 0; i + m <= n; ++i) {
        std::size_t j = 0;
        for (; j < m; ++j) {
            u8 a = data[i + j];
            if (a >= 'A' && a <= 'Z') a = static_cast<u8>(a - 'A' + 'a');
            if (a != static_cast<u8>(needle[j])) break;
        }
        if (j == m) return true;
    }
    return false;
}

bool containsRaw(const u8* data, std::size_t n, const char* needle) noexcept {
    const std::size_t m = std::strlen(needle);
    if (m == 0 || n < m) return false;
    return std::search(data, data + n,
                       reinterpret_cast<const u8*>(needle),
                       reinterpret_cast<const u8*>(needle) + m) != data + n;
}

}

void scanNumericRuns(const u8* data, std::size_t n, const NumericOptions& opt,
                     std::vector<NumericHit>& out) {
    if (!data || n < 12) return;
    if (!opt.findCards && !opt.findIin) return;

    std::string digits;
    digits.reserve(32);

    std::size_t i = 0;
    while (i < n) {
        if (!isDigitB(data[i])) { ++i; continue; }

        if (i > 0 && isAlnumB(data[i - 1])) {
            while (i < n && isAlnumB(data[i])) ++i;
            continue;
        }

        digits.clear();
        const std::size_t start = i;
        std::size_t j = i;
        bool overflow = false;

        while (j < n) {
            if (isDigitB(data[j])) {
                if (digits.size() >= opt.maxRunDigits) { overflow = true; break; }
                digits.push_back(static_cast<char>(data[j]));
                ++j;
            } else if (isSepB(data[j]) && j + 1 < n && isDigitB(data[j + 1]) && !digits.empty()) {
                ++j;
            } else {
                break;
            }
        }

        if (overflow) {
            while (j < n && (isDigitB(data[j]) || isSepB(data[j]))) ++j;
            i = j;
            continue;
        }

        const bool rightBoundary = (j >= n) || !isAlnumB(data[j]);
        const std::size_t len = j - start;

        if (rightBoundary && digits.size() >= 12) {
            bool interesting = false;
            if (opt.findIin && digits.size() == 12) interesting = true;
            if (opt.findCards && digits.size() >= 13 && digits.size() <= 19) interesting = true;
            if (interesting) {
                NumericHit h;
                h.start = start;
                h.length = len;
                h.digits = digits;
                out.push_back(std::move(h));
            }
        }
        i = j > i ? j : i + 1;
    }
}

void scanEntropicTokens(const u8* data, std::size_t n, const TokenOptions& opt,
                        std::vector<TokenHit>& out) {
    if (!data || n < opt.minLen) return;

    std::size_t i = 0;
    while (i < n) {
        if (!isTokenChar(data[i])) { ++i; continue; }
        const std::size_t start = i;
        while (i < n && isTokenChar(data[i])) ++i;
        const std::size_t fullLen = i - start;
        if (fullLen < opt.minLen) continue;

        const std::size_t len = std::min(fullLen, opt.maxLen);

        const std::string_view tok(reinterpret_cast<const char*>(data + start), len);

        bool hasDigit = false, hasAlpha = false, hasUpper = false, hasLower = false;
        for (char c : tok) {
            if (c >= '0' && c <= '9') hasDigit = true;
            else if (c >= 'a' && c <= 'z') { hasAlpha = true; hasLower = true; }
            else if (c >= 'A' && c <= 'Z') { hasAlpha = true; hasUpper = true; }
        }
        if (!hasDigit || !hasAlpha) continue;
        if (isUuid(tok)) continue;
        if (isHexString(tok) && len >= 32 && !(hasUpper && hasLower)) {

            if (!hasSecretContext(data, n, start)) continue;
        }

        const double h = tokenEntropy(tok);
        if (h < opt.minEntropy) continue;

        const bool strong = (h >= opt.strongEntropy && len >= opt.strongMinLen);
        if (!strong && !hasSecretContext(data, n, start)) continue;

        TokenHit t;
        t.start = start;
        t.length = len;
        t.fullLength = fullLen;
        t.entropy = h;
        out.push_back(t);
    }
}

bool hasSecretContext(const u8* data, std::size_t n, std::size_t pos,
                      std::size_t window) {
    if (!data || pos > n) return false;
    const std::size_t b = pos > window ? pos - window : 0;
    const std::size_t e = std::min(n, pos + window);
    const u8* p = data + b;
    const std::size_t len = e - b;

    static const char* kAscii[] = {
        "key", "secret", "token", "passw", "pwd", "credential", "auth", "bearer",
        "private", "apikey", "api_key", "access", "signature", "session", "cookie",
    };
    for (const char* w : kAscii) if (containsI(p, len, w)) return true;

    static const char* kCyr[] = {"парол", "Парол", "ПАРОЛ", "ключ", "Ключ", "секрет", "токен", "доступ"};
    for (const char* w : kCyr) if (containsRaw(p, len, w)) return true;
    return false;
}

bool hasIinContext(const u8* data, std::size_t n, std::size_t pos,
                   std::size_t window) {
    if (!data || pos > n) return false;
    const std::size_t b = pos > window ? pos - window : 0;
    const std::size_t e = std::min(n, pos + window);
    const u8* p = data + b;
    const std::size_t len = e - b;

    static const char* kAscii[] = {"iin", "bin", "individual identification"};
    for (const char* w : kAscii) if (containsI(p, len, w)) return true;

    static const char* kCyr[] = {
        "ИИН", "иин", "Иин", "БИН", "бин", "ЖСН", "жсн",
        "удостовер", "паспорт", "физ. лиц", "физлиц"
    };
    for (const char* w : kCyr) if (containsRaw(p, len, w)) return true;
    return false;
}

}
