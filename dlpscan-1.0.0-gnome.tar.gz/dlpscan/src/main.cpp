#include "dlp/i18n.hpp"
#include "dlp/cli.hpp"
#include "dlp/file_walker.hpp"
#include "dlp/finding.hpp"
#include "dlp/report.hpp"
#include "dlp/rules.hpp"
#include "dlp/scanner.hpp"
#include "dlp/selftest.hpp"
#include "dlp/thread_pool.hpp"

#include <atomic>
#include <chrono>
#include <csignal>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <mutex>
#include <thread>

namespace {

std::atomic<bool> g_cancel{false};

void onSignal(int) { g_cancel.store(true, std::memory_order_relaxed); }

}

namespace {

using namespace dlp;

template <typename Fn>
void emit(std::ostream& os, Fn&& render) {
    std::ostringstream buf;
    render(buf);
    writeConsoleUtf8(os, buf.str());
}

void emitLine(std::ostream& os, const std::string& text) {
    writeConsoleUtf8(os, text);
}

void printProgress(const ScanStats& stats, double elapsed, std::size_t queued) {
    const double mb = static_cast<double>(stats.bytesScanned.load()) / (1024.0 * 1024.0);
    std::ostringstream line;
    line << std::fixed << std::setprecision(1);
    line << trf(S::MainProgress,
                static_cast<unsigned long long>(stats.filesScanned.load()),
                humanBytes(stats.bytesScanned.load()).c_str(),
                static_cast<unsigned long long>(stats.findings.load()),
                queued, humanDuration(elapsed).c_str(),
                elapsed > 0 ? mb / elapsed : 0.0);
    writeConsoleUtf8(std::cerr, line.str());
    std::cerr.flush();
}

void listRules(const RuleSet& rs, std::ostream& os) {
    os << trf(S::MainActiveRules, rs.enabledCount()) << ":\n\n";

    os << tr(S::MainRulesHeader) << '\n';
    os << std::string(78, '-') << '\n';
    for (const Rule& r : rs.rules()) {
        if (!r.enabled) continue;
        os << std::left << std::setw(26) << r.id
           << std::setw(11) << severityName(r.severity)
           << r.name << '\n';
        if (!r.description.empty() && r.description != r.name) {
            os << std::string(26, ' ') << "  " << r.description << '\n';
        }
    }
    os << tr(S::MainBuiltinHeader) << '\n';
    os << tr(S::MainBuiltinCard) << '\n';
    os << tr(S::MainBuiltinIin) << '\n';
    os << tr(S::MainBuiltinToken) << '\n';
    os << tr(S::MainBuiltinPacked) << '\n';
    os << tr(S::MainBuiltinContainer) << '\n';
    os << tr(S::MainBuiltinMismatch) << '\n';
    os << tr(S::MainBuiltinRegion) << '\n';
}

}

int main(int argc, char** argv) {
    enableConsoleUtf8AndAnsi();
    setLanguage(detectSystemLanguage());
    std::signal(SIGINT, onSignal);
#ifdef SIGTERM
    std::signal(SIGTERM, onSignal);
#endif

    CliResult cli = parseCommandLine(argc, argv);

    switch (cli.action) {
        case CliAction::Help:     emit(std::cout, [](std::ostream& o){ printHelp(o); });    return 0;
        case CliAction::Version:  emit(std::cout, [](std::ostream& o){ printVersion(o); }); return 0;
        case CliAction::SelfTest: {
            std::ostringstream b;
            const int rc = runSelfTests(b);
            writeConsoleUtf8(std::cout, b.str());
            return rc == 0 ? 0 : 3;
        }
        case CliAction::Error:
            emitLine(std::cerr, std::string(tr(S::MainErrorPrefix)) + cli.error + tr(S::MainHelpHint));
            return 2;
        default: break;
    }

    ScanConfig& cfg = cli.config;

    RuleSet rules;
    rules.loadDefaults();
    if (!cfg.rulesFile.empty()) {
        std::string err;
        if (!rules.loadFromFile(utf8ToPath(cfg.rulesFile), err)) {
            emitLine(std::cerr, std::string(tr(S::MainErrorPrefix)) + err + "\n");
            return 2;
        }
    }
    rules.applyFilters(cfg.onlyRules, cfg.disabledRules);

    std::string err;
    if (!rules.compile(err)) {
        emitLine(std::cerr, std::string(tr(S::MainErrorPrefix)) + err + "\n");
        return 2;
    }

    if (cli.action == CliAction::ListRules) {
        emit(std::cout, [&](std::ostream& o){ listRules(rules, o); });
        return 0;
    }

    ScanStats stats;
    FindingSink sink(cfg.maxFindings);
    Scanner scanner(rules, cfg, stats);
    BoundedQueue<FileTask> queue(cfg.queueCapacity);

    const auto t0 = std::chrono::steady_clock::now();
    const std::string startedAt = nowIso8601Utc();

    if (!cfg.quiet) {
        std::ostringstream banner;
        banner << "dlpscan " << kVersion << tr(S::MainStart);
        for (const fs::path& p : cfg.roots) {
            banner << tr(S::MainTarget) << pathToUtf8(p) << '\n';
        }
        banner << tr(S::MainRulesCount) << rules.enabledCount()
                  << tr(S::MainAnchors) << rules.prefilter().patternCount()
                  << tr(S::MainThreadsCount) << cfg.threads << '\n';
        writeConsoleUtf8(std::cout, banner.str());
    }

    std::mutex errMtx;
    std::vector<std::string> ioErrors;

    auto worker = [&]() {
        ScanContext ctx;
        FileTask task;
        while (queue.pop(task)) {
            if (g_cancel.load(std::memory_order_relaxed)) break;
            ctx.out.clear();
            std::string e;
            if (!scanner.scanFile(task.path, ctx, e)) {
                stats.filesUnreadable.fetch_add(1, std::memory_order_relaxed);
                if (cfg.verbose) {
                    std::lock_guard<std::mutex> lk(errMtx);
                    if (ioErrors.size() < 200) {
                        ioErrors.push_back(pathToUtf8(task.path) + ": " + e);
                    }
                }
                continue;
            }
            sink.addBatch(ctx.out);
        }
    };

    std::vector<std::thread> workers;
    workers.reserve(cfg.threads);
    for (unsigned i = 0; i < cfg.threads; ++i) workers.emplace_back(worker);

    FileWalker walker(cfg, stats, g_cancel);
    std::thread producer([&]() {
        walker.run(queue);
        queue.close();
    });

    std::thread progress;
    std::atomic<bool> progressDone{false};
    if (cfg.progress) {
        progress = std::thread([&]() {
            while (!progressDone.load(std::memory_order_relaxed)) {
                const double el = std::chrono::duration<double>(
                    std::chrono::steady_clock::now() - t0).count();
                printProgress(stats, el, queue.size());
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
            }
        });
    }

    producer.join();
    for (std::thread& t : workers) t.join();
    progressDone.store(true, std::memory_order_relaxed);
    if (progress.joinable()) progress.join();
    if (cfg.progress) std::cerr << "\r" << std::string(78, ' ') << "\r" << std::flush;

    const double seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - t0).count();

    ScanSummary summary;
    summary.findings        = sink.take();
    summary.config          = cfg;
    summary.seconds         = seconds;
    summary.filesScanned    = stats.filesScanned.load();
    summary.filesSkipped    = stats.filesSkipped.load();
    summary.filesUnreadable = stats.filesUnreadable.load();
    summary.bytesScanned    = stats.bytesScanned.load();
    summary.regexRuns       = stats.regexRuns.load();
    summary.prefilterHits   = stats.prefilterHits.load();
    summary.threads         = cfg.threads;
    summary.ruleCount       = rules.enabledCount();
    summary.truncated       = sink.truncated();
    summary.startedAt       = startedAt;
    summary.version         = kVersion;
    summary.errors          = walker.errors();
    {
        std::lock_guard<std::mutex> lk(errMtx);
        for (const std::string& e : ioErrors) summary.errors.push_back(e);
    }

    std::sort(summary.findings.begin(), summary.findings.end());

    if (!cfg.quiet) {
        emit(std::cout, [&](std::ostream& o){ writeConsoleReport(summary, o, cfg.color); });
    }

    struct Out { const std::string& path; bool (*fn)(const ScanSummary&, const fs::path&, std::string&); const char* kind; };
    const Out outs[] = {
        {cfg.jsonOut, &writeJsonReport, "JSON"},
        {cfg.csvOut,  &writeCsvReport,  "CSV"},
        {cfg.htmlOut, &writeHtmlReport, "HTML"},
    };
    for (const Out& o : outs) {
        if (o.path.empty()) continue;
        std::string e;
        if (o.fn(summary, utf8ToPath(o.path), e)) {
            if (!cfg.quiet) {
                emitLine(std::cout, std::string(tr(S::MainReport)) + o.kind + ": " + o.path + "\n");
            }
        } else {
            emitLine(std::cerr, std::string(tr(S::MainReportError)) + o.kind + ": " + e + "\n");
            return 2;
        }
    }

    if (cfg.quiet) {
        const auto h = severityHistogram(summary.findings);
        std::cout << "findings=" << summary.findings.size()
                  << " critical=" << h[4] << " high=" << h[3] << " medium=" << h[2]
                  << " low=" << h[1] << " info=" << h[0]
                  << " files=" << summary.filesScanned
                  << " seconds=" << std::fixed << std::setprecision(2) << seconds << '\n';
    }

    if (g_cancel.load()) {
        emitLine(std::cerr, tr(S::MainInterrupted));
        return 2;
    }

    const bool failed = std::any_of(
        summary.findings.begin(), summary.findings.end(),
        [&](const Finding& f) {
            return static_cast<int>(f.severity) >= static_cast<int>(cfg.failOn);
        });
    return failed ? 1 : 0;
}
