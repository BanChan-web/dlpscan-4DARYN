#include "dlp/entropy.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace dlp {

namespace {

inline double flog(u64 c) noexcept {
    static const double kLog2 = std::log(2.0);
    if (c < 2) return 0.0;
    return static_cast<double>(c) * (std::log(static_cast<double>(c)) / kLog2);
}

inline bool isPrintableOrUtf8(u8 b) noexcept {
    return (b >= 0x20 && b < 0x7F) || b == '\n' || b == '\r' || b == '\t' || b >= 0x80;
}

inline bool isPrintableAscii(u8 b) noexcept {
    return (b >= 0x20 && b < 0x7F) || b == '\n' || b == '\r' || b == '\t';
}

}

void EntropyCounter::reset() noexcept {
    counts_.fill(0);
    total_ = 0;
    sumFLog_ = 0.0;
}

void EntropyCounter::add(u8 b) noexcept {
    const u64 c = counts_[b];
    sumFLog_ += flog(c + 1) - flog(c);
    counts_[b] = c + 1;
    ++total_;
}

void EntropyCounter::remove(u8 b) noexcept {
    const u64 c = counts_[b];
    if (c == 0) return;
    sumFLog_ += flog(c - 1) - flog(c);
    counts_[b] = c - 1;
    --total_;
}

void EntropyCounter::addRange(const u8* data, std::size_t n) noexcept {

    u64 local[256] = {0};
    for (std::size_t i = 0; i < n; ++i) ++local[data[i]];
    for (int i = 0; i < 256; ++i) {
        if (!local[i]) continue;
        const u64 c = counts_[static_cast<std::size_t>(i)];
        const u64 nc = c + local[i];
        sumFLog_ += flog(nc) - flog(c);
        counts_[static_cast<std::size_t>(i)] = nc;
        total_ += local[i];
    }
}

double EntropyCounter::entropy() const noexcept {
    if (total_ == 0) return 0.0;
    static const double kLog2 = std::log(2.0);
    const double n = static_cast<double>(total_);
    const double h = (std::log(n) / kLog2) - sumFLog_ / n;
    return h < 0.0 ? 0.0 : (h > 8.0 ? 8.0 : h);
}

double EntropyCounter::chiSquareUniform() const noexcept {
    if (total_ == 0) return 0.0;
    const double expected = static_cast<double>(total_) / 256.0;
    double chi = 0.0;
    for (int i = 0; i < 256; ++i) {
        const double d = static_cast<double>(counts_[static_cast<std::size_t>(i)]) - expected;
        chi += d * d / expected;
    }
    return chi;
}

u32 EntropyCounter::distinctBytes() const noexcept {
    u32 n = 0;
    for (int i = 0; i < 256; ++i) if (counts_[static_cast<std::size_t>(i)]) ++n;
    return n;
}

double shannonEntropy(const u8* data, std::size_t n) noexcept {
    if (!data || n == 0) return 0.0;
    EntropyCounter c;
    c.addRange(data, n);
    return c.entropy();
}

double tokenEntropy(std::string_view token) noexcept {
    if (token.empty()) return 0.0;
    return shannonEntropy(reinterpret_cast<const u8*>(token.data()), token.size());
}

bool looksLikeText(const u8* data, std::size_t n) noexcept {
    if (n == 0) return true;
    const std::size_t probe = std::min<std::size_t>(n, 8192);
    std::size_t printable = 0;
    for (std::size_t i = 0; i < probe; ++i) {
        if (data[i] == 0) return false;
        if (isPrintableOrUtf8(data[i])) ++printable;
    }
    return static_cast<double>(printable) / static_cast<double>(probe) >= 0.85;
}

EntropyProfiler::EntropyProfiler(std::size_t window, std::size_t step,
                                 double threshold) noexcept
    : window_(window ? window : 8192),
      step_(step ? step : window_ / 2),
      threshold_(threshold) {
    ring_.resize(window_);
}

void EntropyProfiler::slide() noexcept {
    const double h = win_.entropy();
    ++prof_.windowsTotal;
    if (h > prof_.maxWindowEntropy) {
        prof_.maxWindowEntropy = h;
        prof_.maxWindowOffset  = windowStart_;
    }
    if (h >= threshold_) ++prof_.windowsAbove;
}

void EntropyProfiler::feed(const u8* data, std::size_t n, u64 absoluteOffset) noexcept {
    if (n == 0) return;
    if (prof_.windowsTotal == 0 && ringSize_ == 0) windowStart_ = absoluteOffset;

    global_.addRange(data, n);
    for (std::size_t i = 0; i < n; ++i) {
        const u8 b = data[i];
        if (b == 0) prof_.containsNul = true;
        if (isPrintableAscii(b)) ++printable_;

        if (ringSize_ == window_) {
            const u8 old = ring_[ringHead_];
            win_.remove(old);
            ring_[ringHead_] = b;
            ringHead_ = (ringHead_ + 1) % window_;
            win_.add(b);
            ++windowStart_;
            if (++sinceStep_ >= step_) { sinceStep_ = 0; slide(); }
        } else {
            ring_[(ringHead_ + ringSize_) % window_] = b;
            ++ringSize_;
            win_.add(b);
            if (ringSize_ == window_) slide();
        }
    }
}

EntropyProfile EntropyProfiler::finish() noexcept {

    if (prof_.windowsTotal == 0 && win_.total() > 0) slide();
    prof_.fileEntropy = global_.entropy();
    const u64 total = global_.total();
    prof_.printableRatio = total ? static_cast<double>(printable_) / static_cast<double>(total) : 1.0;
    if (prof_.maxWindowEntropy < prof_.fileEntropy) prof_.maxWindowEntropy = prof_.fileEntropy;
    return prof_;
}

namespace {

inline bool startsWith(const u8* d, std::size_t n, const char* sig, std::size_t len) noexcept {
    return n >= len && std::memcmp(d, sig, len) == 0;
}

}

SniffResult sniffContentType(const u8* data, std::size_t n) noexcept {
    SniffResult r;
    if (!data || n < 4) return r;

    struct Sig { const char* magic; std::size_t len; const char* name; bool comp; bool enc; };
    static const Sig kSigs[] = {
        {"Salted__",                  8, "OpenSSL encrypted",     false, true },
        {"age-encryption.org/v1",    21, "age encrypted",         false, true },
        {"LUKS\xBA\xBE",              6, "LUKS container",        false, true },
        {"-----BEGIN PGP MESSAGE",   22, "PGP message",           false, true },
        {"\x85\x02\x0C\x03",          4, "GPG encrypted",         false, true },
        {"7z\xBC\xAF\x27\x1C",        6, "7-Zip",                 true,  false},
        {"Rar!\x1A\x07",              6, "RAR",                   true,  false},
        {"PK\x03\x04",                4, "ZIP/OOXML",             true,  false},
        {"\x1F\x8B",                  2, "GZIP",                  true,  false},
        {"\xFD" "7zXZ",               6, "XZ",                    true,  false},
        {"BZh",                       3, "BZIP2",                 true,  false},
        {"\x28\xB5\x2F\xFD",          4, "Zstandard",             true,  false},
        {"%PDF-",                     5, "PDF",                   false, false},
        {"\x89PNG\r\n\x1A\n",         8, "PNG",                   false, false},
        {"\xFF\xD8\xFF",              3, "JPEG",                  false, false},
        {"GIF8",                      4, "GIF",                   false, false},
        {"SQLite format 3",          15, "SQLite DB",             false, false},
        {"\x7F" "ELF",                4, "ELF executable",        false, false},
        {"MZ",                        2, "PE/EXE",                false, false},
        {"\xD0\xCF\x11\xE0",          4, "MS Office (OLE2)",      false, false},
        {"\x50\x4B\x05\x06",          4, "ZIP (empty)",           true,  false},
        {"OggS",                      4, "OGG",                   false, false},
        {"\x00\x01\x00\x00\x00",      5, "TrueType font",         false, false},
    };

    for (const Sig& s : kSigs) {
        if (startsWith(data, n, s.magic, s.len)) {
            r.type = s.name; r.compressed = s.comp; r.encrypted = s.enc;
            return r;
        }
    }
    return r;
}

}
