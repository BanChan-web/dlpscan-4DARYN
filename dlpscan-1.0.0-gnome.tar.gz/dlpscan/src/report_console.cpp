#include "dlp/i18n.hpp"
#include "dlp/report.hpp"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>

namespace dlp {

std::array<u64, 5> severityHistogram(const std::vector<Finding>& f) {
    std::array<u64, 5> h{};
    for (const Finding& x : f) ++h[static_cast<std::size_t>(x.severity)];
    return h;
}

namespace {

struct Palette {
    const char* reset;
    const char* dim;
    const char* bold;
    const char* crit;
    const char* high;
    const char* med;
    const char* low;
    const char* info;
    const char* path;
};

Palette makePalette(bool color) {
    if (!color) return {"", "", "", "", "", "", "", "", ""};
    return {
        "\033[0m", "\033[2m", "\033[1m",
        "\033[1;97;41m",
        "\033[1;31m",
        "\033[1;33m",
        "\033[36m",
        "\033[2;37m",
        "\033[1;36m",
    };
}

const char* colorFor(const Palette& p, Severity s) {
    switch (s) {
        case Severity::Critical: return p.crit;
        case Severity::High:     return p.high;
        case Severity::Medium:   return p.med;
        case Severity::Low:      return p.low;
        case Severity::Info:     return p.info;
    }
    return p.info;
}

}

void writeConsoleReport(const ScanSummary& s, std::ostream& os, bool color) {
    const Palette p = makePalette(color);
    const auto hist = severityHistogram(s.findings);

    os << '\n' << p.bold
       << "══════════════════════════" << tr(S::RepTitle) << "══════════════════════════"
       << p.reset << '\n';

    if (s.findings.empty()) {
        os << tr(S::RepNothingFound);
    } else {

        std::vector<const Finding*> sorted;
        sorted.reserve(s.findings.size());
        for (const Finding& f : s.findings) sorted.push_back(&f);
        std::sort(sorted.begin(), sorted.end(),
                  [](const Finding* a, const Finding* b) { return *a < *b; });

        std::string currentFile;
        std::size_t shown = 0;
        const std::size_t limit = s.config.showAllFindings ? sorted.size()
                                                           : std::min<std::size_t>(sorted.size(), 200);

        for (std::size_t i = 0; i < limit; ++i) {
            const Finding& f = *sorted[i];
            if (f.file != currentFile) {
                currentFile = f.file;
                os << '\n' << p.path << currentFile << p.reset << '\n';
            }
            os << "  " << colorFor(p, f.severity) << ' '
               << std::left << std::setw(8) << severityNameLocalized(f.severity) << ' ' << p.reset
               << ' ' << f.ruleName;
            if (f.line > 0) {
                os << p.dim << tr(S::RepLine) << f.line << tr(S::RepColumn) << f.column << ')' << p.reset;
            } else {
                os << p.dim << tr(S::RepOffset) << f.offset << ')' << p.reset;
            }
            os << '\n';
            os << "      " << p.dim << f.preview << p.reset << '\n';
            if (!f.note.empty()) {
                os << "      " << p.dim << "└─ " << f.note << p.reset << '\n';
            }
            ++shown;
        }
        if (shown < sorted.size()) {
            os << '\n' << p.dim
               << trf(S::RepAndMore, sorted.size() - shown)
               << tr(S::RepOrShowAll) << p.reset << '\n';
        }
    }

    os << '\n' << p.bold << tr(S::RepSummary) << p.reset << '\n';
    os << tr(S::RepCritical) << p.crit << ' ' << hist[4] << ' ' << p.reset
       << tr(S::RepHigh)   << p.high << hist[3] << p.reset
       << tr(S::RepMedium) << p.med  << hist[2] << p.reset
       << tr(S::RepLow)    << p.low  << hist[1] << p.reset
       << tr(S::RepInfo)   << p.info << hist[0] << p.reset << '\n';

    const double mb = static_cast<double>(s.bytesScanned) / (1024.0 * 1024.0);
    const double speed = s.seconds > 0.0 ? mb / s.seconds : 0.0;
    const double fps = s.seconds > 0.0 ? static_cast<double>(s.filesScanned) / s.seconds : 0.0;

    std::ostringstream num;
    num << std::fixed << std::setprecision(1);
    num << tr(S::RepScanned) << s.filesScanned << tr(S::RepFiles)
        << humanBytes(s.bytesScanned) << ")";
    os << num.str() << tr(S::RepSkipped) << s.filesSkipped;
    if (s.filesUnreadable) os << tr(S::RepUnreadable) << s.filesUnreadable;
    os << '\n';

    std::ostringstream perf;
    perf << std::fixed << std::setprecision(1);
    perf << tr(S::RepTime) << humanDuration(s.seconds) << tr(S::RepInThreads) << s.threads
         << tr(S::RepThreadsSuffix) << speed << tr(S::RepMbPerSec) << fps
         << tr(S::RepFilesPerSec);
    os << perf.str() << '\n';

    if (s.prefilterHits > 0 || s.regexRuns > 0) {
        os << p.dim << tr(S::RepPrefilter) << s.prefilterHits << tr(S::RepAnchorHits)
           << s.regexRuns << tr(S::RepRegexRuns) << p.reset << '\n';
    }
    if (s.truncated) {
        os << p.med << tr(S::RepTruncated)
           << p.reset << '\n';
    }
    if (!s.errors.empty()) {
        os << p.dim << tr(S::RepAccessErrors) << s.errors.size() << p.reset << '\n';
        for (std::size_t i = 0; i < std::min<std::size_t>(s.errors.size(), 5); ++i) {
            os << p.dim << "    - " << s.errors[i] << p.reset << '\n';
        }
    }
    os << '\n';
}

}
