#include "dlp/i18n.hpp"
#include "dlp/report.hpp"

#include <fstream>
#include <iomanip>
#include <sstream>

namespace dlp {

namespace {

std::string localizeHtml(std::string tpl) {
    struct Sub { const char* key; S id; };
    static const Sub kSubs[] = {
        {"@@TITLE@@",    S::HtmlDocTitle},
        {"@@H1@@",       S::HtmlH1},
        {"@@FILTER@@",   S::HtmlFilterPlaceholder},
        {"@@ALL@@",      S::HtmlAllLevels},
        {"@@ONLYCRIT@@", S::HtmlOnlyCritical},
        {"@@HIGHUP@@",   S::HtmlHighAndUp},
        {"@@MEDUP@@",    S::HtmlMediumAndUp},
        {"@@THL@@",      S::HtmlThLevel},
        {"@@THR@@",      S::HtmlThRule},
        {"@@THF@@",      S::HtmlThFile},
        {"@@THP@@",      S::HtmlThPosition},
        {"@@THG@@",      S::HtmlThFragment},
        {"@@FOOTER@@",   S::HtmlFooter},
        {"@@SHOWN@@",    S::HtmlShownPrefix},
        {"@@OF@@",       S::HtmlShownOf},
    };
    for (const Sub& sub : kSubs) {
        const std::string key = sub.key;
        const std::string val = tr(sub.id);
        std::size_t pos = 0;
        while ((pos = tpl.find(key, pos)) != std::string::npos) {
            tpl.replace(pos, key.size(), val);
            pos += val.size();
        }
    }
    return tpl;
}

}

std::string htmlEscape(std::string_view s) {
    std::string out;
    out.reserve(s.size() + 16);
    for (char c : s) {
        switch (c) {
            case '&':  out += "&amp;";  break;
            case '<':  out += "&lt;";   break;
            case '>':  out += "&gt;";   break;
            case '"':  out += "&quot;"; break;
            case '\'': out += "&#39;";  break;
            default:   out += c;
        }
    }
    return out;
}

bool writeHtmlReport(const ScanSummary& s, const fs::path& path, std::string& error) {
    std::ofstream out(path, std::ios::binary);
    if (!out) {
        error = trf(S::ErrCannotCreate, pathToUtf8(path).c_str());
        return false;
    }

    const auto hist = severityHistogram(s.findings);
    const double mb = static_cast<double>(s.bytesScanned) / (1024.0 * 1024.0);
    const double speed = s.seconds > 0.0 ? mb / s.seconds : 0.0;

    out << std::fixed << std::setprecision(2);
    out << localizeHtml(
R"(<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@@TITLE@@</title>
<style>
:root{--bg:#0f1218;--panel:#171b23;--line:#262c38;--fg:#e6e9ef;--muted:#99a1b3;
--crit:#ff4d5e;--high:#ff8a3d;--med:#ffd23d;--low:#4dc3ff;--info:#7a879e;}
@media(prefers-color-scheme:light){:root{--bg:#f6f7f9;--panel:#fff;--line:#e2e5ea;
--fg:#1a1d23;--muted:#5c6578;}}
*{box-sizing:border-box}
body{margin:0;padding:24px;background:var(--bg);color:var(--fg);
font:14px/1.5 "Segoe UI",Roboto,system-ui,sans-serif}
h1{font-size:20px;margin:0 0 4px}
.sub{color:var(--muted);margin-bottom:20px;font-size:13px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;
padding:12px 18px;min-width:110px}
.card .n{font-size:24px;font-weight:700}
.card .l{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em}
.bar{display:flex;gap:8px;align-items:center;margin-bottom:14px;flex-wrap:wrap}
input[type=search],select{background:var(--panel);color:var(--fg);
border:1px solid var(--line);border-radius:8px;padding:8px 10px;font-size:13px}
input[type=search]{min-width:280px;flex:1}
table{width:100%;border-collapse:collapse;background:var(--panel);
border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid var(--line);
vertical-align:top;font-size:13px}
th{background:rgba(127,127,127,.08);font-weight:600;color:var(--muted);
text-transform:uppercase;font-size:11px;letter-spacing:.05em;cursor:pointer}
tr:last-child td{border-bottom:none}
.sev{font-weight:700;font-size:11px;padding:2px 8px;border-radius:20px;
white-space:nowrap;color:#0f1218}
.critical{background:var(--crit)}.high{background:var(--high)}.medium{background:var(--med)}
.low{background:var(--low)}.info{background:var(--info)}
.path{font-family:ui-monospace,Consolas,monospace;font-size:12px;word-break:break-all}
.prev{font-family:ui-monospace,Consolas,monospace;font-size:12px;
color:var(--muted);word-break:break-all;max-width:520px}
.note{color:var(--muted);font-size:11px;margin-top:3px}
footer{color:var(--muted);font-size:12px;margin-top:18px}
.hidden{display:none}
</style></head><body>
<h1>@@H1@@</h1>
<div class="sub">)");
    out << htmlEscape(s.startedAt) << " · dlpscan " << htmlEscape(s.version)
        << tr(S::HtmlScanned) << s.filesScanned << tr(S::HtmlFilesIn)
        << humanBytes(s.bytesScanned) << tr(S::HtmlIn) << humanDuration(s.seconds)
        << tr(S::HtmlDash) << speed << tr(S::HtmlMbInThreads) << s.threads
        << tr(S::HtmlThreads);

    out << "<div class=\"cards\">";
    struct C { const char* label; u64 v; const char* cls; };
    const C cards[] = {
        {tr(S::HtmlCritical), hist[4], "critical"}, {tr(S::HtmlHigh), hist[3], "high"},
        {tr(S::HtmlMedium),   hist[2], "medium"},   {tr(S::HtmlLow),  hist[1], "low"},
        {tr(S::HtmlInfo),     hist[0], "info"},
    };
    for (const C& c : cards) {
        out << "<div class=\"card\"><div class=\"n\">" << c.v << "</div>"
            << "<div class=\"l\">" << c.label << "</div></div>";
    }
    out << "<div class=\"card\"><div class=\"n\">" << s.findings.size()
        << "</div><div class=\"l\">" << tr(S::HtmlTotal);

    out << localizeHtml(R"(<div class="bar">
<input type="search" id="q" placeholder="@@FILTER@@">
<select id="sev"><option value="">@@ALL@@</option>
<option value="critical">@@ONLYCRIT@@</option><option value="high">@@HIGHUP@@</option>
<option value="medium">@@MEDUP@@</option></select>
<span id="cnt" class="sub"></span></div>
<table id="t"><thead><tr><th>@@THL@@</th><th>@@THR@@</th><th>@@THF@@</th>
<th>@@THP@@</th><th>@@THG@@</th></tr></thead><tbody>
)");

    for (const Finding& f : s.findings) {
        const int sevRank = static_cast<int>(f.severity);
        out << "<tr data-sev=\"" << sevRank << "\"><td><span class=\"sev "
            << severityName(f.severity) << "\">" << severityNameLocalized(f.severity)
            << "</span></td><td>" << htmlEscape(f.ruleName)
            << "<div class=\"note\">" << htmlEscape(f.ruleId) << tr(S::HtmlSep)
            << methodName(f.method) << "</div></td>"
            << "<td class=\"path\">" << htmlEscape(f.file) << "</td><td>";
        if (f.line > 0) out << tr(S::HtmlLineAbbr) << f.line << ":" << f.column;
        else            out << tr(S::HtmlOffsetAbbr) << f.offset;
        out << "</td><td class=\"prev\">" << htmlEscape(f.preview);
        if (!f.note.empty()) out << "<div class=\"note\">" << htmlEscape(f.note) << "</div>";
        out << "</td></tr>\n";
    }

    out << localizeHtml(R"(</tbody></table>
<footer>@@FOOTER@@</footer>
<script>
(function(){
 var rows=[].slice.call(document.querySelectorAll('#t tbody tr'));
 var q=document.getElementById('q'),sev=document.getElementById('sev'),
     cnt=document.getElementById('cnt');
 var minRank={'':0,'critical':4,'high':3,'medium':2};
 function apply(){
  var term=q.value.toLowerCase(),min=minRank[sev.value]||0,n=0;
  rows.forEach(function(r){
   var ok=(+r.dataset.sev>=min)&&(!term||r.textContent.toLowerCase().indexOf(term)>=0);
   r.classList.toggle('hidden',!ok); if(ok)n++;});
  cnt.textContent='@@SHOWN@@'+n+'@@OF@@'+rows.length;
 }
 q.addEventListener('input',apply); sev.addEventListener('change',apply); apply();
})();
</script></body></html>
)");

    if (!out) { error = trf(S::ErrWriteFailed, pathToUtf8(path).c_str()); return false; }
    return true;
}

}
