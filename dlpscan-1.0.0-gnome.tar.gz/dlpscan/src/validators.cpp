#include "dlp/i18n.hpp"
#include "dlp/validators.hpp"

#include <algorithm>
#include <array>
#include <cstring>

namespace dlp {

namespace {

inline bool isDigit(char c) noexcept { return c >= '0' && c <= '9'; }

inline bool allDigits(std::string_view s) noexcept {
    if (s.empty()) return false;
    for (char c : s) if (!isDigit(c)) return false;
    return true;
}

inline int d(char c) noexcept { return c - '0'; }

bool validDate(int y, int m, int day) noexcept {
    if (m < 1 || m > 12 || day < 1) return false;
    static const int kDays[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int dim = kDays[m - 1];
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) dim = 29;
    return day <= dim;
}

}

bool luhnValid(std::string_view digits) noexcept {
    if (digits.size() < 12 || digits.size() > 19 || !allDigits(digits)) return false;
    int sum = 0;
    bool dbl = false;
    for (std::size_t i = digits.size(); i-- > 0;) {
        int v = d(digits[i]);
        if (dbl) {
            v <<= 1;
            if (v > 9) v -= 9;
        }
        sum += v;
        dbl = !dbl;
    }
    return sum % 10 == 0;
}

const char* cardBrandName(CardBrand b) noexcept {
    switch (b) {
        case CardBrand::Visa:       return "Visa";
        case CardBrand::Mastercard: return "Mastercard";
        case CardBrand::Amex:       return "American Express";
        case CardBrand::Discover:   return "Discover";
        case CardBrand::JCB:        return "JCB";
        case CardBrand::DinersClub: return "Diners Club";
        case CardBrand::UnionPay:   return "UnionPay";
        case CardBrand::Mir:        return tr(S::CardMir);
        case CardBrand::Unknown:    break;
    }
    return tr(S::CardUnknown);
}

CardBrand detectCardBrand(std::string_view s) noexcept {
    if (s.size() < 12 || !allDigits(s)) return CardBrand::Unknown;
    const int p2 = d(s[0]) * 10 + d(s[1]);
    const int p4 = p2 * 100 + d(s[2]) * 10 + d(s[3]);
    const int p6 = p4 * 100 + d(s[4]) * 10 + d(s[5]);

    if (s[0] == '4' && (s.size() == 13 || s.size() == 16 || s.size() == 19)) return CardBrand::Visa;
    if ((p2 >= 51 && p2 <= 55) || (p4 >= 2221 && p4 <= 2720))                return CardBrand::Mastercard;
    if ((p2 == 34 || p2 == 37) && s.size() == 15)                            return CardBrand::Amex;
    if (p4 == 6011 || p2 == 65 || (p6 >= 622126 && p6 <= 622925))            return CardBrand::Discover;
    if (p4 >= 3528 && p4 <= 3589)                                            return CardBrand::JCB;
    if (p2 == 36 || p2 == 38 || (p4 >= 3000 && p4 <= 3059))                  return CardBrand::DinersClub;
    if (p2 == 62)                                                            return CardBrand::UnionPay;
    if (p4 >= 2200 && p4 <= 2204)                                            return CardBrand::Mir;
    return CardBrand::Unknown;
}

bool isKnownTestCard(std::string_view s) noexcept {
    static const char* kTest[] = {
        "4111111111111111", "4012888888881881", "4222222222222",
        "4242424242424242", "4000056655665556", "5555555555554444",
        "5105105105105100", "5200828282828210", "2223003122003222",
        "378282246310005",  "371449635398431",  "378734493671000",
        "6011111111111117", "6011000990139424", "6011000000000004",
        "3530111333300000", "3566002020360505", "30569309025904",
        "38520000023237",   "6200000000000005", "5019717010103742",
    };
    for (const char* t : kTest) if (s == t) return true;
    return lowDiversity(s);
}

int kzIinChecksum(std::string_view s) noexcept {
    if (s.size() < 11 || !allDigits(s.substr(0, 11))) return -1;
    static const int w1[11] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    static const int w2[11] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 2};

    int sum = 0;
    for (int i = 0; i < 11; ++i) sum += d(s[static_cast<std::size_t>(i)]) * w1[i];
    int ctrl = sum % 11;

    if (ctrl == 10) {
        sum = 0;
        for (int i = 0; i < 11; ++i) sum += d(s[static_cast<std::size_t>(i)]) * w2[i];
        ctrl = sum % 11;
        if (ctrl == 10) return -1;
    }
    return ctrl;
}

bool kzIinValid(std::string_view s, IinInfo* info) noexcept {
    if (s.size() != 12 || !allDigits(s)) return false;

    const int ctrl = kzIinChecksum(s);
    if (ctrl < 0 || ctrl != d(s[11])) return false;

    const int yy = d(s[0]) * 10 + d(s[1]);
    const int mm = d(s[2]) * 10 + d(s[3]);
    const int dd = d(s[4]) * 10 + d(s[5]);
    const int century = d(s[6]);

    if (century < 1 || century > 6) return false;
    const int base = 1800 + ((century - 1) / 2) * 100;
    const int year = base + yy;
    if (!validDate(year, mm, dd)) return false;

    if (info) {
        info->year = year; info->month = mm; info->day = dd;
        info->female = (century % 2 == 0);
        info->organization = false;
    }
    return true;
}

bool kzBinValid(std::string_view s) noexcept {
    if (s.size() != 12 || !allDigits(s)) return false;
    const int ctrl = kzIinChecksum(s);
    if (ctrl < 0 || ctrl != d(s[11])) return false;
    const int mm = d(s[2]) * 10 + d(s[3]);
    if (mm < 1 || mm > 12) return false;
    const int type = d(s[4]);
    return type >= 4 && type <= 6;
}

bool ibanValid(std::string_view iban) noexcept {
    std::string s;
    s.reserve(iban.size());
    for (char c : iban) {
        if (c == ' ' || c == '-') continue;
        if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
        if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z'))) return false;
        s.push_back(c);
    }
    if (s.size() < 15 || s.size() > 34) return false;

    std::string moved = s.substr(4) + s.substr(0, 4);
    unsigned rem = 0;
    for (char c : moved) {
        if (c >= '0' && c <= '9') {
            rem = (rem * 10 + static_cast<unsigned>(c - '0')) % 97;
        } else {
            const unsigned v = static_cast<unsigned>(c - 'A') + 10;
            rem = (rem * 100 + v) % 97;
        }
    }
    return rem == 1;
}

std::string base64UrlDecode(std::string_view in) {
    auto val = [](char c) -> int {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '-' || c == '+')  return 62;
        if (c == '_' || c == '/')  return 63;
        return -1;
    };
    std::string out;
    out.reserve(in.size() * 3 / 4 + 3);
    u32 buf = 0;
    int bits = 0;
    for (char c : in) {
        if (c == '=') break;
        const int v = val(c);
        if (v < 0) return {};
        buf = (buf << 6) | static_cast<u32>(v);
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back(static_cast<char>((buf >> bits) & 0xFF));
        }
    }
    return out;
}

bool jwtStructureValid(std::string_view token) noexcept {
    const std::size_t p1 = token.find('.');
    if (p1 == std::string_view::npos || p1 < 8) return false;
    const std::size_t p2 = token.find('.', p1 + 1);
    if (p2 == std::string_view::npos || p2 == p1 + 1) return false;
    if (token.find('.', p2 + 1) != std::string_view::npos) return false;

    const std::string header = base64UrlDecode(token.substr(0, p1));
    if (header.size() < 8 || header.front() != '{') return false;
    if (header.find("\"alg\"") == std::string::npos &&
        header.find("'alg'")  == std::string::npos) {
        return false;
    }

    const std::string payload = base64UrlDecode(token.substr(p1 + 1, p2 - p1 - 1));
    if (payload.size() < 2 || payload.front() != '{') return false;

    const std::string_view sig = token.substr(p2 + 1);
    if (sig.empty()) return false;
    for (char c : sig) {
        const bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '=';
        if (!ok) return false;
    }
    return true;
}

bool lowDiversity(std::string_view s) noexcept {
    if (s.size() < 4) return true;
    bool same = true, seqUp = true, seqDown = true;
    for (std::size_t i = 1; i < s.size(); ++i) {
        if (s[i] != s[0]) same = false;
        if (s[i] != s[i - 1] + 1) seqUp = false;
        if (s[i] != s[i - 1] - 1) seqDown = false;
    }
    return same || seqUp || seqDown;
}

bool looksLikePlaceholder(std::string_view value) noexcept {
    if (value.size() < 3) return true;
    if (value.front() == '<' || value.front() == '$' || value.front() == '{') return true;
    if (value.find("${") != std::string_view::npos) return true;
    if (value.find("%(") != std::string_view::npos) return true;
    if (value.find("{{") != std::string_view::npos) return true;

    const std::string v = toLowerAscii(value);
    static const char* kMarkers[] = {
        "your_", "your-", "yourkey", "example", "changeme", "change_me", "placeholder",
        "dummy", "sample", "test_key", "testkey", "xxxx", "aaaaaa", "123456",
        "password", "secret_here", "insert_", "replace", "todo", "fixme", "n/a",
        "none", "null", "undefined", "not_set", "notset", "redacted", "******",
        "my_secret", "mysecret", "foobar", "lorem", "введите", "пример",
    };
    for (const char* m : kMarkers) {
        if (v.find(m) != std::string::npos) return true;
    }

    if (v.find_first_not_of("*.") == std::string::npos) return true;
    return lowDiversity(v);
}

bool isHexString(std::string_view s) noexcept {
    if (s.empty()) return false;
    for (char c : s) {
        const bool ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        if (!ok) return false;
    }
    return true;
}

bool isUuid(std::string_view s) noexcept {
    if (s.size() != 36) return false;
    static const int kDash[] = {8, 13, 18, 23};
    for (int p : kDash) if (s[static_cast<std::size_t>(p)] != '-') return false;
    for (std::size_t i = 0; i < s.size(); ++i) {
        if (i == 8 || i == 13 || i == 18 || i == 23) continue;
        const char c = s[i];
        const bool hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        if (!hex) return false;
    }
    return true;
}

bool isBase64OfText(std::string_view s) noexcept {
    if (s.size() < 16 || s.size() % 4 != 0) return false;
    const std::string dec = base64UrlDecode(s);
    if (dec.size() < 8) return false;
    std::size_t printable = 0;
    for (const char rawChar : dec) {
        const unsigned char c = static_cast<unsigned char>(rawChar);
        if ((c >= 0x20 && c < 0x7F) || c == '\n' || c == '\r' || c == '\t') ++printable;
    }
    return static_cast<double>(printable) / static_cast<double>(dec.size()) > 0.9;
}

}
