#include "dlp/redact.hpp"

#include <algorithm>

namespace dlp {

std::string redactSecret(std::string_view secret, std::size_t keepHead,
                         std::size_t keepTail) {
    if (secret.empty()) return {};
    if (secret.size() <= 8) return std::string(secret.size(), '*');

    keepHead = std::min(keepHead, secret.size() / 4);
    keepTail = std::min(keepTail, secret.size() / 4);
    const std::size_t hidden = secret.size() - keepHead - keepTail;

    std::string out;
    out.reserve(secret.size());
    out.append(secret.substr(0, keepHead));
    out.append(std::min<std::size_t>(hidden, 24), '*');
    out.append(secret.substr(secret.size() - keepTail));
    return out;
}

std::string redactPan(std::string_view digits) {
    if (digits.size() < 10) return std::string(digits.size(), '*');
    std::string out;
    out.append(digits.substr(0, 6));
    out.append(digits.size() - 10, '*');
    out.append(digits.substr(digits.size() - 4));
    return out;
}

std::string redactIin(std::string_view digits) {
    if (digits.size() != 12) return std::string(digits.size(), '*');
    return std::string(digits.substr(0, 6)) + "******";
}

std::string buildPreview(const u8* data, std::size_t bufSize,
                         std::size_t matchStart, std::size_t matchLen,
                         std::string_view replacement, std::size_t maxLen) {
    if (!data || matchStart >= bufSize) return std::string(replacement);
    matchLen = std::min(matchLen, bufSize - matchStart);

    std::size_t lineStart = matchStart;
    std::size_t guard = 0;
    while (lineStart > 0 && data[lineStart - 1] != '\n' && data[lineStart - 1] != '\r' && guard++ < 80) {
        --lineStart;
    }
    std::size_t lineEnd = matchStart + matchLen;
    guard = 0;
    while (lineEnd < bufSize && data[lineEnd] != '\n' && data[lineEnd] != '\r' && guard++ < 80) {
        ++lineEnd;
    }

    auto escapeAppend = [](std::string& dst, const u8* p, std::size_t n) {
        for (std::size_t i = 0; i < n; ++i) {
            const u8 c = p[i];
            if (c == '\t') { dst += "\\t"; }
            else if (c == '\r') { dst += "\\r"; }
            else if (c == '\n') { dst += "\\n"; }
            else if (c < 0x20 || c == 0x7F) { dst += '.'; }
            else { dst += static_cast<char>(c); }
        }
    };

    std::string out;
    out.reserve(maxLen + 16);
    if (lineStart > 0 && data[lineStart - 1] != '\n' && data[lineStart - 1] != '\r') out += "…";
    escapeAppend(out, data + lineStart, matchStart - lineStart);
    out.append(replacement);
    escapeAppend(out, data + matchStart + matchLen, lineEnd - (matchStart + matchLen));
    if (lineEnd < bufSize && data[lineEnd] != '\n' && data[lineEnd] != '\r') out += "…";

    if (out.size() > maxLen) {

        std::size_t cut = maxLen;
        while (cut > 0 && (static_cast<u8>(out[cut]) & 0xC0) == 0x80) --cut;
        out.resize(cut);
        out += "…";
    }
    return out;
}

}
