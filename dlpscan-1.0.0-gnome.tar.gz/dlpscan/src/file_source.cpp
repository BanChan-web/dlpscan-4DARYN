#include "dlp/i18n.hpp"
#include "dlp/file_source.hpp"

#include <algorithm>
#include <cstring>

#if defined(_WIN32)
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#else
#  include <fcntl.h>
#  include <sys/mman.h>
#  include <sys/stat.h>
#  include <unistd.h>
#endif

namespace dlp {

namespace {

#if defined(_WIN32)
std::wstring toWinPath(const fs::path& p) {
    std::wstring w = p.native();

    if (w.size() > 240 && w.size() > 2 && w[1] == L':' && w.compare(0, 4, L"\\\\?\\") != 0) {
        w = L"\\\\?\\" + w;
    }
    return w;
}

std::string lastErrorMessage() {
    const DWORD code = ::GetLastError();
    char buf[256] = {0};
    ::FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                     nullptr, code, 0, buf, sizeof(buf) - 1, nullptr);
    std::string msg(buf);
    while (!msg.empty() && (msg.back() == '\n' || msg.back() == '\r')) msg.pop_back();
    if (msg.empty()) msg = trf(S::ErrCodePrefix, static_cast<unsigned>(code));
    return msg;
}
#endif

}

FileSource::~FileSource() { close(); }

bool FileSource::open(const fs::path& path, u64 mapLimit, std::string& error) {
    close();

#if defined(_WIN32)
    const std::wstring wpath = toWinPath(path);
    HANDLE h = ::CreateFileW(wpath.c_str(), GENERIC_READ,
                             FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                             nullptr, OPEN_EXISTING,
                             FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        error = lastErrorMessage();
        return false;
    }
    LARGE_INTEGER li{};
    if (!::GetFileSizeEx(h, &li)) {
        error = lastErrorMessage();
        ::CloseHandle(h);
        return false;
    }
    hFile_ = h;
    size_ = static_cast<u64>(li.QuadPart);
#else
    const int fd = ::open(path.c_str(), O_RDONLY
#  ifdef O_CLOEXEC
                          | O_CLOEXEC
#  endif
                          );
    if (fd < 0) {
        error = std::strerror(errno);
        return false;
    }
    struct stat st{};
    if (::fstat(fd, &st) != 0) {
        error = std::strerror(errno);
        ::close(fd);
        return false;
    }
    if (!S_ISREG(st.st_mode)) {
        error = tr(S::ErrNotRegularFile);
        ::close(fd);
        return false;
    }
    fd_ = fd;
    size_ = static_cast<u64>(st.st_size);
#endif

    position_ = 0;
    eof_ = (size_ == 0);

    if (size_ > 0 && size_ <= mapLimit) {
        if (mapWhole(error)) {
            mapped_ = true;
        } else {
            error.clear();
        }
    }
    return true;
}

bool FileSource::mapWhole(std::string& error) {
#if defined(_WIN32)
    HANDLE mapping = ::CreateFileMappingW(static_cast<HANDLE>(hFile_), nullptr,
                                          PAGE_READONLY, 0, 0, nullptr);
    if (!mapping) { error = lastErrorMessage(); return false; }
    void* view = ::MapViewOfFile(mapping, FILE_MAP_READ, 0, 0, 0);
    if (!view) {
        error = lastErrorMessage();
        ::CloseHandle(mapping);
        return false;
    }
    hMapping_ = mapping;
    view_ = static_cast<const u8*>(view);
    return true;
#else
    void* addr = ::mmap(nullptr, static_cast<std::size_t>(size_), PROT_READ, MAP_PRIVATE, fd_, 0);
    if (addr == MAP_FAILED) { error = std::strerror(errno); return false; }
#  ifdef MADV_SEQUENTIAL
    ::madvise(addr, static_cast<std::size_t>(size_), MADV_SEQUENTIAL);
#  endif
    addr_ = addr;
    mapLen_ = static_cast<std::size_t>(size_);
    view_ = static_cast<const u8*>(addr);
    return true;
#endif
}

bool FileSource::next(std::size_t chunkSize, std::size_t overlap, Chunk& out,
                      std::string& error) {
    if (eof_ || size_ == 0) return false;

    if (mapped_) {
        if (position_ != 0) return false;
        out.data = view_;
        out.size = static_cast<std::size_t>(size_);
        out.offset = 0;
        position_ = size_;
        eof_ = true;
        return true;
    }

    if (chunkSize < 64 * 1024) chunkSize = 64 * 1024;
    if (overlap >= chunkSize) overlap = chunkSize / 8;

    const u64 readStart = (position_ > overlap && position_ > 0)
                              ? position_ - overlap
                              : 0;
    const u64 remaining = size_ - readStart;
    const std::size_t want = static_cast<std::size_t>(
        std::min<u64>(remaining, static_cast<u64>(chunkSize)));
    if (want == 0) { eof_ = true; return false; }

    buffer_.resize(want);
    std::size_t got = 0;

#if defined(_WIN32)
    LARGE_INTEGER pos{};
    pos.QuadPart = static_cast<LONGLONG>(readStart);
    if (!::SetFilePointerEx(static_cast<HANDLE>(hFile_), pos, nullptr, FILE_BEGIN)) {
        error = lastErrorMessage();
        return false;
    }
    while (got < want) {
        DWORD n = 0;
        const DWORD ask = static_cast<DWORD>(std::min<std::size_t>(want - got, 1u << 20));
        if (!::ReadFile(static_cast<HANDLE>(hFile_), buffer_.data() + got, ask, &n, nullptr)) {
            error = lastErrorMessage();
            return false;
        }
        if (n == 0) break;
        got += n;
    }
#else
    while (got < want) {
        const ssize_t n = ::pread(fd_, buffer_.data() + got, want - got,
                                  static_cast<off_t>(readStart + got));
        if (n < 0) {
            if (errno == EINTR) continue;
            error = std::strerror(errno);
            return false;
        }
        if (n == 0) break;
        got += static_cast<std::size_t>(n);
    }
#endif

    if (got == 0) { eof_ = true; return false; }
    out.data = buffer_.data();
    out.size = got;
    out.offset = readStart;
    position_ = readStart + got;
    if (position_ >= size_) eof_ = true;
    return true;
}

void FileSource::close() noexcept {
#if defined(_WIN32)
    if (view_)     { ::UnmapViewOfFile(const_cast<u8*>(view_)); view_ = nullptr; }
    if (hMapping_) { ::CloseHandle(static_cast<HANDLE>(hMapping_)); hMapping_ = nullptr; }
    if (hFile_)    { ::CloseHandle(static_cast<HANDLE>(hFile_)); hFile_ = nullptr; }
#else
    if (addr_) { ::munmap(addr_, mapLen_); addr_ = nullptr; mapLen_ = 0; }
    if (fd_ >= 0) { ::close(fd_); fd_ = -1; }
    view_ = nullptr;
#endif
    std::vector<u8>().swap(buffer_);
    size_ = 0;
    position_ = 0;
    mapped_ = false;
    eof_ = false;
}

}
