#include "dlp/i18n.hpp"
#include "dlp/file_walker.hpp"

#include <algorithm>
#include <system_error>

namespace dlp {

namespace {

const char* kNoiseDirs[] = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".mypy_cache",
    ".pytest_cache", ".gradle", ".m2", "vendor", "bower_components",
    "$Recycle.Bin", "System Volume Information", "WinSxS", "Windows.old",
    "DriverStore", "servicing", "Installer", "SoftwareDistribution",
    "AppData/Local/Temp", "Temp", "Prefetch", "assembly",
    "proc", "sys", "dev", "run",
};

const char* kNoiseExts[] = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".ico", ".webp", ".tiff", ".svg",
    ".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac",
    ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".webm",
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    ".obj", ".o", ".pdb", ".ilk", ".lib", ".a", ".pyc", ".class",
};

bool inNoiseList(std::string_view name) {
    for (const char* d : kNoiseDirs) {
        if (iequalsAscii(name, d)) return true;
    }
    return false;
}

bool noisyExtension(std::string_view ext) {
    for (const char* e : kNoiseExts) {
        if (iequalsAscii(ext, e)) return true;
    }
    return false;
}

}

bool FileWalker::excludedDir(const fs::path& dir) const {
    const std::string name = pathToUtf8(dir.filename());
    if (cfg_.skipDefaultNoise && inNoiseList(name)) return true;

    const std::string full = normalizeSeparators(pathToUtf8(dir));
    for (const std::string& g : cfg_.excludeGlobs) {
        if (wildcardMatch(normalizeSeparators(g), full, true)) return true;
    }
    return false;
}

bool FileWalker::accepted(const fs::path& p, u64 size) const {
    if (size < cfg_.minFileSize) return false;
    if (cfg_.maxFileSize && size > cfg_.maxFileSize) return false;

    const std::string ext = toLowerAscii(pathToUtf8(p.extension()));

    if (!cfg_.includeExts.empty()) {
        const bool ok = std::any_of(cfg_.includeExts.begin(), cfg_.includeExts.end(),
                                    [&](const std::string& e) { return iequalsAscii(ext, e); });
        if (!ok) return false;
    } else if (cfg_.skipDefaultNoise && noisyExtension(ext)) {
        return false;
    }

    for (const std::string& e : cfg_.excludeExts) {
        if (iequalsAscii(ext, e)) return false;
    }

    const std::string full = normalizeSeparators(pathToUtf8(p));
    for (const std::string& g : cfg_.excludeGlobs) {
        if (wildcardMatch(normalizeSeparators(g), full, true)) return false;
    }
    return true;
}

void FileWalker::walkRoot(const fs::path& root, BoundedQueue<FileTask>& queue) {
    std::error_code ec;

    const fs::file_status st = cfg_.followSymlinks ? fs::status(root, ec)
                                                   : fs::symlink_status(root, ec);
    if (ec) {
        errors_.push_back(pathToUtf8(root) + ": " + ec.message());
        return;
    }

    if (fs::is_regular_file(st)) {
        const u64 sz = static_cast<u64>(fs::file_size(root, ec));
        if (ec) { errors_.push_back(pathToUtf8(root) + ": " + ec.message()); return; }
        stats_.filesSeen.fetch_add(1, std::memory_order_relaxed);
        if (accepted(root, sz)) queue.push(FileTask{root, sz});
        else stats_.filesSkipped.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    if (!fs::is_directory(st)) {
        errors_.push_back(trf(S::ErrNotFileOrDir, pathToUtf8(root).c_str()));
        return;
    }

    auto options = fs::directory_options::skip_permission_denied;
    if (cfg_.followSymlinks) options |= fs::directory_options::follow_directory_symlink;

    fs::recursive_directory_iterator it(root, options, ec);
    if (ec) {
        errors_.push_back(pathToUtf8(root) + ": " + ec.message());
        return;
    }
    const fs::recursive_directory_iterator end;

    while (it != end) {
        if (cancel_.load(std::memory_order_relaxed)) return;

        const fs::directory_entry& entry = *it;
        std::error_code e2;

        const bool isDir = entry.is_directory(e2) && !e2;
        if (isDir) {
            stats_.dirsVisited.fetch_add(1, std::memory_order_relaxed);
            const bool tooDeep = (cfg_.maxDepth >= 0 && it.depth() >= cfg_.maxDepth);
            if (tooDeep || excludedDir(entry.path())) {
                it.disable_recursion_pending();
            }
            it.increment(e2);
            if (e2) { it.increment(e2); }
            continue;
        }

        const bool isSymlink = entry.is_symlink(e2);
        if (!cfg_.followSymlinks && isSymlink && !e2) {
            it.increment(e2);
            continue;
        }

        if (entry.is_regular_file(e2) && !e2) {
            stats_.filesSeen.fetch_add(1, std::memory_order_relaxed);
            const u64 sz = static_cast<u64>(entry.file_size(e2));
            if (e2) {
                stats_.filesUnreadable.fetch_add(1, std::memory_order_relaxed);
            } else if (accepted(entry.path(), sz)) {
                if (!queue.push(FileTask{entry.path(), sz})) return;
            } else {
                stats_.filesSkipped.fetch_add(1, std::memory_order_relaxed);
            }
        }

        it.increment(e2);
        if (e2) {

            std::error_code e3;
            it.increment(e3);
            if (e3) return;
        }
    }
}

void FileWalker::run(BoundedQueue<FileTask>& queue) {
    for (const fs::path& root : cfg_.roots) {
        if (cancel_.load(std::memory_order_relaxed)) break;
        walkRoot(root, queue);
    }
}

}
