#include "dlp/finding.hpp"

#include <iterator>
#include <utility>

namespace dlp {

void FindingSink::addBatch(std::vector<Finding>& batch) {
    if (batch.empty()) return;
    std::lock_guard<std::mutex> lk(mtx_);
    if (items_.size() >= limit_) {
        truncated_.store(true, std::memory_order_relaxed);
        batch.clear();
        return;
    }
    const std::size_t room = limit_ - items_.size();
    if (batch.size() > room) {
        truncated_.store(true, std::memory_order_relaxed);
        batch.resize(room);
    }
    items_.insert(items_.end(), std::make_move_iterator(batch.begin()),
                  std::make_move_iterator(batch.end()));
    batch.clear();
}

std::vector<Finding> FindingSink::take() {
    std::lock_guard<std::mutex> lk(mtx_);
    std::vector<Finding> out;
    out.swap(items_);
    return out;
}

std::vector<Finding> FindingSink::snapshot() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return items_;
}

std::size_t FindingSink::size() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return items_.size();
}

}
