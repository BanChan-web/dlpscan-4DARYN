Drop a UI font here to get the GNOME look and guaranteed Cyrillic/Kazakh coverage.

The app looks for these, in order:

    Cantarell-Regular.ttf  + Cantarell-Bold.ttf      <- GNOME's own font
    Inter-Regular.ttf      + Inter-SemiBold.ttf
    NotoSans-Regular.ttf   + NotoSans-Bold.ttf
    DejaVuSans.ttf         + DejaVuSans-Bold.ttf
    ui.ttf                 + ui-bold.ttf             <- any font, renamed

Where to get them on Arch:

    sudo pacman -S cantarell-fonts ttf-dejavu noto-fonts
    cp /usr/share/fonts/cantarell/Cantarell-VF.otf  assets/fonts/ui.ttf
    # or
    cp /usr/share/fonts/TTF/DejaVuSans.ttf      assets/fonts/DejaVuSans.ttf
    cp /usr/share/fonts/TTF/DejaVuSans-Bold.ttf assets/fonts/DejaVuSans-Bold.ttf

Inter: https://rsms.me/inter/    Cantarell: https://gitlab.gnome.org/GNOME/cantarell-fonts

If this folder is empty the app falls back to Segoe UI from C:\Windows\Fonts,
which is present on every real Windows 10/11 install but NOT inside Wine.
Every candidate is checked for the glyphs Ж (U+0416) and Қ (U+049A) before use,
so a font without Cyrillic is skipped instead of silently producing "?????".
