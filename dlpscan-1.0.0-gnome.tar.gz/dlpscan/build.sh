#!/usr/bin/env bash

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JOBS="$(nproc 2>/dev/null || echo 4)"
MINGW=x86_64-w64-mingw32-g++
IMGUI_TAG="${IMGUI_TAG:-v1.91.0}"

info() { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!  \033[0m %s\n' "$*"; }
fail() { printf '\033[1;31mОшибка:\033[0m %s\n' "$*" >&2; exit 1; }

need_cmake() {
    command -v cmake >/dev/null 2>&1 || fail "нужен cmake: sudo pacman -S cmake"
}

need_mingw() {
    command -v "$MINGW" >/dev/null 2>&1 || \
        fail "$MINGW не найден. Установите: sudo pacman -S mingw-w64-gcc"
}

fetch_imgui() {
    if [[ -f "$ROOT/third_party/imgui/imgui.cpp" ]]; then
        info "Dear ImGui уже на месте: third_party/imgui"
        return
    fi
    command -v git >/dev/null 2>&1 || fail "нужен git"
    info "Загружаю Dear ImGui $IMGUI_TAG"
    mkdir -p "$ROOT/third_party"
    git clone --depth 1 --branch "$IMGUI_TAG" \
        https://github.com/ocornut/imgui.git "$ROOT/third_party/imgui"
    [[ -f "$ROOT/third_party/imgui/backends/imgui_impl_win32.cpp" ]] \
        || fail "в загруженном ImGui нет backends/imgui_impl_win32.cpp"
    info "Готово: third_party/imgui ($IMGUI_TAG)"
}

link_compile_commands() {
    local from="$1"
    [[ -f "$from/compile_commands.json" ]] || return 0
    ln -sf "$from/compile_commands.json" "$ROOT/compile_commands.json"
    info "compile_commands.json -> $(basename "$from")/  (IntelliSense готов)"
}

build_linux() {
    need_cmake
    info "Сборка под Linux"
    cmake -S "$ROOT" -B "$ROOT/build" -DCMAKE_BUILD_TYPE=Release -DDLP_BUILD_TESTS=ON
    cmake --build "$ROOT/build" -j "$JOBS"
    info "Готово: $ROOT/build/dlpscan"
    "$ROOT/build/dlpscan" --selftest >/dev/null && info "Самотестирование пройдено (88/88)"
}

build_windows() {
    need_cmake; need_mingw
    info "Кросс-сборка dlpscan.exe"
    cmake -S "$ROOT" -B "$ROOT/build-win" \
          -DCMAKE_TOOLCHAIN_FILE="$ROOT/cmake/toolchain-mingw64.cmake" \
          -DCMAKE_BUILD_TYPE=Release
    cmake --build "$ROOT/build-win" --target dlpscan -j "$JOBS"
    check_exe "$ROOT/build-win/dlpscan.exe"
    link_compile_commands "$ROOT/build-win"
}

build_gui() {
    need_cmake; need_mingw
    fetch_imgui
    info "Кросс-сборка dlpscan-gui.exe"
    cmake -S "$ROOT" -B "$ROOT/build-win" \
          -DCMAKE_TOOLCHAIN_FILE="$ROOT/cmake/toolchain-mingw64.cmake" \
          -DCMAKE_BUILD_TYPE=Release \
          -DDLP_BUILD_GUI=ON
    cmake --build "$ROOT/build-win" -j "$JOBS"
    check_exe "$ROOT/build-win/dlpscan.exe"
    check_exe "$ROOT/build-win/dlpscan-gui.exe"
    link_compile_commands "$ROOT/build-win"
}

check_exe() {
    local exe="$1"
    [[ -f "$exe" ]] || fail "не создан: $exe"
    info "Готово: $exe ($(du -h "$exe" | cut -f1))"

    command -v file >/dev/null 2>&1 && file -b "$exe" | sed 's/^/      /'

    if command -v objdump >/dev/null 2>&1; then
        local deps
        deps=$(objdump -p "$exe" | awk '/DLL Name:/ {print $3}' | sort -u)
        echo "$deps" | sed 's/^/      /'
        if echo "$deps" | grep -qiE 'libstdc\+\+|libgcc|libwinpthread'; then
            warn "остались зависимости от DLL MinGW - .exe не автономен"
        else
            info "Автономный .exe: только системные DLL Windows"
        fi
    fi
}

run_tests() {
    build_linux
    info "Генерирую тестовую выборку"
    bash "$ROOT/scripts/make_samples.sh" /tmp/dlp_samples >/dev/null
    rm -rf /tmp/dlp_big && mkdir -p /tmp/dlp_big
    for i in $(seq 1 200); do cp -r /tmp/dlp_samples "/tmp/dlp_big/run_$i"; done
    info "Прогон scan_runner_smoketest"
    "$ROOT/build/scan_runner_smoketest" /tmp/dlp_big
    info "Прогон CLI на выборке"
    "$ROOT/build/dlpscan" /tmp/dlp_samples --json /tmp/dlp_report.json --quiet || true
    [[ -s /tmp/dlp_report.json ]] && info "JSON-отчёт записан: /tmp/dlp_report.json"
}

gen_ide() {
    need_cmake
    if command -v "$MINGW" >/dev/null 2>&1; then
        local gui_flag=OFF
        [[ -f "$ROOT/third_party/imgui/imgui.cpp" ]] && gui_flag=ON
        cmake -S "$ROOT" -B "$ROOT/build-win" \
              -DCMAKE_TOOLCHAIN_FILE="$ROOT/cmake/toolchain-mingw64.cmake" \
              -DCMAKE_BUILD_TYPE=Release -DDLP_BUILD_GUI=$gui_flag >/dev/null
        link_compile_commands "$ROOT/build-win"
        [[ $gui_flag == ON ]] || warn "GUI не в базе: сначала ./build.sh imgui"
    else
        cmake -S "$ROOT" -B "$ROOT/build" -DCMAKE_BUILD_TYPE=Release >/dev/null
        link_compile_commands "$ROOT/build"
        warn "MinGW не найден - IntelliSense покроет только CLI"
    fi
}

case "${1:-linux}" in
    linux)        build_linux ;;
    win|windows)  build_windows ;;
    gui)          build_gui ;;
    imgui)        fetch_imgui ;;
    test|tests)   run_tests ;;
    ide)          gen_ide ;;
    all)          build_linux; build_windows; build_gui ;;
    clean)        rm -rf "$ROOT/build" "$ROOT/build-win" "$ROOT/compile_commands.json"
                  info "Очищено (third_party/imgui сохранён)" ;;
    *)            fail "неизвестная цель: $1 (linux|win|gui|imgui|test|ide|all|clean)" ;;
esac
