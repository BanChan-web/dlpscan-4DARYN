#pragma once

#include "dlp/common.hpp"

namespace dlp {

struct ScanConfig {

    std::vector<fs::path>    roots;
    std::vector<std::string> excludeGlobs;
    std::vector<std::string> includeExts;
    std::vector<std::string> excludeExts;
    u64  maxFileSize   = 256ull << 20;
    u64  minFileSize   = 0;
    bool followSymlinks = false;
    bool skipDefaultNoise = true;
    int  maxDepth      = -1;

    bool   useSignatures  = true;
    bool   useNumeric     = true;
    bool   useEntropy     = true;
    bool   useEntropyTokens = true;
    bool   scanBinary     = true;

    double entropyThreshold = 7.2;
    std::size_t entropyWindow = 8192;
    std::size_t entropyStep   = 4096;
    double tokenEntropyMin  = 4.2;
    std::size_t tokenMinLen = 24;
    bool   iinRequireContext = false;
    bool   reportTestCards   = false;

    unsigned    threads    = 0;
    u64         mapLimit   = 512ull << 20;
    std::size_t chunkSize  = 8u << 20;
    std::size_t chunkOverlap = 8192;
    std::size_t queueCapacity = 4096;

    Severity    minSeverity = Severity::Low;
    Severity    failOn      = Severity::Low;
    std::size_t maxFindingsPerFile = 200;
    std::size_t maxFindings = 200000;
    bool        redact   = true;
    bool        color    = true;
    bool        progress = true;
    bool        quiet    = false;
    bool        verbose  = false;
    bool        showAllFindings = false;

    std::string jsonOut;
    std::string csvOut;
    std::string htmlOut;

    std::string              lang;

    std::string              rulesFile;
    std::vector<std::string> onlyRules;
    std::vector<std::string> disabledRules;
};

}
