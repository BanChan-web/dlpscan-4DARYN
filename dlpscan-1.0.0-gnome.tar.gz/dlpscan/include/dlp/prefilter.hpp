#pragma once

#include "dlp/common.hpp"

#include <cstdint>
#include <vector>

namespace dlp {

class AhoCorasick {
public:
    explicit AhoCorasick(bool caseInsensitive = true);

    void add(std::string_view pattern, int id);

    void build();

    bool        empty()      const noexcept { return patterns_ == 0; }
    std::size_t nodeCount()  const noexcept { return static_cast<std::size_t>(nodes_); }
    std::size_t patternCount() const noexcept { return patterns_; }
    std::size_t maxPatternLen() const noexcept { return maxLen_; }
    std::size_t memoryBytes() const noexcept {
        return next_.size() * sizeof(std::int32_t) + outIds_.size() * sizeof(std::int32_t);
    }

    template <class F>
    void scan(const u8* data, std::size_t n, F&& cb) const {
        if (!built_ || patterns_ == 0 || n == 0) return;
        const std::int32_t* next   = next_.data();
        const std::int32_t* ostart = outStart_.data();
        const std::int32_t* oids   = outIds_.data();
        const u8* lower = lower_.data();

        std::int32_t state = 0;
        for (std::size_t i = 0; i < n; ++i) {
            state = next[static_cast<std::size_t>(state) * 256 + lower[data[i]]];
            const std::int32_t b = ostart[state];
            const std::int32_t e = ostart[state + 1];
            for (std::int32_t k = b; k < e; ++k) cb(oids[k], i);
        }
    }

private:
    std::int32_t newNode();

    std::vector<std::int32_t> next_;
    std::vector<std::int32_t> fail_;
    std::vector<std::vector<std::int32_t>> tmpOut_;
    std::vector<std::int32_t> outStart_;
    std::vector<std::int32_t> outIds_;
    std::array<u8, 256>       lower_{};
    std::int32_t nodes_    = 0;
    std::size_t  patterns_ = 0;
    std::size_t  maxLen_   = 0;
    bool         built_    = false;
};

}
