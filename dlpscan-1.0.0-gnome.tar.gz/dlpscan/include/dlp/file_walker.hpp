#pragma once

#include "dlp/config.hpp"
#include "dlp/finding.hpp"
#include "dlp/thread_pool.hpp"

#include <atomic>
#include <functional>

namespace dlp {

struct FileTask {
    fs::path path;
    u64      size = 0;
};

class FileWalker {
public:
    FileWalker(const ScanConfig& cfg, ScanStats& stats, std::atomic<bool>& cancel)
        : cfg_(cfg), stats_(stats), cancel_(cancel) {}

    void run(BoundedQueue<FileTask>& queue);

    const std::vector<std::string>& errors() const noexcept { return errors_; }

    bool accepted(const fs::path& p, u64 size) const;

private:
    void walkRoot(const fs::path& root, BoundedQueue<FileTask>& queue);
    bool excludedDir(const fs::path& dir) const;

    const ScanConfig&        cfg_;
    ScanStats&               stats_;
    std::atomic<bool>&       cancel_;
    std::vector<std::string> errors_;
};

}
