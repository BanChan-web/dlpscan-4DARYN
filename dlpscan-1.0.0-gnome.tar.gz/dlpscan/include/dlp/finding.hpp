#pragma once

#include "dlp/common.hpp"

#include <atomic>
#include <mutex>

namespace dlp {

enum class Method : int {
    Signature,
    Checksum,
    Entropy
};

const char* methodName(Method m) noexcept;

struct Finding {
    std::string file;
    std::string ruleId;
    std::string ruleName;
    Severity    severity = Severity::Medium;
    Method      method   = Method::Signature;

    u64 offset = 0;
    u64 line   = 0;
    u64 column = 0;
    u64 length = 0;

    std::string preview;
    std::string fingerprint;
    double      entropy = 0.0;
    std::string note;

    bool operator<(const Finding& o) const noexcept {
        if (severity != o.severity) return static_cast<int>(severity) > static_cast<int>(o.severity);
        if (file != o.file) return file < o.file;
        return offset < o.offset;
    }
};

class FindingSink {
public:
    explicit FindingSink(std::size_t limit) : limit_(limit) {}

    void addBatch(std::vector<Finding>& batch);

    std::vector<Finding> take();

    std::vector<Finding> snapshot() const;

    std::size_t size() const;
    bool truncated() const noexcept { return truncated_.load(std::memory_order_relaxed); }

private:
    mutable std::mutex   mtx_;
    std::vector<Finding> items_;
    std::size_t          limit_;
    std::atomic<bool>    truncated_{false};
};

struct ScanStats {
    std::atomic<u64> filesSeen{0};
    std::atomic<u64> filesScanned{0};
    std::atomic<u64> filesSkipped{0};
    std::atomic<u64> filesUnreadable{0};
    std::atomic<u64> bytesScanned{0};
    std::atomic<u64> findings{0};
    std::atomic<u64> dirsVisited{0};
    std::atomic<u64> regexRuns{0};
    std::atomic<u64> prefilterHits{0};
};

}
