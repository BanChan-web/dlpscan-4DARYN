#pragma once

#include "dlp/common.hpp"

namespace dlp {

std::string redactSecret(std::string_view secret, std::size_t keepHead = 4,
                         std::size_t keepTail = 4);

std::string redactPan(std::string_view digits);

std::string redactIin(std::string_view digits);

std::string buildPreview(const u8* data, std::size_t bufSize,
                         std::size_t matchStart, std::size_t matchLen,
                         std::string_view replacement, std::size_t maxLen = 160);

}
