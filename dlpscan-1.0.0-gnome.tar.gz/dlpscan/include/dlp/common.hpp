#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

namespace dlp {

namespace fs = std::filesystem;

using u8  = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;
using i64 = std::int64_t;

enum class Severity : int {
    Info     = 0,
    Low      = 1,
    Medium   = 2,
    High     = 3,
    Critical = 4
};

const char* severityName(Severity s) noexcept;
const char* severityNameLocalized(Severity s) noexcept;
const char* severityNameLocalizedCap(Severity s) noexcept;
bool parseSeverity(std::string_view text, Severity& out) noexcept;

std::string pathToUtf8(const fs::path& p);
fs::path    utf8ToPath(std::string_view s);

std::string normalizeSeparators(std::string_view p);

std::string toLowerAscii(std::string_view s);
bool iequalsAscii(std::string_view a, std::string_view b) noexcept;
bool endsWithIAscii(std::string_view s, std::string_view suffix) noexcept;
bool startsWithIAscii(std::string_view s, std::string_view prefix) noexcept;

bool wildcardMatch(std::string_view pattern, std::string_view text,
                   bool caseInsensitive) noexcept;

std::string trim(std::string_view s);
std::vector<std::string> splitAndTrim(std::string_view s, char sep);

std::string humanBytes(u64 bytes);
std::string humanDuration(double seconds);
bool parseSize(std::string_view text, u64& out) noexcept;

u64 fnv1a64(const void* data, std::size_t len) noexcept;
std::string toHex64(u64 v);

std::string nowIso8601Utc();

bool stdoutIsTty() noexcept;

void enableConsoleUtf8AndAnsi() noexcept;

void writeConsoleUtf8(std::ostream& os, const std::string& text);
void flushConsole(std::ostream& os);

}
