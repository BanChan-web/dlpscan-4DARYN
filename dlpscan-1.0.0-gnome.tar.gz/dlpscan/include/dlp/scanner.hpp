#pragma once

#include "dlp/config.hpp"
#include "dlp/detectors.hpp"
#include "dlp/entropy.hpp"
#include "dlp/finding.hpp"
#include "dlp/rules.hpp"

#include <regex>
#include <unordered_set>

namespace dlp {

struct ScanContext {
    std::vector<std::pair<int, std::size_t>> hits;
    std::vector<std::size_t>  ruleNextAllowed;
    std::vector<NumericHit>   numeric;
    std::vector<TokenHit>     tokens;
    std::vector<std::pair<std::size_t, std::size_t>> covered;
    std::vector<std::pair<int, Finding>> candidates;
    std::unordered_set<u64>   seen;
    std::vector<Finding>      out;
    std::cmatch               match;
};

class Scanner {
public:
    Scanner(const RuleSet& rules, const ScanConfig& cfg, ScanStats& stats)
        : rules_(rules), cfg_(cfg), stats_(stats) {}

    bool scanFile(const fs::path& path, ScanContext& ctx, std::string& error);

private:
    struct FileState {
        std::string utf8Path;
        std::string ext;
        u64  lineBase        = 1;
        u64  lineCountedUpTo = 0;
        u64  lastLineStart   = 0;
        bool binary          = false;
        bool sniffed         = false;
        SniffResult sniff{};
        std::size_t perFile  = 0;
    };

    void scanChunk(const u8* data, std::size_t n, u64 base, ScanContext& ctx, FileState& st);
    void runSignatures(const u8* data, std::size_t n, u64 base, ScanContext& ctx, FileState& st);
    void runNumeric(const u8* data, std::size_t n, u64 base, ScanContext& ctx, FileState& st);
    void runTokens(const u8* data, std::size_t n, u64 base, ScanContext& ctx, FileState& st);
    void finalizeEntropy(const EntropyProfile& p, ScanContext& ctx, FileState& st);

    bool emit(Finding&& f, ScanContext& ctx, FileState& st);
    void assignLines(const u8* data, std::size_t n, u64 base, ScanContext& ctx,
                     FileState& st, std::size_t firstIdx);

    const RuleSet&    rules_;
    const ScanConfig& cfg_;
    ScanStats&        stats_;
};

const char* expectedTypeForExtension(std::string_view ext) noexcept;

bool isTextExtension(std::string_view ext) noexcept;

}
