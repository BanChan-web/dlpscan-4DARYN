#pragma once

#include "dlp/common.hpp"

namespace dlp {

enum class CardBrand {
    Unknown, Visa, Mastercard, Amex, Discover, JCB, DinersClub, UnionPay, Mir
};

const char* cardBrandName(CardBrand b) noexcept;
CardBrand   detectCardBrand(std::string_view digits) noexcept;

bool luhnValid(std::string_view digits) noexcept;

bool isKnownTestCard(std::string_view digits) noexcept;

struct IinInfo {
    int  year         = 0;
    int  month        = 0;
    int  day          = 0;
    bool female       = false;
    bool organization = false;
};

int kzIinChecksum(std::string_view first11) noexcept;

bool kzIinValid(std::string_view digits, IinInfo* info = nullptr) noexcept;

bool kzBinValid(std::string_view digits) noexcept;

bool ibanValid(std::string_view iban) noexcept;

bool jwtStructureValid(std::string_view token) noexcept;

std::string base64UrlDecode(std::string_view in);

bool looksLikePlaceholder(std::string_view value) noexcept;

bool lowDiversity(std::string_view s) noexcept;

bool isHexString(std::string_view s) noexcept;

bool isUuid(std::string_view s) noexcept;

bool isBase64OfText(std::string_view s) noexcept;

}
