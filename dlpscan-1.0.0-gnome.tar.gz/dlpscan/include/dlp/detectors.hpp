#pragma once

#include "dlp/common.hpp"

namespace dlp {

struct NumericHit {
    std::size_t start = 0;
    std::size_t length = 0;
    std::string digits;
};

struct NumericOptions {
    bool findCards = true;
    bool findIin   = true;
    std::size_t maxRunDigits = 24;
};

void scanNumericRuns(const u8* data, std::size_t n, const NumericOptions& opt,
                     std::vector<NumericHit>& out);

struct TokenHit {
    std::size_t start = 0;
    std::size_t length = 0;
    std::size_t fullLength = 0;
    double entropy = 0.0;
};

struct TokenOptions {
    std::size_t minLen     = 24;
    std::size_t maxLen     = 512;
    double      minEntropy = 4.2;

    double      strongEntropy = 4.8;
    std::size_t strongMinLen  = 40;
};

void scanEntropicTokens(const u8* data, std::size_t n, const TokenOptions& opt,
                        std::vector<TokenHit>& out);

bool hasSecretContext(const u8* data, std::size_t n, std::size_t pos,
                      std::size_t window = 96);

bool hasIinContext(const u8* data, std::size_t n, std::size_t pos,
                   std::size_t window = 64);

}
