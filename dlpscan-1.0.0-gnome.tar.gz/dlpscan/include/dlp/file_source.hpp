#pragma once

#include "dlp/common.hpp"

namespace dlp {

class FileSource {
public:
    struct Chunk {
        const u8*   data   = nullptr;
        std::size_t size   = 0;
        u64         offset = 0;
    };

    FileSource() = default;
    ~FileSource();

    FileSource(const FileSource&)            = delete;
    FileSource& operator=(const FileSource&) = delete;

    bool open(const fs::path& path, u64 mapLimit, std::string& error);
    void close() noexcept;

    u64  size()   const noexcept { return size_; }
    bool mapped() const noexcept { return mapped_; }

    bool next(std::size_t chunkSize, std::size_t overlap, Chunk& out, std::string& error);

private:
    bool mapWhole(std::string& error);

    u64             size_    = 0;
    u64             position_ = 0;
    bool            mapped_  = false;
    bool            eof_     = false;
    const u8*       view_    = nullptr;
    std::vector<u8> buffer_;

#if defined(_WIN32)
    void* hFile_    = nullptr;
    void* hMapping_ = nullptr;
#else
    int   fd_ = -1;
    void* addr_ = nullptr;
    std::size_t mapLen_ = 0;
#endif
};

}
