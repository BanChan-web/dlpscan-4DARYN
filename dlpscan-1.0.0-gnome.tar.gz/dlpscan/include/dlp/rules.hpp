#pragma once

#include "dlp/common.hpp"
#include "dlp/prefilter.hpp"

#include <regex>

namespace dlp {

enum class Validator {
    None,
    Jwt,
    Entropy,
    NotPlaceholder,
    Iban
};

struct Rule {
    std::string id;
    std::string name;
    std::string description;
    Severity    severity = Severity::Medium;

    std::string pattern;
    bool        icase   = false;

    std::vector<std::string> keywords;

    Validator validator  = Validator::None;
    double    entropyMin = 0.0;
    int       captureGroup = 0;
    std::size_t windowBefore = 256;
    std::size_t windowAfter  = 1024;
    bool      enabled = true;

    std::regex re;
    bool       compiled = false;
};

class RuleSet {
public:

    void loadDefaults();

    bool loadFromFile(const fs::path& path, std::string& error);

    void applyFilters(const std::vector<std::string>& onlyIds,
                      const std::vector<std::string>& disabledIds);

    bool compile(std::string& error);

    const std::vector<Rule>& rules()     const noexcept { return rules_; }
    const AhoCorasick&       prefilter() const noexcept { return prefilter_; }
    const std::vector<int>&  heavyRules() const noexcept { return heavy_; }
    std::size_t enabledCount() const noexcept;

private:
    std::vector<Rule> rules_;
    AhoCorasick       prefilter_{true};
    std::vector<int>  heavy_;
};

}
