#pragma once

#include "dlp/config.hpp"
#include "dlp/finding.hpp"

#include <iosfwd>

namespace dlp {

struct ScanSummary {
    std::vector<Finding> findings;
    ScanConfig           config;
    double               seconds       = 0.0;
    u64                  filesScanned  = 0;
    u64                  filesSkipped  = 0;
    u64                  filesUnreadable = 0;
    u64                  bytesScanned  = 0;
    u64                  regexRuns     = 0;
    u64                  prefilterHits = 0;
    unsigned             threads       = 1;
    std::size_t          ruleCount     = 0;
    std::vector<std::string> errors;
    bool                 truncated     = false;
    std::string          startedAt;
    std::string          version;
};

std::array<u64, 5> severityHistogram(const std::vector<Finding>& f);

void writeConsoleReport(const ScanSummary& s, std::ostream& os, bool color);
bool writeJsonReport(const ScanSummary& s, const fs::path& path, std::string& error);
bool writeCsvReport(const ScanSummary& s, const fs::path& path, std::string& error);
bool writeHtmlReport(const ScanSummary& s, const fs::path& path, std::string& error);

std::string jsonEscape(std::string_view s);
std::string htmlEscape(std::string_view s);
std::string csvEscape(std::string_view s);

}
