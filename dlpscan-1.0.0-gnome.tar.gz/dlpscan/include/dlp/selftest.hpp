#pragma once

#include <iosfwd>

namespace dlp {

int runSelfTests(std::ostream& os);

}
