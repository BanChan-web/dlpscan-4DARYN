#pragma once

#include "dlp/common.hpp"

#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <thread>

namespace dlp {

template <class T>
class BoundedQueue {
public:
    explicit BoundedQueue(std::size_t capacity) : capacity_(capacity ? capacity : 1) {}

    bool push(T value) {
        std::unique_lock<std::mutex> lk(mtx_);
        notFull_.wait(lk, [&] { return closed_ || items_.size() < capacity_; });
        if (closed_) return false;
        items_.push_back(std::move(value));
        lk.unlock();
        notEmpty_.notify_one();
        return true;
    }

    bool pop(T& out) {
        std::unique_lock<std::mutex> lk(mtx_);
        notEmpty_.wait(lk, [&] { return closed_ || !items_.empty(); });
        if (items_.empty()) return false;
        out = std::move(items_.front());
        items_.pop_front();
        lk.unlock();
        notFull_.notify_one();
        return true;
    }

    void close() {
        {
            std::lock_guard<std::mutex> lk(mtx_);
            closed_ = true;
        }
        notEmpty_.notify_all();
        notFull_.notify_all();
    }

    std::size_t size() const {
        std::lock_guard<std::mutex> lk(mtx_);
        return items_.size();
    }

private:
    mutable std::mutex      mtx_;
    std::condition_variable notEmpty_;
    std::condition_variable notFull_;
    std::deque<T>           items_;
    std::size_t             capacity_;
    bool                    closed_ = false;
};

unsigned defaultThreadCount() noexcept;

}
