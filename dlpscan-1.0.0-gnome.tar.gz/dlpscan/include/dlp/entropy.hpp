#pragma once

#include "dlp/common.hpp"

namespace dlp {

class EntropyCounter {
public:
    void reset() noexcept;

    void add(u8 b) noexcept;
    void remove(u8 b) noexcept;
    void addRange(const u8* data, std::size_t n) noexcept;

    double entropy() const noexcept;

    double chiSquareUniform() const noexcept;

    u64 total() const noexcept { return total_; }
    u32 distinctBytes() const noexcept;
    const std::array<u64, 256>& counts() const noexcept { return counts_; }

private:
    std::array<u64, 256> counts_{};
    u64    total_   = 0;
    double sumFLog_ = 0.0;
};

double shannonEntropy(const u8* data, std::size_t n) noexcept;

double tokenEntropy(std::string_view token) noexcept;

struct EntropyProfile {
    double fileEntropy      = 0.0;
    double maxWindowEntropy = 0.0;
    u64    maxWindowOffset  = 0;
    u64    windowsAbove     = 0;
    u64    windowsTotal     = 0;
    double printableRatio   = 1.0;
    bool   containsNul      = false;
};

class EntropyProfiler {
public:
    EntropyProfiler(std::size_t window, std::size_t step, double threshold) noexcept;

    void feed(const u8* data, std::size_t n, u64 absoluteOffset) noexcept;

    EntropyProfile finish() noexcept;

private:
    void slide() noexcept;

    std::size_t window_;
    std::size_t step_;
    double      threshold_;

    EntropyCounter global_;
    EntropyCounter win_;
    std::vector<u8> ring_;
    std::size_t     ringHead_ = 0;
    std::size_t     ringSize_ = 0;
    std::size_t     sinceStep_ = 0;
    u64             windowStart_ = 0;
    u64             printable_ = 0;
    EntropyProfile  prof_{};
};

bool looksLikeText(const u8* data, std::size_t n) noexcept;

struct SniffResult {
    const char* type       = nullptr;
    bool        compressed = false;
    bool        encrypted  = false;
};
SniffResult sniffContentType(const u8* data, std::size_t n) noexcept;

}
