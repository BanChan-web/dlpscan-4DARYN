#pragma once

#include "dlp/config.hpp"

namespace dlp {

constexpr const char* kVersion = "1.0.0";

enum class CliAction { Scan, Help, Version, ListRules, SelfTest, Error };

struct CliResult {
    CliAction   action = CliAction::Scan;
    ScanConfig  config;
    std::string error;
};

CliResult parseCommandLine(int argc, char** argv);
void printHelp(std::ostream& os);
void printVersion(std::ostream& os);

}
