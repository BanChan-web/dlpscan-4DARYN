#pragma once

#include "dlp/config.hpp"
#include "dlp/finding.hpp"
#include "dlp/report.hpp"

#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

namespace dlp {

enum class RunState { Idle, Running, Done, Cancelled, Failed };

const char* runStateName(RunState s) noexcept;

class ScanRunner {
public:
    ScanRunner();
    ~ScanRunner();

    ScanRunner(const ScanRunner&) = delete;
    ScanRunner& operator=(const ScanRunner&) = delete;

    void start(ScanConfig cfg);

    void cancel() noexcept;

    RunState state() const noexcept { return state_.load(); }
    bool     isCancelRequested() const noexcept { return cancelRequested_.load(); }
    bool     isActive() const noexcept { return state() == RunState::Running; }

    const ScanStats& stats() const noexcept { return *stats_; }

    std::vector<Finding> liveFindings() const;

    std::shared_ptr<const ScanSummary> summary() const;

    double elapsedSeconds() const;

    std::string errorMessage() const;

private:
    void runBody(ScanConfig cfg);

    std::atomic<RunState> state_{RunState::Idle};
    std::atomic<bool>     cancelRequested_{false};
    std::atomic<double>   elapsedAtEnd_{0.0};

    std::unique_ptr<ScanStats>   stats_;
    std::unique_ptr<FindingSink> sink_;
    std::thread                  worker_;
    std::chrono::steady_clock::time_point startTime_{};
    std::string                  startedAtIso_;

    mutable std::mutex                 summaryMtx_;
    std::shared_ptr<const ScanSummary> summary_;

    mutable std::mutex errorMtx_;
    std::string        error_;
};

}
