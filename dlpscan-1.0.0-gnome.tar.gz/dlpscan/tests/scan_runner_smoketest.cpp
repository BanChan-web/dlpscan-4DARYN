#include "dlp/scan_runner.hpp"

#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <thread>

using namespace dlp;
using namespace std::chrono_literals;

int main(int argc, char** argv) {
    if (argc < 2) { std::fprintf(stderr, "usage: %s <dir>\n", argv[0]); return 2; }

    {
        ScanRunner runner;
        assert(runner.state() == RunState::Idle);

        ScanConfig cfg;
        cfg.roots = {utf8ToPath(argv[1])};
        cfg.progress = false;
        cfg.quiet = true;

        runner.start(cfg);
        assert(runner.state() == RunState::Running || runner.state() == RunState::Done);

        int polls = 0;
        std::size_t maxLiveSeen = 0;
        std::size_t maxFilesSeen = 0;
        while (runner.state() == RunState::Running) {
            auto live = runner.liveFindings();
            maxLiveSeen  = std::max(maxLiveSeen, live.size());
            maxFilesSeen = std::max<std::size_t>(maxFilesSeen, runner.stats().filesScanned.load());
            ++polls;
            std::this_thread::sleep_for(100ms);
        }
        std::printf("[test1] polls while running: %d, max live findings seen mid-scan: %zu, "
                     "max files-scanned seen mid-scan: %zu\n", polls, maxLiveSeen, maxFilesSeen);

        assert(runner.state() == RunState::Done);
        auto sum = runner.summary();
        assert(sum != nullptr);
        std::printf("[test1] done: files=%llu bytes=%llu findings=%zu seconds=%.3f threads=%u\n",
                    (unsigned long long)sum->filesScanned, (unsigned long long)sum->bytesScanned,
                    sum->findings.size(), sum->seconds, sum->threads);
        assert(sum->filesScanned > 0);
        assert(sum->findings.size() > 0);
        assert(sum->bytesScanned > 0);
        assert(polls >= 2);
        assert(maxLiveSeen > 0);
        assert(maxFilesSeen > 0 && maxFilesSeen < sum->filesScanned);

        std::printf("[test1] errorMessage (should be empty): '%s'\n", runner.errorMessage().c_str());
        assert(runner.errorMessage().empty());
    }

    {
        ScanRunner runner;
        ScanConfig cfg;
        cfg.roots = {utf8ToPath(argv[1])};
        cfg.progress = false;
        cfg.quiet = true;

        runner.start(cfg);
        std::this_thread::sleep_for(300ms);
        std::size_t filesBeforeCancel = runner.stats().filesScanned.load();
        runner.cancel();

        int spins = 0;
        while (runner.state() == RunState::Running && spins < 200) {
            std::this_thread::sleep_for(20ms);
            ++spins;
        }
        std::printf("[test2] state after cancel: %s, filesScanned at cancel-call: %zu, "
                     "final filesScanned: %llu\n",
                    runStateName(runner.state()), filesBeforeCancel,
                    (unsigned long long)runner.stats().filesScanned.load());

        assert(runner.state() == RunState::Cancelled);
        auto sum = runner.summary();
        assert(sum != nullptr);
        assert(sum->filesScanned < 3000);
    }

    {
        ScanRunner runner;
        ScanConfig cfg;
        cfg.roots = {utf8ToPath(argv[1])};
        cfg.progress = false;
        cfg.quiet = true;
        runner.start(cfg);
        std::this_thread::sleep_for(50ms);

    }
    std::printf("[test3] destructor-while-running: ok (no hang, no crash)\n");

    std::printf("ALL SCAN_RUNNER SMOKETESTS PASSED\n");
    return 0;
}
