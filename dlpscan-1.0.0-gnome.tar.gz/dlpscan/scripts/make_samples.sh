#!/usr/bin/env bash

set -euo pipefail

OUT="${1:-./samples}"
rm -rf "$OUT"
mkdir -p "$OUT/configs" "$OUT/logs" "$OUT/docs" "$OUT/clean" "$OUT/hidden"

cat > "$OUT/configs/app.env" <<'EOF'
APP_ENV=production
DB_HOST=10.0.0.14
DATABASE_URL=postgres://app_user:Xk7
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
GOOGLE_API_KEY=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY
STRIPE_SECRET=sk_live_4eC39HqLyjWDarjtT1zdp7dc

PLACEHOLDER_KEY=your_api_key_here
TEMPLATE_PASS=${DB_PASSWORD}
DUMMY=xxxxxxxxxxxxxxxxxxxx
EOF

cat > "$OUT/configs/id_rsa" <<'EOF'
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAvX3mK9dQ2bZ8yTn4pLwR7sHcVfGjNxKmEoPqYtUiOaSdFgHj
kLmNbVcXzAqWsEdRfTgYhUjIkOlPpAsDfGhJkLzXcVbNmQwErTyUiOpAsDfGhJkL
-----END RSA PRIVATE KEY-----
EOF

cat > "$OUT/logs/api.log" <<'EOF'
2026-01-15 09:12:03 INFO  GET /api/v1/users 200 14ms
2026-01-15 09:12:44 DEBUG Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4ifQ.dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk
2026-01-15 09:13:01 WARN  payment failed for card 4532 0162 7409 8156
2026-01-15 09:13:02 INFO  клиент ИИН 950101300125 верифицирован
2026-01-15 09:13:40 INFO  связаться по телефону +7 701 234 56 78
2026-01-15 09:14:00 ERROR upstream timeout after 30s
EOF

cat > "$OUT/docs/клиенты.csv" <<'EOF'
ФИО,ИИН,Телефон,Карта,Почта
Иванов И.И.,950101300125,+77012345678,4532016274098156,ivanov@example.kz
Петров П.П.,880315450017,+77021112233,5413336274098159,petrov@example.kz
EOF

cat > "$OUT/docs/backup_users.txt" <<'EOF'
admin@corp.local:P@ssw0rd2026!
user1@corp.local:qwerty12345
service@corp.local:Xy9
EOF

head -c 65536 /dev/urandom > "$OUT/logs/archive_2026.log"

{ printf 'Salted__'; head -c 4096 /dev/urandom; } > "$OUT/docs/notes.txt"

{
  echo "Отчёт о работе системы за январь 2026 года."
  echo "Все подсистемы функционировали в штатном режиме."
  head -c 16384 /dev/urandom | base64 | tr -d '\n'
  echo
  echo "Конец отчёта. Подготовлено автоматически."
} > "$OUT/logs/report_mixed.log"

cat > "$OUT/clean/readme.md" <<'EOF'

Версия 2.4.1, сборка от 2026-01-15. Идентификатор запроса
550e8400-e29b-41d4-a716-446655440000 используется для трассировки.
Контрольная сумма релиза: d41d8cd98f00b204e9800998ecf8427e

Порядок установки описан в разделе «Быстрый старт».
EOF

cat > "$OUT/clean/data.csv" <<'EOF'
id,timestamp,value,status
1001,202601150912,45.21,ok
1002,202601150913,45.88,ok
1003,202601150914,44.10,warn
EOF

echo "Тестовые данные созданы в: $OUT"
find "$OUT" -type f | sort
